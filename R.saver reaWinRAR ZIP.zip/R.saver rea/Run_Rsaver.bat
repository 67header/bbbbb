@echo off
title R.saver - version 6.9.5
cd /d "%~dp0"
set PYTHONIOENCODING=utf-8

python run.py
if %errorlevel% neq 0 (
    echo.
    echo An error occurred while running R.saver.
    pause
)
