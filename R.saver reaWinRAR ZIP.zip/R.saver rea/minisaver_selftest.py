# -*- coding: utf-8 -*-
"""اختبار ذاتي شامل لـ MiniSaver
يبني صورة قرص FAT16 تحتوي:
  - ملفات سليمة (نص + مجلد فرعي)
  - ملف محذوف (0xE5 + سلسلة FAT مصفّرة)
  - صورة PNG و JPEG و ZIP داخل المساحة الحرّة (للتواقيع/الحفر)
ثم يشغّل محرك المسح والاسترجاع ويتحقق من صحة المحتوى المستعاد.
"""
import os
import struct
import sys
import io
import zipfile
import tempfile

BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE)

from minisaver.engine import ScanEngine  # noqa: E402

BPS, SPC = 512, 4
TOTAL_SECTORS = 32768            # 16MB
ROOT_ENTRIES = 512
RESERVED = 1
NFATS = 2
ROOT_SECTORS = ROOT_ENTRIES * 32 // BPS
FAT_SECTORS = 68
DATA_START = RESERVED + NFATS * FAT_SECTORS + ROOT_SECTORS  # 138
CLUSTERS = (TOTAL_SECTORS - DATA_START) // SPC  # ~8157 -> FAT16

FAILED = []


def check(name, cond, extra=''):
    status = 'PASS' if cond else 'FAIL'
    print(f'  [{status}] {name} {extra}')
    if not cond:
        FAILED.append(name)


def fat_entry_val(n):
    return 0xFFFF  # في FAT16


def build_image(path):
    img = bytearray(BPS * TOTAL_SECTORS)

    # ---- BPB (FAT16) ----
    bs = bytearray(512)
    bs[0:3] = b'\xEB\x3C\x90'
    bs[3:11] = b'MSWIN4.1'
    struct.pack_into('<H', bs, 11, BPS)
    bs[13] = SPC
    struct.pack_into('<H', bs, 14, RESERVED)
    bs[16] = NFATS
    struct.pack_into('<H', bs, 17, ROOT_ENTRIES)
    struct.pack_into('<H', bs, 19, TOTAL_SECTORS & 0xFFFF)
    bs[21] = 0xF8
    struct.pack_into('<H', bs, 22, FAT_SECTORS)
    struct.pack_into('<H', bs, 24, 63)          # sectors per track
    struct.pack_into('<H', bs, 26, 255)         # heads
    struct.pack_into('<I', bs, 32, 0)           # hidden
    struct.pack_into('<I', bs, 36, 0)           # total32
    bs[38] = 0x80                                # drive num
    bs[39] = 0x29                                # ext boot sig
    struct.pack_into('<I', bs, 39 + 1, 0x1234ABCD)  # volume id (offset 39? فعليا 39..43)
    bs[43:54] = b'MINITEST    '                 # label
    bs[54:62] = b'FAT16   '
    bs[510:512] = b'\x55\xAA'
    img[0:512] = bs

    def cluster_abs(c):
        return (DATA_START + (c - 2) * SPC) * BPS

    fat = bytearray(FAT_SECTORS * BPS)

    def set_fat16(n, val):
        off = n * 2
        struct.pack_into('<H', fat, off, val)

    set_fat16(0, 0xFFF8)
    set_fat16(1, 0xFFFF)

    def alloc_chain(start, nclusters):
        """تخصيص سلسلة متتالية في FAT"""
        for i in range(nclusters):
            nxt = start + i + 1
            set_fat16(start + i, 0xFFFF if i == nclusters - 1 else nxt)

    def write_cluster(c, data):
        off = cluster_abs(c)
        img[off:off + len(data)] = data

    def dir_entry(name, attr, cluster, size, deleted=False, lfn=None):
        e = bytearray(32)
        # مدخلات النقاط . و .. تُخزن حرفياً في حقول الاسم 11 بايت
        if name in ('.', '..'):
            short = name.encode('ascii').ljust(11, b' ')
            e[0:11] = short
            e[11] = attr
            struct.pack_into('<H', e, 26, cluster & 0xFFFF)
            struct.pack_into('<I', e, 28, size)
            return bytes(e)
        # تنسيق 8.3 الحقيقي: الاسم 8 بايت + الامتداد 3 بايت بحشو فراغات
        if '.' in name:
            b8, ext3 = name.rsplit('.', 1)
        else:
            b8, ext3 = name, ''
        short = b8.upper().encode('ascii')[:8].ljust(8, b' ') + \
            ext3.upper().encode('ascii')[:3].ljust(3, b' ')
        if deleted:
            short = b'\xE5' + short[1:]
        e[0:11] = short.ljust(11, b' ')
        e[11] = attr
        struct.pack_into('<H', e, 26, cluster & 0xFFFF)
        if attr & 0x10:  # dir
            struct.pack_into('<H', e, 20, (cluster >> 16) & 0xFFFF)
        struct.pack_into('<I', e, 28, size)
        return bytes(e)

    # FAT12/16: cluster high غير مستخدم (يُترك 0)
    next_cluster = [2]

    def new_chain(n):
        c = next_cluster[0]
        next_cluster[0] += n
        alloc_chain(c, n)
        return c

    # ملف 1: نص سليم في الجذر (حجم 1000 -> عنقود واحد)
    txt1 = (b'HELLO MINISAVER LIVE FILE\n' * 38)[:1000]
    c = new_chain(1)
    write_cluster(c, txt1.ljust(BPS * SPC, b'\x00'))
    root = bytearray(ROOT_SECTORS * BPS)
    root[0:32] = dir_entry('LIVE.TXT', 0x20, c, len(txt1))

    # مجلد فرعي مع ملف داخله
    sub_c = new_chain(1)
    sub = bytearray(BPS * SPC)
    sub[0:32] = dir_entry('.', 0x10, sub_c, 0)
    sub[32:64] = dir_entry('..', 0x10, 0, 0)
    txt2 = b'NESTED FILE CONTENT 0123456789ABCDEF' * 20
    c2 = new_chain(1)
    write_cluster(c2, txt2.ljust(BPS * SPC, b'\x00'))
    sub[64:96] = dir_entry('NESTED.DAT', 0x20, c2, len(txt2))
    write_cluster(sub_c, bytes(sub))
    root[32:64] = dir_entry('SUBDIR', 0x10, sub_c, 0)

    # ملف محذوف: مدخلة 0xE5 وحجم معروف، بدون FAT (مصفّرة)
    dtext = b'DELETED BUT RECOVERABLE CONTENT\r\n' * 40  # 1320 بايت
    dc = new_chain(1)  # عنقود فعلي مكتوب لكن FAT سيصفّر بعده
    write_cluster(dc, dtext.ljust(BPS * SPC, b'\x00'))
    set_fat16(dc, 0x0000)  # محذوف: السلسلة صفرّت
    root[64:96] = dir_entry('GONE.TXT', 0x20, dc, len(dtext), deleted=True)
    # نتحقق أن أول بايت 0xE5
    assert root[64] == 0xE5

    img[RESERVED * BPS: RESERVED * BPS + len(fat)] = fat
    img[(RESERVED + NFATS * FAT_SECTORS) * BPS:
        (RESERVED + NFATS * FAT_SECTORS) * BPS + len(root)] = root

    # ---- ملفات للتوقيع في المساحة الحرّة ----
    # PNG (1x1 مع بيانات حشوة) >= 512 بايت
    def make_png(pad_bytes=2000):
        import zlib
        sig = b'\x89PNG\r\n\x1a\n'

        def chunk(typ, data):
            c = struct.pack('>I', len(data)) + typ + data
            return c + struct.pack('>I', zlib.crc32(typ + data) & 0xFFFFFFFF)
        ihdr = chunk(b'IHDR', struct.pack('>IIBBBBB', 1, 1, 8, 2, 0, 0, 0))
        idat = chunk(b'IDAT', b'\x00' + b'\xAA' * pad_bytes)
        iend = chunk(b'IEND', b'')
        return sig + ihdr + idat + iend

    # JPEG مصغّر مع حشوة
    def make_jpeg(pad_bytes=3000):
        head = (b'\xFF\xD8\xFF\xE0\x00\x10JFIF\x00\x01\x01\x00\x00\x01\x00'
                b'\x01\x00\x00')
        body = b'\xFF\xDB' + struct.pack('>H', 67) + b'\x33' * 65
        body += b'\xAA' * pad_bytes
        return head + body + b'\xFF\xD9'

    # ZIP حقيقي
    def make_zip():
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, 'w', zipfile.ZIP_STORED) as z:
            z.writestr('inside.txt', b'ZIP CONTENT INSIDE ARCHIVE' * 30)
        return buf.getvalue()


    # توضع ملفات التوقيع في المساحة الحرة، كل ملف يبدأ على حد قطاع 512
    # لأن الماسح يفحص على خطوات 512 بايت
    png = make_png()
    jpg = make_jpeg()
    zipped = make_zip()

    def pad_to(n):
        return (n + 511) & ~511

    heap_free = cluster_abs(next_cluster[0] + 1)  # بعد آخر عنقود مخصص
    blob = png + b'\x00' * (pad_to(len(png)) - len(png))
    jpg_off = len(blob)
    pad_jpg = pad_to(len(blob) + len(jpg)) - (len(blob) + len(jpg))
    blob += jpg + b'\xEE' * pad_jpg
    zip_off = len(blob)
    blob += zipped
    end = heap_free + len(blob)
    assert end < len(img), 'blob أكبر من المساحة'
    img[heap_free:end] = blob

    with open(path, 'wb') as f:
        f.write(img)
    return {'png': png, 'jpg': jpg, 'zip': zipped,
            'txt1': txt1, 'txt2': txt2, 'dtext': dtext,
            'heap_free': heap_free, 'jpg_off': jpg_off,
            'zip_off': zip_off}


def main():
    print('=== MiniSaver اختبار ذاتي ===')
    tmp = tempfile.mkdtemp(prefix='minisaver_test_')
    img_path = os.path.join(tmp, 'test_fat16.img')
    expect = build_image(img_path)
    print(f'صورة الاختبار: {img_path}')

    eng = ScanEngine(img_path, progress=lambda *a: None)
    eng.open()
    vols = eng.discover()
    print(f'فوليومات: {[v.describe() for v in vols]}')
    live, lost = eng.scan(deep=False, carve=True)

    names_live = {it['name'] for it in live}
    names_lost = {it['name'] for it in lost}

    print(f'\nسليم ({len(live)}):')
    for it in live:
        print(f"   {it['name']:<20} {it['size']:>8}  path={it.get('path','')}")
    print(f'محذوف/محفور ({len(lost)}):')
    for it in lost:
        print(f"   {it['name']:<20} {it['size']:>8}  "
              f"sig={it.get('sig', '')}")

    check('ملف سليم LIVE.TXT مكتشف', 'LIVE.TXT' in names_live)
    check('مجلد SUBDIR مكتشف', 'SUBDIR' in names_live)
    check('ملف NESTED.DAT مكتشف', 'NESTED.DAT' in names_live)
    check('ملف محذوف مكتشف', any('_ELETED' in n or n.startswith('_')
                                 for n in names_lost),
          f'lost={sorted(names_lost)}')
    check('PNG محفور', any('.png' in n for n in names_lost))
    check('JPEG محفور', any('.jpg' in n for n in names_lost))
    check('ZIP محفور', any('.zip' in n for n in names_lost))

    # ---- الاسترجاع ----
    out = os.path.join(tmp, 'out')
    ok, fail, written = eng.recover(lost + live, out)
    print(f'\nاسترجاع: نجاح={ok} فشل={fail} بايتات={written}')
    check('لا فشل في الاسترجاع', fail == 0)

    # التحقق من المحتوى
    def read_out(rel):
        p = os.path.join(out, rel)
        return open(p, 'rb').read() if os.path.exists(p) else None

    check('LIVE.TXT محتوى صحيح', read_out('LIVE.TXT') == expect['txt1'])
    nested = read_out(os.path.join('SUBDIR', 'NESTED.DAT'))
    check('NESTED.DAT محتوى صحيح', nested == expect['txt2'])
    deleted = [f for f in os.listdir(os.path.join(out, '$LostFiles'))
               if f.endswith('.TXT')]
    check('الملف المحذوف استُرجع', len(deleted) == 1, str(deleted))
    if deleted:
        d = read_out(os.path.join('$LostFiles', deleted[0]))
        check('محتوى الملف المحذوف صحيح', d == expect['dtext'])
    carved_png = [f for f in os.listdir(os.path.join(out, '$LostFiles'))
                  if f.endswith('.png')]
    if carved_png:
        cp = read_out(os.path.join('$LostFiles', carved_png[0]))
        check('PNG محفور مطابق', cp == expect['png'],
              f'{len(cp or b"")} vs {len(expect["png"])}')
    carved_zip = [f for f in os.listdir(os.path.join(out, '$LostFiles'))
                  if f.endswith('.zip')]
    if carved_zip:
        cz = read_out(os.path.join('$LostFiles', carved_zip[0]))
        # ZIP المدفون يُكتشف حتى لو حشوة بعده: نفحص EOCD صالح
        check('ZIP محفور قابل للفتح',
              cz and cz[:4] == b'PK\x03\x04'
              and b'inside.txt' in cz)

    eng.close()

    print('\n=== النتيجة: ' +
          ('كل الاختبارات ناجحة' if not FAILED else
           f'فشل {len(FAILED)}: {FAILED}') + ' ===')
    print(f'مجلد الاختبار (للمعاينة اليدوية): {tmp}')
    return 0 if not FAILED else 1


if __name__ == '__main__':
    sys.exit(main())