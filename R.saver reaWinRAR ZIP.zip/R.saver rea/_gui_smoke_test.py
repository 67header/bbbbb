"""اختبار دخان 2: عرض كل الشجرة (الأقراص داخل الفئات)"""
import sys
sys.stdout.reconfigure(encoding='utf-8')
from minisaver.core.disk import list_sources

srcs = list_sources()
print('list_sources ->', len(srcs))
for s in srcs:
    print(' ', s['kind'], s['path'], s['size'])

import tkinter as tk
import minisaver.gui as g
root = tk.Tk()
root.after(1200, root.destroy)
w = g.Wizard(root)
w.show('disksel')
def dump(item=''):
    kids = w.dtree.get_children(item)
    for k in kids:
        print('  tree:', w.dtree.item(k)['text'], w.dtree.item(k)['values'])
        dump(k)
dump()
try:
    root.mainloop()
    print('GUI OK')
except Exception as e:
    print('FAIL', e); sys.exit(1)