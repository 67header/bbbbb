# -*- coding: utf-8 -*-
"""توليد minisaver/lang.py من langs/all_langs.json (RU) + ترجمة EN يدوية"""
import json, re, sys
sys.stdout.reconfigure(encoding='utf-8')

packs = json.load(open('langs/all_langs.json', encoding='utf-8'))

def norm(s):
    return s.replace('\r\n', '\n').replace('\r', '\n')

def clean_table(table):
    out = {}
    for k, v in table.items():
        key = k.replace('\x00', '').strip()
        if key.startswith('rxw::'):
            out[key.split('::', 1)[1]] = [norm(s) for s in v]
    return out

ru = clean_table(packs['RUS_5_19381_19381'])

en = {
 'splash': [
  "Welcome to the R.saver Assistant!",
  "-",
  "I have read and understood the information above",
  "Do not show me this information again",
  "Let's get started "],
 'disksel': [
  "Choose storage containing your data",
  "-",
  "Please wait a few seconds while we detect devices...",
  "Logical volumes",
  "Physical disks",
  "Comprehensive storages (RAID)",
  "Virtual and file-based storages",
  "Continue",
  "Disk %d",
  "Disk %c:",
  "%d MB",
  "%d GB",
  "%.1f TB",
  "Unknown format",
  "Composed volume",
  "RAID array level %d",
  "Composed volume (RAID array)",
  "Software license",
  "Configuration and settings",
  "What to do on this page",
  "Refresh list",
  "Where is my disk?",
  "Close Assistant",
  "Open existing file system (skip scanning if possible)",
  "The selected storage or partition does not contain a file system. Do you want to start scanning?"],
 'partsel': [
  "Choose a storage partition with your data",
  "-",
  "Back",
  "Software license",
  "Configuration and settings",
  "What to do on this page",
  "Start scanning",
  "Ignore these partitions",
  "The size of this storage may have been determined incorrectly: size %s was determined, while %s was expected.",
  "%.1f TB",
  "Are you sure you want to continue with this storage component?\nThis component is part of a RAID array. For correct file system reconstruction it is REQUIRED to recover data from the entire RAID array!\nRecovering data from a separate RAID array component will most likely NOT give any useful result.",
  "Close Assistant",
  "Open existing file system (skip scanning if possible)"],
 'partbar': [
  "%d MB", "%d GB", "%.1f TB", "Unknown format"],
 'partprop': [
  "Unknown/damaged volume or RAID component",
  "%s volume",
  "Partition size %s",
  "Starts at %s",
  "Not damaged",
  "Invalid root folder",
  "No files available",
  "Damaged root folder",
  "No file system",
  "File system is not readable",
  "The partition extends beyond this storage: is this storage part of a RAID array?",
  "The partition starts beyond this storage: is this storage part of a RAID array?",
  "The partition is a component of a RAID array"],
 'scan': [
  "Analyzing storage contents…",
  "-",
  "Back",
  "Skip",
  "Software license",
  "What to do on this page",
  "Analyzing the location of available files",
  "Searching for lost data",
  "Extending the virtual file system",
  "Processing special data types and special places",
  "Are you sure you want to interrupt the analysis?\nScanning will be interrupted and you will return to storage selection.\nInformation already found by the program will not be saved.",
  "Are you sure you want to interrupt the analysis?\nThe reconstruction result may be incomplete.",
  "Are you sure you want to interrupt this analysis and close the Assistant?"],
 'progl': [
  "Current operation is in progress",
  "%.1f%%. Elapsed time: %02d:%02d:%02d",
  "%.1f%%. Elapsed: %02d:%02d:%02d. Estimated time remaining: %02d:%02d:%02d"],
 'sett': [
  "File name encodings for:",
  "File names of legacy Windows OS",
  "DOS file systems",
  "Linux/Unix file systems",
  "Re-encode UTF-16 (Linux/Unix)",
  "Yes",
  "No ",
  "Which files to search",
  "Search",
  "Skip",
  "Lost and deleted files",
  "From the Recycle Bin",
  "By known content",
  "Small (floppy) file systems",
  "If there are no user files ",
  "Why are these settings needed?"],
 'explorer': [
  "Choose files and folders to recover",
  "-",
  "Back to storage selection",
  "Recover the selected",
  "Are you sure you want to return to the previous step?\nThe reconstruction result will be lost.",
  "Software license",
  "What to do on this page",
  "Current file system (%s volume)",
  "%s (%s volume)",
  "%d KB",
  "%d MB",
  "%.1f GB",
  "Found files (%s, %s, %lld files)",
  "%s (%s, %s, %lld files)",
  "Additionally found files",
  "Folder",
  "File",
  "Archive",
  "Audio file",
  "Document",
  "Executable file",
  "Image",
  "Video file",
  "This folder is empty",
  "Previous folder",
  "Enter the name of the file you are looking for here",
  "No files or folders found",
  "Search result",
  "Found \u201c%s\u201d",
  "Select all",
  "Deselect all",
  "Change file name encoding",
  "-", "-", "-", "-",
  "Are you sure you want to close the Assistant?\nCheck that all the data you were looking for has been copied. After the window is closed, the reconstruction result will be lost.",
  "Close Assistant",
  "Lost files",
  "Available files",
  "All files"],
 'cpdef': [
  "Choose where to save the data being recovered",
  "-",
  "Back to file selection",
  "Start recovery",
  "Software license",
  "What to do on this page",
  "Building the list of suitable storages...",
  "Selected for recovery:",
  "number of files: %lld",
  "total size: %s",
  "%d KB",
  "%d MB",
  "%.1f GB",
  "Data cannot be copied due to missing licenses:",
  "Some data cannot be copied due to missing licenses:",
  "General software license",
  "RAID array recovery support",
  "Support for basic Linux OS file systems ",
  "Support for Mac OS file systems",
  "ReFS file system support ",
  "XFS file system support ",
  "(required to copy all files)",
  "(required to copy %lld files with total size %s)",
  "However, it is possible to copy %lld files (%s).",
  "Order this license",
  "Order these licenses",
  "The recovered data will be saved to the folder:",
  " ",
  "located in the root of the volume selected from the list:",
  "Refresh list",
  "Other places",
  "Recovered",
  "The destination folder will be used or created under \u201c%s\u201d",
  "Refresh list",
  "Choose another place to save",
  "Choose the destination",
  "Are you REALLY sure you want to choose this place?\nThe destination appears to be the same as the source.\nIf you are recovering DELETED data, saving files to the same place will lead to \nPERMANENT LOSS OF DATA BEFORE RECOVERY.",
  "Do you really want to use this place?\nThis place is not suitable for saving your data because:\n%s.",
  "This place cannot be used to save the selected data.\nThe reason is insufficient space to store the selected files or the storage is in \"read only\" mode.",
  "Cannot create the destination folder!\nCheck write permissions for the destination and try again.\nYou can also use another place or another folder name.",
  "Cannot create the destination folder!\nAnother object with the same name as the destination folder exists.\nYou need to choose another place or another folder name.",
  "Are you sure you want to close the Assistant?\nCheck that all the data you were looking for has been copied. After the window is closed, the reconstruction result will be lost.",
  "Close Assistant",
  "-",
  "General software license"],
 'targetbar': [
  "%d KB available",
  "%d MB available",
  "%.1f GB available",
  "Not enough free space to store all selected files",
  "No space to store all selected files. Some of them also exceed the storage file size limits",
  "Some of the selected files cannot be saved due to storage file size limits",
  "Other places"],
 'copying': [
  "Recovering the selected files",
  "-",
  "Back to file selection",
  "Finish",
  "What to do on this page",
  "Are you sure you want to close the Assistant?\nCheck that all the data you were looking for has been copied. After the window is closed, the reconstruction result will be lost.",
  "Do you really want to interrupt file copying and return to the file selection window?",
  "Files are being extracted from \u201c%s\u201d and saved to \u201c%s\u201d...",
  "No data selected for recovery",
  "Save log",
  "HTML documents",
  "Save dialog file as...",
  "Are you sure you want to overwrite this file?",
  "Objects with this name already exist.",
  "Cannot create the destination file!",
  "Cannot write to the destination file!",
  "Data recovery report",
  "Created with:",
  "Date:",
  "Go to the recovered data",
  "Stop",
  "Do you really want to interrupt file copying?"],
 'gen': ["Step %d.", "The data recovery process is complete"],
 'nodata': [
  "No files selected!",
  "No files are currently selected for recovery. You need to return to the file list and select all or individual files that you plan to recover.\n\nThe program will not recover empty folders that may have been selected for this recovery."],
 'nodisk': [
  "No storages detected!",
  "The program finished detecting disks and found no storages. Apparently, the program needs to be restarted with Administrator rights.\n\nAccess to some logical volumes may not require Administrator rights. In this case, make sure the volume is properly mounted and that your operating system has installed all the necessary drivers for it."],
 'nofile': [
  "No files found!",
  "The program could not find files on the storage being scanned. Apparently, the data you are looking for is located on a different storage. If so, return to the storage selection and choose a different storage or partition to scan.\n\nIn general, it is recommended to:\n - make sure the program has finished scanning;\n - try selecting a different partition or ignore the storage partitions altogether;\n - try searching for data on a different storage."],
 'preview': [
  "Modified: %s", "Size: %s", "%d bytes", "%d KB", "%d MB", "%.1f GB",
  "File", "Archive", "Audio file", "Document", "Executable file",
  "Image", "Video file", "View", "Save as..."],
 'hybridview': [
  "[Object contents]", "This file is empty", "This file cannot be opened",
  "Visualization", "Text mode", "Hexadecimal mode"],
 'fnenc': ["Choose encoding", "OK", "Cancel"],
 'lic': [
  "No active licenses", "These licenses are active:", "Add license",
  "User agreement", "Software licensing options",
  "General software license", "RAID array recovery support",
  "Support for major Linux/Unix systems", "Support for Mac OS file systems",
  "XFS file system support", "Activate new license",
  "This file cannot be saved due to missing licenses:\n - %s;\n - %s;\n - %s.\n\nDo you want to order these licenses now?",
  "This file cannot be saved due to missing licenses:\n - %s;\n - %s.\n\nDo you want to order these licenses now?",
  "This file cannot be saved due to missing \"%s\".\nDo you want to order this license now?",
  "All files", "Save this file as...",
  "Do you want to overwrite the existing file?",
  "An object with this name already exists!", "General software license"],
 'licw': [
  "Registration name:", "Registration code:", "Apply license",
  "Licensing options", "License agreement",
  "Do you really want to deactivate this license?", "-",
  "Thank you for activating the license!", "Enter your name here",
  "This license has already been activated.", "Software ID:",
  "Buy license", "-", "-",
  "The General software license is not active!\nActivate the General license before activating this license."],
 'licwd': [
  "Software license information", "License type", "Personal (single user)",
  "Commercial (1 seat)", "Corporate (10 seats)", "Unknown",
  "Updates expire", "Never", "Government (1 seat)", "Academic"],
 'licwe': [
  "License Manager", "OK", "Registration code not accepted",
  "Please make sure that the registration code is copied as is, with all dashes, preserving letter case. Also make sure that the registration code is issued specifically for this version and edition of the software.",
  "Resolve registration problems online"],
}

# التحقق من تطابق الأطوال
missing = [k for k in ru if k not in en]
extra = [k for k in en if k not in ru]
bad_len = [k for k in ru if k in en and len(ru[k]) != len(en[k])]
if missing or extra or bad_len:
    print('RU missing in EN:', missing)
    print('EN extra:', extra)
    print('len mismatch:', [(k, len(ru[k]), len(en[k])) for k in bad_len])

LANGS = {'ru': ru, 'en': en}

header = '''# -*- coding: utf-8 -*-
"""MiniSaver / R.saver - حزم النصوص المستخرجة من r.saver64.exe

الروسية: مستخرجة حرفياً من الحزمة RUS_5_19381 (أقسام rxw:: - معالج الاسترجاع).
الإنجليزية: ترجمة مطابقة لنفس القوالب.
الاستخدام:
    from .lang import T
    T('disksel', 3)            -> 'Логические тома'
    T('disksel', 9, 'D')       -> 'Диск D:'
    set_lang('en')
"""
'''

body = 'LANG = \'ru\'\n\nSTRINGS = ' + json.dumps(LANGS, ensure_ascii=False,
      indent=1).replace('\\r\\n', '\\n')

footer = '''

def set_lang(code):
    global LANG
    if code in STRINGS:
        LANG = code


def get_lang():
    return LANG


def available_langs():
    return sorted(STRINGS)


def _fmt(s, args):
    """تنسيق يحافظ على متطابقات مثل %lld و%.01f"""
    if not args:
        return s
    try:
        return s % args
    except (TypeError, ValueError):
        return s


def T(section, idx=0, *args):
    """جلب نص من القسم الحالي بلغة الواجهة مع تنسيق اختياري"""
    table = STRINGS.get(LANG) or STRINGS['ru']
    sec = table.get(section) or STRINGS['ru'].get(section) or []
    if idx >= len(sec):
        sec_ru = STRINGS['ru'].get(section) or []
        if idx < len(sec_ru):
            return _fmt(sec_ru[idx], args)
        return ''
    return _fmt(sec[idx], args)


def section(section):
    """كل نصوص القسم باللغة الحالية"""
    table = STRINGS.get(LANG) or STRINGS['ru']
    return table.get(section) or STRINGS['ru'].get(section) or []
'''

with open('minisaver/lang.py', 'w', encoding='utf-8', newline='\n') as f:
    f.write(header + body + footer)

print('lang.py written:',
      {k: len(v) for k, v in LANGS.items()})
