"""MiniSaver - واجهة سطر الأوامر

أمثلة:
  python -m minisaver --list
  python -m minisaver --source D:\\out.img --output ./recovered --carve
  python -m minisaver --source \\\\.\\D: --output ./rec --deep --carve
"""
import os
import sys
import time

from minisaver.core.disk import list_sources, is_admin
from minisaver.core.util import human_size
from minisaver.engine import ScanEngine

USAGE = r"""MiniSaver v1.0 - أداة استرجاع البيانات

الاستخدام:
  python -m minisaver --list                          عرض الأقراص المتاحة
  python -m minisaver --source PATH --output DIR [خيارات]

الخيارات:
  --source PATH    مصدر: صورة قرص (.img/.dd/.raw...) أو \\.\D: أو \\.\PhysicalDrive0
  --output DIR     مجلد الإخراج (افتراضي: ./MiniSaver_Output)
  --deep           فحص عميق إضافي (exFAT deep scan)
  --carve          حفر بالتواقيع في المساحة الحرة (JPEG/PNG/ZIP/MP4...)
  --list           عرض الأقراص والصور المتاحة ثم الخروج
  --no-admin       عدم طلب صلاحيات المدير (لصور الملفات)
  --gui            فتح الواجهة الرسومية
"""


def cli_main(argv):
    args = {'source': None, 'output': 'MiniSaver_Output',
            'deep': False, 'carve': False, 'list': False}
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ('-h', '--help'):
            print(USAGE)
            return 0
        if a == '--list':
            args['list'] = True
        elif a == '--deep':
            args['deep'] = True
        elif a == '--carve':
            args['carve'] = True
        elif a == '--source' and i + 1 < len(argv):
            i += 1
            args['source'] = argv[i]
        elif a == '--output' and i + 1 < len(argv):
            i += 1
            args['output'] = argv[i]
        else:
            print(f'خيار غير معروف: {a}')
            print(USAGE)
            return 2
        i += 1

    if args['list']:
        _print_sources()
        return 0

    if not args['source']:
        print(USAGE)
        return 2

    return _run_scan(args['source'], args['output'],
                     deep=args['deep'], carve=args['carve'])


def _print_sources():
    admin = is_admin()
    print(f'الأقراص المتاحة (صلاحيات مدير: {"نعم" if admin else "لا"})\n')
    print(f'{"المسار":<28}{"النوع":<12}{"الحجم":<12}{"القطاع"}')
    print('-' * 64)
    for s in list_sources():
        kind = {'physical': 'فيزيائي', 'logical': 'منطقي'}.get(
            s['kind'], s['kind'])
        print(f"{s['path']:<28}{kind:<12}"
              f"{human_size(s['size']):<12}{s['sector']}")
    print('\nلصور الملفات مرر المسار مباشرة: --source C:\\path\\disk.img')


def _run_scan(source, output, deep=False, carve=False):
    t0 = time.time()
    print(f'MiniSaver - المصدر: {source}')
    eng = ScanEngine(source, progress=_cli_progress)
    try:
        eng.open()
    except OSError as e:
        print(f'خطأ في فتح المصدر: {e}')
        if not is_admin():
            print('ملاحظة: قراءة الأقراص الخام تتطلب تشغيل البرنامج '
                  'بصلاحيات المدير (أو استخدم --no-admin مع صورة ملف).')
        return 1

    try:
        vols = eng.discover()
        print(f'\nالفوليومات المكتشفة: {len(vols)}')
        for v in vols:
            print(f'  - {v.describe()}')
        live, lost = eng.scan(deep=deep, carve=carve)
    finally:
        pass

    print(f'\nالنتائج: {len(live)} ملف سليم، {len(lost)} محذوف/محفور')
    print(f'كتابة الملفات إلى: {os.path.abspath(output)}')
    ok, fail, written = eng.recover(lost + live, output,
                                    progress=_cli_progress)
    # ملاحظة: نكتب المحذوف أولاً (أهمية أعلى) ثم السليم؛ التكرار يُرقّم تلقائياً
    dt = time.time() - t0
    print(f'\nتم: نجاح {ok}، فشل {fail}، {human_size(written)} '
          f'في {dt:.1f} ثانية')
    eng.close()
    return 0


def _cli_progress(stage, done, total, msg):
    if stage in ('mft', 'carve', 'deep', 'orphans') and total:
        pct = 100 * done // max(1, total)
        sys.stdout.write(f'\r  [{stage}] {pct:3d}%  {msg:<50}')
        sys.stdout.flush()
        if done >= total:
            sys.stdout.write('\n')
    else:
        print(f'  [{stage}] {msg}')
