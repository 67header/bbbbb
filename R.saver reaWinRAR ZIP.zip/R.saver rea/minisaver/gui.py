# -*- coding: utf-8 -*-
"""MiniSaver - R.saver 6.9.5 User Interface Implementation

Step 1: Choose storage containing your data (Logical volumes & Physical disks)
Full recovery wizard:
  disksel -> partsel -> scan -> explorer -> cpdef -> copying -> done
Fully supports Arabic, English and Russian interfaces.
"""
import os
import sys
import time
import queue
import threading
import datetime
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

from .core.disk import list_sources, is_admin, relaunch_as_admin
from .core.util import human_size
from .engine import ScanEngine
from . import lang
from . import icons

APP_TITLE = 'R.saver - version 6.9.5'

# Theme Palette matching R.saver 6.9.5
C_WIN_BG = '#FFFFFF'
C_HEADER_BG = '#FFFFFF'
C_TITLE = '#203A58'
C_SUBTITLE = '#5C7186'
C_BAR_BG = '#EDF2F7'
C_BAR_BORDER = '#D6E0EA'
C_TAB_ACTIVE = '#203A58'
C_TAB_INACTIVE = '#697B8E'
C_ACCENT_RED = '#E04A3A'
C_ORANGE = '#D9532F'
C_SIDE_TEXT = '#4A5568'
C_FOOTER_BG = '#27496D'
C_FOOTER_BTN_BG = '#325C8A'
C_FOOTER_BTN_BORDER = '#5682B2'
C_CARD_BG = '#FFFFFF'
C_CARD_BORDER = '#D8E2EC'
C_CARD_HOVER_BG = '#F6F9FD'
C_CARD_SEL_BG = '#EDF4FE'
C_CARD_SEL_BORDER = '#1A73E8'


def fmt_size(n):
    kb, mb, gb, tb = 1024, 1024**2, 1024**3, 1024**4
    if n >= tb:
        return f'{round(n / tb, 1)} TB'
    if n >= gb:
        return f'{n // gb} GB'
    if n >= mb:
        return f'{n // mb} MB'
    return f'{n} B'


class Wizard:
    """R.saver 6.9.5 Multi-step Data Recovery Wizard"""

    def __init__(self, root):
        self.root = root
        root.title(APP_TITLE)
        root.geometry('1020x680')
        root.minsize(900, 600)
        root.configure(bg=C_WIN_BG)

        self.engine = None
        self.worker = None
        self.cancel_event = threading.Event()
        self.uiq = queue.Queue()
        self.current = None

        # Data state
        self.selected_source = None
        self.volumes = []
        self.live, self.lost = [], []
        self.scan_volumes = None
        self.recover_items = []
        self.opt_lost = tk.BooleanVar(value=True)
        self.opt_recy = tk.BooleanVar(value=False)
        self.opt_carve = tk.BooleanVar(value=False)
        self.checks = {}
        self.i2item = {}
        self.target_dir = None
        self.report_html = None

        # Disksel tab: 'logical' or 'physical'
        self.current_disksel_tab = 'logical'
        self.card_widgets = []
        self._selected_card_path = None

        self._build_chrome()
        self.show('disksel')
        self._poll()

    # ---------- Chrome: Header, Stepper, Content, Footer ----------

    def _build_chrome(self):
        # 1. Header Frame
        self.head_frame = tk.Frame(self.root, bg=C_HEADER_BG, height=64)
        self.head_frame.pack(fill='x', padx=20, pady=(10, 0))

        # Title container
        title_box = tk.Frame(self.head_frame, bg=C_HEADER_BG)
        title_box.pack(side='left', fill='both', expand=True)

        self.title_var = tk.StringVar(value='Step 1. Choose storage containing your data')
        self.title_lbl = tk.Label(
            title_box, textvariable=self.title_var, bg=C_HEADER_BG, fg=C_TITLE,
            font=('Segoe UI', 14, 'bold'), anchor='w'
        )
        self.title_lbl.pack(anchor='w', pady=(4, 0))

        # Top Right Circular Buttons & Quick Language Switcher
        act_box = tk.Frame(self.head_frame, bg=C_HEADER_BG)
        act_box.pack(side='right', pady=(4, 0))

        # Quick Language Toggle button (العربية / English)
        cur_lang = lang.get_lang()
        btn_lang_text = 'English' if cur_lang == 'ar' else 'العربية'
        self.btn_lang_toggle = tk.Button(
            act_box, text=f'🌐 {btn_lang_text}', bg='#EDF2F7', fg=C_TITLE,
            activebackground='#CBD5E1', font=('Segoe UI', 9, 'bold'),
            bd=1, relief='solid', padx=8, pady=2, cursor='hand2',
            command=self._quick_toggle_lang
        )
        self.btn_lang_toggle.pack(side='left', padx=(0, 10))

        self.icon_profile = icons.get_tk_image('btn_profile', (28, 28))
        self.icon_gear = icons.get_tk_image('btn_gear', (28, 28))
        self.icon_help = icons.get_tk_image('btn_help', (28, 28))

        self.btn_profile = tk.Label(act_box, image=self.icon_profile, bg=C_HEADER_BG, cursor='hand2')
        self.btn_profile.pack(side='left', padx=4)
        self.btn_profile.bind('<Button-1>', lambda e: self._on_about())

        self.btn_gear = tk.Label(act_box, image=self.icon_gear, bg=C_HEADER_BG, cursor='hand2')
        self.btn_gear.pack(side='left', padx=4)
        self.btn_gear.bind('<Button-1>', lambda e: self._settings_dialog())

        self.btn_help = tk.Label(act_box, image=self.icon_help, bg=C_HEADER_BG, cursor='hand2')
        self.btn_help.pack(side='left', padx=4)
        self.btn_help.bind('<Button-1>', lambda e: self._on_help())

        # 2. Stepper / Breadcrumbs Bar
        self.stepper_frame = tk.Frame(self.root, bg=C_BAR_BG, height=26)
        self.stepper_frame.pack(fill='x', pady=(6, 0))
        tk.Frame(self.root, bg=C_BAR_BORDER, height=1).pack(fill='x')

        self.stepper_canvas = tk.Canvas(self.stepper_frame, bg=C_BAR_BG, height=26, bd=0, highlightthickness=0)
        self.stepper_canvas.pack(fill='both', expand=True)

        # 3. Main Body Container
        self.body = tk.Frame(self.root, bg=C_WIN_BG)
        self.body.pack(fill='both', expand=True)

        # 4. Bottom Footer Bar (Slate Navy)
        self.footer = tk.Frame(self.root, bg=C_FOOTER_BG, height=52)
        self.footer.pack(fill='x', side='bottom')

        self.footer_left = tk.Frame(self.footer, bg=C_FOOTER_BG)
        self.footer_left.pack(side='left', padx=18, pady=8)

        self.icon_refresh = icons.get_tk_image('btn_refresh', (20, 20))
        self.icon_close = icons.get_tk_image('btn_close', (20, 20))

        # Refresh button
        self.f_btn_refresh = tk.Button(
            self.footer_left, image=self.icon_refresh, text=' ' + self._t_rsaver('btn_refresh', 'Refresh list'),
            compound='left', bg=C_FOOTER_BG, fg='#FFFFFF', activebackground='#355B82', activeforeground='#FFFFFF',
            bd=0, font=('Segoe UI', 9), cursor='hand2', padx=8, pady=4, command=self._on_refresh_click
        )
        self.f_btn_refresh.pack(side='left', padx=(0, 16))

        # Close Assistant button
        self.f_btn_close = tk.Button(
            self.footer_left, image=self.icon_close, text=' ' + self._t_rsaver('btn_close', 'Close Assistant'),
            compound='left', bg=C_FOOTER_BG, fg='#FFFFFF', activebackground='#355B82', activeforeground='#FFFFFF',
            bd=0, font=('Segoe UI', 9), cursor='hand2', padx=8, pady=4, command=self._on_close_click
        )
        self.f_btn_close.pack(side='left')

        # Footer Right: Continue button
        self.footer_right = tk.Frame(self.footer, bg=C_FOOTER_BG)
        self.footer_right.pack(side='right', padx=18, pady=8)

        self.btn_continue = tk.Button(
            self.footer_right, text=self._t_rsaver('btn_continue', 'Continue') + '  ▶',
            bg=C_FOOTER_BTN_BG, fg='#FFFFFF', activebackground='#4374A7', activeforeground='#FFFFFF',
            font=('Segoe UI', 10, 'bold'), padx=24, pady=5, bd=1, relief='raised',
            cursor='hand2', command=self._on_continue_click
        )
        self.btn_continue.pack(side='right')

    def _quick_toggle_lang(self):
        cur = lang.get_lang()
        new_lang = 'en' if cur == 'ar' else 'ar'
        lang.set_lang(new_lang)
        self._update_all_labels()

    def _update_all_labels(self):
        cur = lang.get_lang()
        btn_lang_text = 'English' if cur == 'ar' else 'العربية'
        self.btn_lang_toggle.configure(text=f'🌐 {btn_lang_text}')
        self._update_footer_labels()
        self.show(self.current)

    def _t_rsaver(self, key, fallback=''):
        table = lang.section('rsaver')
        if isinstance(table, dict) and key in table:
            return table[key]
        return fallback

    def _draw_stepper(self, active_step=1):
        self.stepper_canvas.delete('all')
        w = self.stepper_canvas.winfo_width()
        if w < 100:
            w = 1000
        steps = self._t_rsaver('step_crumbs', [
            '1: Storage', '2: Partition', '3: Scan', '4: Select Files', '5: Destination', '6: Recover'
        ])
        num = len(steps)
        step_w = w / num
        for i, s in enumerate(steps):
            x1 = i * step_w
            x2 = (i + 1) * step_w
            is_active = (i + 1 == active_step)
            is_past = (i + 1 < active_step)

            bg_c = '#E2EAF2' if is_active else C_BAR_BG
            fg_c = '#1A538C' if is_active else ('#334155' if is_past else '#7B8E9F')
            font = ('Segoe UI', 8, 'bold' if is_active else 'normal')

            self.stepper_canvas.create_rectangle(x1, 0, x2, 26, fill=bg_c, outline='')
            if is_active:
                self.stepper_canvas.create_rectangle(x1, 23, x2, 26, fill=C_ACCENT_RED, outline='')

            self.stepper_canvas.create_text(
                x1 + step_w / 2, 13, text=s, fill=fg_c, font=font
            )
            if i < num - 1:
                self.stepper_canvas.create_line(x2, 4, x2, 22, fill=C_BAR_BORDER)

    def _poll(self):
        try:
            while True:
                fn = self.uiq.get_nowait()
                try:
                    fn()
                except Exception as ex:
                    print(f"Error executing UI callback: {ex}")
        except queue.Empty:
            pass
        except Exception as e:
            print(f"Queue poll error: {e}")
        finally:
            self.root.after(80, self._poll)

    def _clear_body(self):
        for w in self.body.winfo_children():
            w.destroy()

    def show(self, page):
        self._clear_body()
        self.current = page
        step_map = {
            'disksel': 1, 'partsel': 2, 'scan': 3, 'scan_direct': 3,
            'explorer': 4, 'cpdef': 5, 'copying': 6, 'done': 6
        }
        active_step = step_map.get(page, 1)
        self.root.update_idletasks()
        self._draw_stepper(active_step)

        # Update title text
        is_ar = lang.get_lang() == 'ar'
        step_prefix = f'الخطوة {active_step}: ' if is_ar else f'Step {active_step}. '
        titles = {
            'disksel': self._t_rsaver('step1_title', 'Step 1. Choose storage containing your data'),
            'partsel': step_prefix + lang.T('partsel', 0),
            'scan': step_prefix + lang.T('scan', 0),
            'scan_direct': step_prefix + lang.T('scan', 0),
            'explorer': step_prefix + lang.T('explorer', 0),
            'cpdef': step_prefix + lang.T('cpdef', 0),
            'copying': step_prefix + lang.T('copying', 0),
            'done': step_prefix + (lang.T('gen', 1) or 'Data Recovery Completed')
        }
        self.title_var.set(titles.get(page, APP_TITLE))

        if page == 'disksel':
            self.footer.pack(fill='x', side='bottom')
            self._page_disksel()
        else:
            getattr(self, '_page_' + page)()

    # ---------- Dialogs & Header Actions ----------

    def _on_about(self):
        win = tk.Toplevel(self.root)
        is_ar = lang.get_lang() == 'ar'
        win.title('حول R.saver' if is_ar else 'About R.saver')
        win.geometry('440x300')
        win.resizable(False, False)
        win.configure(bg='#FFFFFF')
        win.transient(self.root)
        win.grab_set()

        tk.Label(win, text='R.saver', font=('Segoe UI', 18, 'bold'), fg=C_TITLE, bg='#FFFFFF').pack(pady=(20, 2))
        tk.Label(win, text='Version 6.9.5', font=('Segoe UI', 10), fg='#64748B', bg='#FFFFFF').pack(pady=(0, 10))

        info_text = (
            "أداة احترافية لاسترجاع البيانات والملفات المحذوفة والمفقودة\n"
            "من وسائط التخزين المختلفة: فلاش USB، الأقراص الصلبة وSSD.\n\n"
            "تدعم أنظمة الملفات NTFS, FAT32, FAT16, exFAT\n"
            "مع الحفر المتطور بالتواقيع (Signature Carving).\n\n"
            "الواجهة تدعم العربية والإنجليزية والروسية بالكامل."
            if is_ar else
            "Professional data recovery utility designed to restore lost,\n"
            "deleted, and carved files from storage devices:\n"
            "USB Flash Drives, HDD, SSD, and Disk Images.\n\n"
            "Supports NTFS, FAT12/16/32, and exFAT file systems\n"
            "with advanced signature carving."
        )
        tk.Label(win, text=info_text, font=('Segoe UI', 9), justify='center', bg='#FFFFFF', fg='#334155').pack(padx=20, pady=10)
        close_btn_txt = 'إغلاق' if is_ar else 'Close'
        tk.Button(win, text=close_btn_txt, command=win.destroy, width=12, bg='#2B5885', fg='#FFFFFF', font=('Segoe UI', 9, 'bold')).pack(pady=12)

    def _on_help(self):
        is_ar = lang.get_lang() == 'ar'
        title = 'تعليمات R.saver' if is_ar else 'R.saver Help'
        msg = (
            "دليل الاستخدام السريع:\n\n"
            "1. اختر نوع وحدة التخزين من التبويب (أقراص منطقية أو أقراص فيزيائية).\n"
            "2. حدد القرص أو فلاش USB المطلوب استرجاع ملفاته.\n"
            "3. اضغط «متابعة» للبدء في تحليل نظام الملفات والبحث عن المحذوفات.\n"
            "4. في نافذة النتائج، حدد الملفات أو المجلدات المطلوبة ثم اضغط استرجاع.\n"
            "5. اختر مجلد حفظ على قرص آخر مختلف عن القرص المصدر.\n\n"
            "نصيحة: يمكنك أيضاً الضغط على «+ فتح صورة قرص...» لتحميل ملفات Dump (.img, .iso, .vhd, .dd)."
            if is_ar else
            "How to use R.saver:\n\n"
            "1. Select the storage type (Logical volumes or Physical disks).\n"
            "2. Choose your drive or USB stick containing lost data.\n"
            "3. Click 'Continue' to begin scanning and file discovery.\n"
            "4. Check the files you want to restore in the explorer.\n"
            "5. Select a destination directory on a DIFFERENT drive.\n\n"
            "Tip: You can also click '+ Open Disk Image' to load raw disk dumps (.img, .iso, .vhd, .dd)."
        )
        messagebox.showinfo(title, msg, parent=self.root)

    def _settings_dialog(self):
        win = tk.Toplevel(self.root)
        is_ar = lang.get_lang() == 'ar'
        win.title('الإعدادات واللغة' if is_ar else 'Settings & Language')
        win.geometry('380x250')
        win.resizable(False, False)
        win.transient(self.root)
        win.grab_set()
        win.configure(bg='#FFFFFF')

        cur = lang.get_lang()
        var = tk.StringVar(value=cur)
        tk.Label(
            win, text='اختر لغة الواجهة:' if is_ar else 'Select Interface Language:',
            font=('Segoe UI', 11, 'bold'), fg=C_TITLE, bg='#FFFFFF'
        ).pack(pady=(16, 12))

        names = {
            'ar': 'العربية (Arabic)',
            'en': 'English (United States)',
            'ru': 'Русский (Russian)'
        }
        for code, nm in names.items():
            tk.Radiobutton(win, text=nm, value=code, variable=var, font=('Segoe UI', 10), bg='#FFFFFF', activebackground='#FFFFFF')\
                .pack(anchor='w', padx=50, pady=4)

        def apply():
            if var.get() != cur:
                lang.set_lang(var.get())
            win.destroy()
            self._update_all_labels()

        btn_box = tk.Frame(win, bg='#FFFFFF')
        btn_box.pack(pady=18)
        tk.Button(btn_box, text='تطبيق' if is_ar else 'Apply', command=apply, width=12, bg='#2B5885', fg='#FFFFFF', font=('Segoe UI', 9, 'bold')).pack(side='left', padx=6)
        tk.Button(btn_box, text='إلغاء' if is_ar else 'Cancel', command=win.destroy, width=10, bg='#E2E8F0', font=('Segoe UI', 9)).pack(side='left', padx=6)

    def _update_footer_labels(self):
        self.f_btn_refresh.configure(text=' ' + self._t_rsaver('btn_refresh', 'Refresh list'))
        self.f_btn_close.configure(text=' ' + self._t_rsaver('btn_close', 'Close Assistant'))
        self.btn_continue.configure(text=self._t_rsaver('btn_continue', 'Continue') + '  ▶')

    # ---------- STEP 1: Storage Selection (R.saver 6.9.5 Match) ----------

    def _page_disksel(self):
        self.card_widgets.clear()
        self._selected_card_path = None
        self._update_continue_btn_state()

        # Top sub-bar with Tabs: 'Logical volumes' & 'Physical disks'
        tab_bar = tk.Frame(self.body, bg=C_WIN_BG, height=42)
        tab_bar.pack(fill='x', padx=24, pady=(12, 0))

        # Logical volumes Tab
        self.tab_logical_frame = tk.Frame(tab_bar, bg=C_WIN_BG, cursor='hand2')
        self.tab_logical_frame.pack(side='left', padx=(0, 24))
        self.lbl_tab_logical = tk.Label(
            self.tab_logical_frame, text=self._t_rsaver('tab_logical', 'Logical volumes'),
            bg=C_WIN_BG, fg=C_TAB_ACTIVE if self.current_disksel_tab == 'logical' else C_TAB_INACTIVE,
            font=('Segoe UI', 11, 'bold' if self.current_disksel_tab == 'logical' else 'normal')
        )
        self.lbl_tab_logical.pack(anchor='w')
        self.line_tab_logical = tk.Frame(
            self.tab_logical_frame, bg=C_ACCENT_RED if self.current_disksel_tab == 'logical' else C_WIN_BG,
            height=3
        )
        self.line_tab_logical.pack(fill='x', pady=(4, 0))

        # Physical disks Tab
        self.tab_physical_frame = tk.Frame(tab_bar, bg=C_WIN_BG, cursor='hand2')
        self.tab_physical_frame.pack(side='left')
        self.lbl_tab_physical = tk.Label(
            self.tab_physical_frame, text=self._t_rsaver('tab_physical', 'Physical disks'),
            bg=C_WIN_BG, fg=C_TAB_ACTIVE if self.current_disksel_tab == 'physical' else C_TAB_INACTIVE,
            font=('Segoe UI', 11, 'bold' if self.current_disksel_tab == 'physical' else 'normal')
        )
        self.lbl_tab_physical.pack(anchor='w')
        self.line_tab_physical = tk.Frame(
            self.tab_physical_frame, bg=C_ACCENT_RED if self.current_disksel_tab == 'physical' else C_WIN_BG,
            height=3
        )
        self.line_tab_physical.pack(fill='x', pady=(4, 0))

        # Tab click handlers
        self.tab_logical_frame.bind('<Button-1>', lambda e: self._switch_tab('logical'))
        self.lbl_tab_logical.bind('<Button-1>', lambda e: self._switch_tab('logical'))
        self.tab_physical_frame.bind('<Button-1>', lambda e: self._switch_tab('physical'))
        self.lbl_tab_physical.bind('<Button-1>', lambda e: self._switch_tab('physical'))

        # Content split: Cards Grid vs Guidance Sidebar
        split_frame = tk.Frame(self.body, bg=C_WIN_BG)
        split_frame.pack(fill='both', expand=True, padx=24, pady=(10, 10))

        # Sidebar
        sidebar = tk.Frame(split_frame, bg=C_WIN_BG, width=320)
        sidebar.pack(side='right', fill='y', padx=(20, 0))
        sidebar.pack_propagate(False)

        # Vertical divider
        tk.Frame(split_frame, bg='#E2E8F0', width=1).pack(side='right', fill='y', padx=0)

        # Build Sidebar Content
        self._build_sidebar(sidebar)

        # Left Cards Grid Area
        self.cards_container = tk.Frame(split_frame, bg=C_WIN_BG)
        self.cards_container.pack(side='left', fill='both', expand=True)

        self._render_cards()

    def _switch_tab(self, tab):
        if self.current_disksel_tab == tab:
            return
        self.current_disksel_tab = tab
        if tab == 'logical':
            self.lbl_tab_logical.configure(fg=C_TAB_ACTIVE, font=('Segoe UI', 11, 'bold'))
            self.line_tab_logical.configure(bg=C_ACCENT_RED)
            self.lbl_tab_physical.configure(fg=C_TAB_INACTIVE, font=('Segoe UI', 11, 'normal'))
            self.line_tab_physical.configure(bg=C_WIN_BG)
        else:
            self.lbl_tab_physical.configure(fg=C_TAB_ACTIVE, font=('Segoe UI', 11, 'bold'))
            self.line_tab_physical.configure(bg=C_ACCENT_RED)
            self.lbl_tab_logical.configure(fg=C_TAB_INACTIVE, font=('Segoe UI', 11, 'normal'))
            self.line_tab_logical.configure(bg=C_WIN_BG)

        self._selected_card_path = None
        self.selected_source = None
        self._update_continue_btn_state()
        self._render_cards()

    def _build_sidebar(self, parent):
        box1 = tk.Frame(parent, bg=C_WIN_BG)
        box1.pack(fill='x', pady=(0, 16))

        tk.Label(
            box1, text=self._t_rsaver('how_to_choose_title', 'How to choose correctly'),
            font=('Segoe UI', 10, 'bold'), fg=C_TITLE, bg=C_WIN_BG
        ).pack(anchor='w', pady=(0, 6))

        for p_key, def_txt in [
            ('how_to_choose_p1', 'Selecting a device analyzes the entire drive.'),
            ('how_to_choose_p2', 'When in doubt, choose the physical device.'),
            ('how_to_choose_p3', 'In logical volumes, note size, name, and drive letter.'),
            ('how_to_choose_p4', 'For physical disks, check model, size, and vendor.')
        ]:
            txt = self._t_rsaver(p_key, def_txt)
            tk.Label(
                box1, text=txt, font=('Segoe UI', 8), fg=C_SIDE_TEXT,
                bg=C_WIN_BG, wraplength=300, justify='left'
            ).pack(anchor='w', pady=2)

        # Section 2: FAQ
        box2 = tk.Frame(parent, bg=C_WIN_BG)
        box2.pack(fill='x')

        tk.Label(
            box2, text=self._t_rsaver('faq_title', 'Frequently asked questions:'),
            font=('Segoe UI', 10, 'bold'), fg=C_TITLE, bg=C_WIN_BG
        ).pack(anchor='w', pady=(0, 6))

        faqs = [
            ('faq_q1', 'faq_a1', '• Is data recovery safe?'),
            ('faq_q2', 'faq_a2', '• Why is the disk not listed?'),
            ('faq_q3', 'faq_a3', '• How to recover data from RAID?'),
            ('faq_q4', 'faq_a4', '• Other questions »')
        ]
        for q_key, a_key, def_q in faqs:
            q_txt = self._t_rsaver(q_key, def_q)
            a_txt = self._t_rsaver(a_key, '')
            lbl = tk.Label(
                box2, text=q_txt, font=('Segoe UI', 8), fg='#1A73E8',
                bg=C_WIN_BG, cursor='hand2', justify='left'
            )
            lbl.pack(anchor='w', pady=2)
            lbl.bind('<Button-1>', lambda e, t=q_txt, a=a_txt: self._show_faq_modal(t, a))

    def _show_faq_modal(self, title, text):
        clean_title = title.lstrip('• ').rstrip(' »')
        messagebox.showinfo(clean_title, text, parent=self.root)

    def _render_cards(self):
        for w in self.cards_container.winfo_children():
            w.destroy()
        self.card_widgets.clear()

        canvas = tk.Canvas(self.cards_container, bg=C_WIN_BG, bd=0, highlightthickness=0)
        vs = ttk.Scrollbar(self.cards_container, orient='vertical', command=canvas.yview)
        grid_frame = tk.Frame(canvas, bg=C_WIN_BG)

        grid_frame.bind(
            '<Configure>',
            lambda e: canvas.configure(scrollregion=canvas.bbox('all'))
        )
        canvas.create_window((0, 0), window=grid_frame, anchor='nw')
        canvas.configure(yscrollcommand=vs.set)

        canvas.pack(side='left', fill='both', expand=True)
        vs.pack(side='right', fill='y')

        def _on_wheel(event):
            canvas.yview_scroll(int(-1 * (event.delta / 120)), 'units')
        canvas.bind_all('<MouseWheel>', _on_wheel)

        sources = list_sources()
        if self.current_disksel_tab == 'logical':
            filtered = [s for s in sources if s['kind'] == 'logical']
        else:
            filtered = [s for s in sources if s['kind'] == 'physical']

        img_card_data = {
            'path': 'custom_image',
            'kind': 'image',
            'name': self._t_rsaver('btn_add_image', '+ Open Disk Image...'),
            'label': 'Raw image / ISO / VHD',
            'size': 0
        }
        all_cards = filtered + [img_card_data]

        col_count = 2
        for idx, item in enumerate(all_cards):
            r = idx // col_count
            c = idx % col_count
            self._create_card(grid_frame, item, r, c)

    def _create_card(self, parent, item, r, c):
        card = tk.Frame(
            parent, bg=C_CARD_BG, bd=1, relief='solid',
            padx=10, pady=10, cursor='hand2'
        )
        card.grid(row=r, column=c, padx=10, pady=10, sticky='nsew')
        parent.grid_columnconfigure(c, weight=1, minsize=260)

        if item.get('kind') == 'image':
            tk_img = icons.get_tk_image('disk_image', (56, 56))
        elif item.get('kind') == 'physical':
            tk_img = icons.get_tk_image('hdd_physical', (56, 56))
        elif item.get('drive_type') == 'usb':
            tk_img = icons.get_tk_image('hdd_usb', (56, 56))
        else:
            tk_img = icons.get_tk_image('hdd_win', (56, 56))

        icon_lbl = tk.Label(card, image=tk_img, bg=C_CARD_BG)
        icon_lbl.pack(side='left', padx=(0, 10))

        txt_frame = tk.Frame(card, bg=C_CARD_BG)
        txt_frame.pack(side='left', fill='both', expand=True)

        name_text = item.get('name') or item.get('path')
        label_text = f"{item.get('label', '')} ({item.get('fs', 'RAW')})" if item.get('fs') else item.get('label', '')
        size_val = item.get('size', 0)
        size_text = human_size(size_val) if size_val > 0 else ''

        name_lbl = tk.Label(txt_frame, text=name_text, font=('Segoe UI', 11, 'bold'), fg='#1E293B', bg=C_CARD_BG, anchor='w')
        name_lbl.pack(anchor='w')

        if label_text:
            desc_lbl = tk.Label(txt_frame, text=label_text, font=('Segoe UI', 9), fg='#475569', bg=C_CARD_BG, anchor='w')
            desc_lbl.pack(anchor='w', pady=(1, 0))
        else:
            desc_lbl = None

        if size_text:
            sz_lbl = tk.Label(txt_frame, text=size_text, font=('Segoe UI', 9), fg='#64748B', bg=C_CARD_BG, anchor='w')
            sz_lbl.pack(anchor='w', pady=(1, 0))
        else:
            sz_lbl = None

        all_children = [card, icon_lbl, txt_frame, name_lbl]
        if desc_lbl:
            all_children.append(desc_lbl)
        if sz_lbl:
            all_children.append(sz_lbl)

        card_info = {
            'item': item,
            'card': card,
            'all_widgets': all_children,
            'txt_frame': txt_frame,
            'icon_lbl': icon_lbl,
            'name_lbl': name_lbl,
            'desc_lbl': desc_lbl,
            'sz_lbl': sz_lbl
        }
        self.card_widgets.append(card_info)

        def _on_click(_e=None):
            self._select_card(card_info)

        def _on_dbl_click(_e=None):
            self._select_card(card_info)
            self._on_continue_click()

        def _on_enter(_e=None):
            if self._selected_card_path != item['path']:
                card.configure(bg=C_CARD_HOVER_BG)
                for w in all_children:
                    w.configure(bg=C_CARD_HOVER_BG)

        def _on_leave(_e=None):
            if self._selected_card_path != item['path']:
                card.configure(bg=C_CARD_BG)
                for w in all_children:
                    w.configure(bg=C_CARD_BG)

        for w in all_children:
            w.bind('<Button-1>', _on_click)
            w.bind('<Double-Button-1>', _on_dbl_click)
            w.bind('<Enter>', _on_enter)
            w.bind('<Leave>', _on_leave)

    def _select_card(self, card_info):
        for ci in self.card_widgets:
            ci['card'].configure(bg=C_CARD_BG, highlightthickness=0)
            for w in ci['all_widgets']:
                w.configure(bg=C_CARD_BG)

        self._selected_card_path = card_info['item']['path']
        self.selected_source = card_info['item']

        card_info['card'].configure(bg=C_CARD_SEL_BG, highlightbackground=C_CARD_SEL_BORDER, highlightthickness=2)
        for w in card_info['all_widgets']:
            w.configure(bg=C_CARD_SEL_BG)

        self._update_continue_btn_state()

    def _update_continue_btn_state(self):
        if self.selected_source:
            self.btn_continue.configure(
                state='normal', bg='#1A73E8', cursor='hand2'
            )
        else:
            self.btn_continue.configure(
                state='disabled', bg='#6B8299', cursor='arrow'
            )

    def _on_refresh_click(self):
        self._selected_card_path = None
        self.selected_source = None
        self._update_continue_btn_state()
        self._render_cards()

    def _on_close_click(self):
        is_ar = lang.get_lang() == 'ar'
        msg = 'هل أنت متأكد من رغبتك في إغلاق المساعد؟' if is_ar else 'Are you sure you want to close the Assistant?'
        title = 'تأكيد الإغلاق' if is_ar else 'Confirm Exit'
        if messagebox.askyesno(title, msg, parent=self.root):
            self.root.destroy()

    def _on_continue_click(self):
        if not self.selected_source:
            return

        if self.selected_source['path'] == 'custom_image':
            p = filedialog.askopenfilename(
                parent=self.root,
                filetypes=[
                    ('Disk Images', '*.img *.dd *.raw *.iso *.bin *.vhd *.vhdx *.e01'),
                    ('All Files', '*.*')
                ]
            )
            if not p:
                return
            sz = 0
            try:
                sz = os.path.getsize(p)
            except OSError:
                pass
            self.selected_source = {
                'path': p, 'kind': 'image', 'size': sz, 'sector': 512,
                'name': os.path.basename(p), 'label': 'Disk Image'
            }

        self.footer.pack_forget()
        if self.selected_source.get('kind') == 'logical':
            self.volumes = []
            self.show('scan_direct')
        else:
            self.show('partsel')

    # ---------- STEP 2: Partition Selection ----------

    def _page_partsel(self):
        is_ar = lang.get_lang() == 'ar'
        self.status_var = tk.StringVar(value='جاري البحث عن الأقسام...' if is_ar else 'Searching partitions...')

        wrap = tk.Frame(self.body, bg=C_WIN_BG)
        wrap.pack(fill='both', expand=True, padx=20, pady=14)

        heading_txt = (
            'اختر القسم المراد مسحه من هذا الجهاز:' if is_ar else
            'Select the partition to scan from this device:'
        )
        tk.Label(
            wrap, text=heading_txt,
            font=('Segoe UI', 11, 'bold'), fg=C_TITLE, bg=C_WIN_BG
        ).pack(anchor='w', pady=(0, 8))

        cols = ('size', 'fs', 'state')
        self.ptree = ttk.Treeview(wrap, columns=cols, show='tree headings', selectmode='browse', height=10)
        self.ptree.heading('#0', text='القسم' if is_ar else 'Partition')
        self.ptree.heading('size', text='الحجم' if is_ar else 'Size')
        self.ptree.heading('fs', text='نظام الملفات' if is_ar else 'File System')
        self.ptree.heading('state', text='الحالة' if is_ar else 'Status')
        self.ptree.column('#0', width=340)
        self.ptree.column('size', width=120, anchor='e')
        self.ptree.column('fs', width=120)
        self.ptree.column('state', width=180)

        vs = ttk.Scrollbar(wrap, orient='vertical', command=self.ptree.yview)
        self.ptree.configure(yscrollcommand=vs.set)
        self.ptree.pack(side='left', fill='both', expand=True)
        vs.pack(side='left', fill='y')

        side = tk.Frame(wrap, bg=C_WIN_BG)
        side.pack(side='left', fill='y', padx=(14, 0))

        tk.Label(
            side, text='خيارات التحليل والمسح' if is_ar else 'Analysis Settings',
            bg=C_WIN_BG, font=('Segoe UI', 10, 'bold'), fg=C_TITLE
        ).pack(anchor='w', pady=(0, 6))

        check_labels = [
            (self.opt_lost, 'البحث عن الملفات المحذوفة/المفقودة' if is_ar else 'Scan for lost/deleted files'),
            (self.opt_recy, 'فحص سلة المحذوفات' if is_ar else 'Parse Recycle Bin'),
            (self.opt_carve, 'تفعيل الحفر بالتواقيع (فحص عميق)' if is_ar else 'Enable signature carving (deep)')
        ]
        for var, text in check_labels:
            tk.Checkbutton(side, text=text, variable=var, bg=C_WIN_BG, font=('Segoe UI', 9)).pack(anchor='w', pady=3)

        self.ptree.insert('', 'end', iid='loading', text='جاري فحص وحدة التخزين...' if is_ar else 'Scanning storage device...')

        nav = tk.Frame(self.body, bg='#F1F5F9', height=50)
        nav.pack(fill='x', side='bottom')

        back_txt = '< رجوع' if is_ar else '< Back'
        entire_txt = 'مسح القرص كاملاً' if is_ar else 'Scan Entire Disk'
        cont_txt = 'متابعة >' if is_ar else 'Continue >'

        tk.Button(nav, text=back_txt, command=lambda: self.show('disksel'), width=12, font=('Segoe UI', 9)).pack(side='left', padx=14, pady=10)
        tk.Button(nav, text=entire_txt, command=self._parts_ignore, width=18, font=('Segoe UI', 9)).pack(side='left', padx=6, pady=10)
        tk.Button(nav, text=cont_txt, command=self._parts_next, bg='#2B5885', fg='#FFFFFF', font=('Segoe UI', 9, 'bold'), width=14).pack(side='right', padx=14, pady=10)

        self.worker = threading.Thread(target=self._discover_worker, daemon=True)
        self.worker.start()

    def _discover_worker(self):
        try:
            eng = ScanEngine(self.selected_source['path'], cancel=self.cancel_event)
            eng.open()
            eng.discover()
            self.engine = eng
            self.uiq.put(lambda: self._fill_parts(eng.volumes))
        except PermissionError as pe:
            self.uiq.put(lambda p=pe: self._on_permission_error(str(p)))
        except Exception as e:
            self.uiq.put(lambda er=e: self._discover_error(er))

    def _on_permission_error(self, msg):
        is_ar = lang.get_lang() == 'ar'
        title = 'صلاحيات المسؤول مطلوبة' if is_ar else 'Administrator Rights Required'
        text = (
            'يتطلب فحص هذا القرص أو فلاش USB صلاحيات المسؤول (Administrator) في ويندوز لقراءة القطاعات الخام.\n\n'
            'هل ترغب في إعادة تشغيل R.saver كمسؤول (Run as Administrator) الآن؟'
            if is_ar else
            'Scanning this physical drive or raw USB requires Administrator privileges in Windows.\n\n'
            'Would you like to restart R.saver as Administrator now?'
        )
        if messagebox.askyesno(title, text, parent=self.root):
            relaunch_as_admin()
            self.root.destroy()
        else:
            self.show('disksel')

    def _discover_error(self, e):
        is_ar = lang.get_lang() == 'ar'
        self.ptree.delete(*self.ptree.get_children())
        self.ptree.insert('', 'end', text=f'{"خطأ في قراءة الجهاز" if is_ar else "Error reading device"}: {e}')

    def _fill_parts(self, vols):
        self.volumes = vols
        self.ptree.delete(*self.ptree.get_children())
        is_ar = lang.get_lang() == 'ar'
        if not vols:
            no_p_txt = 'لم يتم اكتشاف أقسام (اضغط "مسح القرص كاملاً" للمسح المباشر)' if is_ar else 'No partitions detected (click "Scan Entire Disk" for raw scan)'
            self.ptree.insert('', 'end', text=no_p_txt)
            return
        for i, v in enumerate(vols):
            part_name = f'{"القسم" if is_ar else "Partition"} {i+1}' + (f' ("{v.label}")' if v.label else '')
            fs_val = v.fs or ('غير معروف' if is_ar else 'Unknown FS')
            state = ('منسق' if is_ar else 'Formatted') if v.fs else ('غير مخصص / خام' if is_ar else 'Unallocated / Raw')
            self.ptree.insert('', 'end', iid=f'v{i}', text=part_name,
                              values=(human_size(v.length), fs_val, state))

    def _parts_next(self):
        if not self.volumes:
            self.scan_volumes = None
            self.show('scan')
            return
        sel = self.ptree.selection()
        if sel and sel[0].startswith('v'):
            keep = int(sel[0][1:])
            self.scan_volumes = [self.volumes[keep]]
        else:
            self.scan_volumes = list(self.volumes)
        self.show('scan')

    def _parts_ignore(self):
        self.scan_volumes = None
        self.show('scan')

    # ---------- STEP 3: Scanning ----------

    def _page_scan_direct(self):
        self.scan_volumes = None
        self.show('scan')

    def _page_scan(self):
        is_ar = lang.get_lang() == 'ar'
        info = tk.Frame(self.body, bg=C_WIN_BG)
        info.pack(fill='both', expand=True, padx=30, pady=24)

        scan_head_txt = (
            'جاري تحليل نظام الملفات والبحث عن البيانات المحذوفة...' if is_ar else
            'Analyzing File System & Scanning for Data...'
        )
        tk.Label(
            info, text=scan_head_txt,
            font=('Segoe UI', 13, 'bold'), fg=C_TITLE, bg=C_WIN_BG
        ).pack(anchor='w', pady=(0, 6))

        src_name = self.selected_source.get('name') or self.selected_source.get('path')
        self.scan_src_lbl = tk.Label(
            info, text=f'{"الهدف" if is_ar else "Target"}: {src_name}',
            font=('Segoe UI', 10), fg='#475569', bg=C_WIN_BG
        )
        self.scan_src_lbl.pack(anchor='w', pady=(0, 16))

        self.pbar = ttk.Progressbar(info, orient='horizontal', mode='determinate')
        self.pbar.pack(fill='x', pady=8)

        self.scan_pct_var = tk.StringVar(value='0% مكتمل' if is_ar else '0% completed')
        tk.Label(info, textvariable=self.scan_pct_var, font=('Segoe UI', 10, 'bold'), fg=C_TITLE, bg=C_WIN_BG).pack(anchor='w')

        self.scan_msg_var = tk.StringVar(value='جاري تهيئة محرك المسح...' if is_ar else 'Initializing scan engine...')
        tk.Label(info, textvariable=self.scan_msg_var, font=('Segoe UI', 9), fg='#64748B', bg=C_WIN_BG).pack(anchor='w', pady=(4, 0))

        nav = tk.Frame(self.body, bg='#F1F5F9', height=50)
        nav.pack(fill='x', side='bottom')

        skip_txt = 'تخطي الفحص العميق' if is_ar else 'Skip Deep Scan'
        cancel_txt = 'إلغاء' if is_ar else 'Cancel'

        self.btn_skip_scan = tk.Button(nav, text=skip_txt, command=self._scan_skip, width=18, font=('Segoe UI', 9))
        self.btn_skip_scan.pack(side='left', padx=14, pady=10)

        self.btn_cancel_scan = tk.Button(nav, text=cancel_txt, command=self._scan_back, width=12, font=('Segoe UI', 9))
        self.btn_cancel_scan.pack(side='right', padx=14, pady=10)

        self.worker = threading.Thread(target=self._scan_worker, daemon=True)
        self.worker.start()

    def _scan_worker(self):
        def progress(stage, done, total, msg):
            self.uiq.put(lambda s=stage, d=done, t=total, m=msg: self._on_scan_progress(s, d, t, m))

        try:
            if not self.engine:
                self.engine = ScanEngine(self.selected_source['path'], progress=progress, cancel=self.cancel_event)
                self.engine.open()
            else:
                self.engine.progress = progress
                self.engine.cancel = self.cancel_event

            if not self.engine.volumes:
                self.engine.discover()

            vols = self.scan_volumes or self.engine.volumes
            deep = self.opt_carve.get() or self.opt_lost.get()
            carve = self.opt_carve.get()
            live, lost = self.engine.scan(volumes=vols, deep=deep, carve=carve)
            self.uiq.put(lambda: self._scan_done(live, lost, None))
        except PermissionError as pe:
            self.uiq.put(lambda p=pe: self._on_permission_error(str(p)))
        except Exception as e:
            self.uiq.put(lambda er=e: self._scan_done([], [], er))

    def _on_scan_progress(self, stage, done, total, msg):
        pct = (100 * done // max(1, total)) if total else 0
        self.pbar['value'] = pct
        is_ar = lang.get_lang() == 'ar'
        self.scan_pct_var.set(f'{pct}% {"مكتمل" if is_ar else "completed"}')
        self.scan_msg_var.set(f'[{stage.upper()}] {msg}')

    def _scan_skip(self):
        self.cancel_event.set()

    def _scan_back(self):
        self.cancel_event.set()
        self.show('disksel')

    def _scan_done(self, live, lost, error):
        self.live = live
        self.lost = lost
        if error:
            is_ar = lang.get_lang() == 'ar'
            err_title = 'تنبيه المسح' if is_ar else 'Scan Notice'
            err_msg = f'{"حدث خطأ أثناء المسح" if is_ar else "Scan encountered an issue"}:\n{error}'
            messagebox.showwarning(err_title, err_msg, parent=self.root)
        self.show('explorer')

    # ---------- STEP 4: File Explorer ----------

    def _page_explorer(self):
        self.checks.clear()
        self.i2item.clear()
        is_ar = lang.get_lang() == 'ar'

        top_info = tk.Frame(self.body, bg=C_WIN_BG)
        top_info.pack(fill='x', padx=20, pady=(10, 6))

        total_files = len(self.live) + len(self.lost)
        if is_ar:
            title_exp = f'الملفات المكتشفة ({total_files} إجمالي: {len(self.live)} سليم، {len(self.lost)} محذوف ومحفور)'
        else:
            title_exp = f'Discovered Files ({total_files} total: {len(self.live)} existing, {len(self.lost)} lost/deleted)'

        tk.Label(
            top_info, text=title_exp,
            font=('Segoe UI', 12, 'bold'), fg=C_TITLE, bg=C_WIN_BG
        ).pack(side='left')

        # Filter / Search
        filter_box = tk.Frame(top_info, bg=C_WIN_BG)
        filter_box.pack(side='right')
        tk.Label(filter_box, text=('تصفية: ' if is_ar else 'Filter: '), bg=C_WIN_BG, font=('Segoe UI', 9)).pack(side='left')
        self.filter_var = tk.StringVar(value='')
        fe = tk.Entry(filter_box, textvariable=self.filter_var, width=20, font=('Segoe UI', 9))
        fe.pack(side='left', padx=(0, 6))
        self.filter_var.trace_add('write', lambda *a: self._filter_tree())

        # Main splitter (Treeview left, Preview right)
        paned = tk.PanedWindow(self.body, orient='horizontal', bg='#CBD5E1', sashwidth=4)
        paned.pack(fill='both', expand=True, padx=20, pady=(0, 10))

        # Left: Files tree
        left_f = tk.Frame(paned, bg=C_WIN_BG)
        paned.add(left_f, minsize=420)

        cols = ('size', 'type', 'status')
        self.tree = ttk.Treeview(left_f, columns=cols, show='tree headings', selectmode='extended')
        self.tree.heading('#0', text='الاسم' if is_ar else 'Name')
        self.tree.heading('size', text='الحجم' if is_ar else 'Size')
        self.tree.heading('type', text='النوع' if is_ar else 'Type')
        self.tree.heading('status', text='الحالة' if is_ar else 'Status')
        self.tree.column('#0', width=270)
        self.tree.column('size', width=90, anchor='e')
        self.tree.column('type', width=90)
        self.tree.column('status', width=90)

        vs = ttk.Scrollbar(left_f, orient='vertical', command=self.tree.yview)
        self.tree.configure(yscrollcommand=vs.set)
        self.tree.pack(side='left', fill='both', expand=True)
        vs.pack(side='left', fill='y')

        self.tree.bind('<Button-1>', self._tree_click)
        self.tree.bind('<<TreeviewSelect>>', self._tree_preview)

        # Right: Preview Frame
        right_f = tk.Frame(paned, bg='#F8FAFC', bd=1, relief='solid')
        paned.add(right_f, minsize=260)

        tk.Label(
            right_f, text=('معاينة وتفاصيل الملف' if is_ar else 'File Preview'),
            font=('Segoe UI', 10, 'bold'), fg=C_TITLE, bg='#F8FAFC'
        ).pack(anchor='w', padx=10, pady=8)
        
        default_prev = 'حدد ملفاً من القائمة لمعاينة معلوماته وحجمه.' if is_ar else 'Select a file to preview its content or metadata.'
        self.preview_lbl = tk.Label(
            right_f, text=default_prev, bg='#F8FAFC', fg='#64748B',
            font=('Segoe UI', 9), wraplength=240, justify='left'
        )
        self.preview_lbl.pack(fill='both', expand=True, padx=10, pady=6)

        # Bottom Bar
        nav = tk.Frame(self.body, bg='#F1F5F9', height=50)
        nav.pack(fill='x', side='bottom')

        sel_all_txt = 'تحديد الكل' if is_ar else 'Select All'
        desel_all_txt = 'إلغاء التحديد' if is_ar else 'Deselect All'
        rec_btn_txt = 'استرجاع الملفات المحددة >' if is_ar else 'Recover Selected >'
        back_txt = '< رجوع' if is_ar else '< Back'

        tk.Button(nav, text=sel_all_txt, command=lambda: self._check_all(True), font=('Segoe UI', 9)).pack(side='left', padx=14, pady=10)
        tk.Button(nav, text=desel_all_txt, command=lambda: self._check_all(False), font=('Segoe UI', 9)).pack(side='left', padx=4, pady=10)

        self.sel_count_lbl = tk.Label(nav, text='0 files selected', bg='#F1F5F9', font=('Segoe UI', 9, 'bold'), fg=C_TITLE)
        self.sel_count_lbl.pack(side='left', padx=16)

        tk.Button(nav, text=rec_btn_txt, command=self._to_cpdef, bg='#2B5885', fg='#FFFFFF', font=('Segoe UI', 9, 'bold'), padx=16).pack(side='right', padx=14, pady=10)
        tk.Button(nav, text=back_txt, command=lambda: self.show('disksel'), font=('Segoe UI', 9)).pack(side='right', padx=6, pady=10)

        self._fill_tree()

    def _fill_tree(self):
        self.tree.delete(*self.tree.get_children())
        is_ar = lang.get_lang() == 'ar'
        lost_title = '[x] $LostFiles (الملفات المحذوفة والمحفورة)' if is_ar else '[x] $LostFiles (Deleted / Carved)'
        live_title = '[ ] الملفات السليمة الموجودة' if is_ar else '[ ] Existing File System'

        # Lost / Deleted Files Folder
        lost_root = self.tree.insert('', 'end', iid='grp_lost', text=lost_title, open=True)
        self.checks['grp_lost'] = True
        for i, it in enumerate(self.lost):
            iid = f'lost_{i}'
            self.i2item[iid] = it
            self.checks[iid] = True
            name = it.get('name') or 'unknown'
            sz_str = human_size(it.get('size', 0))
            typ = it.get('sig') or (name.rsplit('.', 1)[-1].upper() if '.' in name else ('ملف' if is_ar else 'file'))
            status_txt = 'محذوف' if is_ar else 'Deleted'
            self.tree.insert(lost_root, 'end', iid=iid, text=f'[x] {name}', values=(sz_str, typ, status_txt))

        # Live / Existing Files Folder
        live_root = self.tree.insert('', 'end', iid='grp_live', text=live_title, open=False)
        self.checks['grp_live'] = False
        for i, it in enumerate(self.live):
            iid = f'live_{i}'
            self.i2item[iid] = it
            self.checks[iid] = False
            name = it.get('name') or 'unknown'
            sz_str = human_size(it.get('size', 0))
            typ = it.get('sig') or (name.rsplit('.', 1)[-1].upper() if '.' in name else ('ملف' if is_ar else 'file'))
            status_txt = 'سليم' if is_ar else 'Live'
            self.tree.insert(live_root, 'end', iid=iid, text=f'[ ] {name}', values=(sz_str, typ, status_txt))

        self._update_selection_count()

    def _filter_tree(self):
        q = self.filter_var.get().strip().lower()
        if not q:
            self._fill_tree()
            return
        self.tree.delete(*self.tree.get_children())
        is_ar = lang.get_lang() == 'ar'
        title = f'النتائج المطابقة لـ "{q}"' if is_ar else f'Matching "{q}"'
        filtered_root = self.tree.insert('', 'end', iid='grp_flt', text=title, open=True)

        for i, it in enumerate(self.lost + self.live):
            name = str(it.get('name', ''))
            if q in name.lower():
                iid = f'flt_{i}'
                self.i2item[iid] = it
                self.checks[iid] = True
                sz_str = human_size(it.get('size', 0))
                st = 'محذوف' if it.get('deleted') else ('سليم' if is_ar else 'Live')
                self.tree.insert(filtered_root, 'end', iid=iid, text=f'[x] {name}', values=(sz_str, '', st))

    def _tree_click(self, event):
        iid = self.tree.identify_row(event.y)
        if not iid:
            return
        cur = self.checks.get(iid, False)
        new_val = not cur
        self.checks[iid] = new_val

        txt = self.tree.item(iid, 'text')
        if txt.startswith('[x] '):
            self.tree.item(iid, text='[ ] ' + txt[4:])
        elif txt.startswith('[ ] '):
            self.tree.item(iid, text='[x] ' + txt[4:])

        for child in self.tree.get_children(iid):
            self.checks[child] = new_val
            c_txt = self.tree.item(child, 'text')
            prefix = '[x] ' if new_val else '[ ] '
            if c_txt.startswith(('[x] ', '[ ] ')):
                self.tree.item(child, text=prefix + c_txt[4:])

        self._update_selection_count()

    def _check_all(self, val):
        for iid in list(self.checks.keys()):
            self.checks[iid] = val
            txt = self.tree.item(iid, 'text')
            prefix = '[x] ' if val else '[ ] '
            if txt.startswith(('[x] ', '[ ] ')):
                self.tree.item(iid, text=prefix + txt[4:])
        self._update_selection_count()

    def _update_selection_count(self):
        is_ar = lang.get_lang() == 'ar'
        sel_items = [self.i2item[k] for k, v in self.checks.items() if v and k in self.i2item]
        total_sz = sum(it.get('size', 0) for it in sel_items)
        cnt = len(sel_items)
        if is_ar:
            self.sel_count_lbl.configure(text=f'تم تحديد {cnt} ملف ({human_size(total_sz)})')
        else:
            self.sel_count_lbl.configure(text=f'{cnt} files selected ({human_size(total_sz)})')

    def _tree_preview(self, _e=None):
        sel = self.tree.selection()
        if not sel or sel[0] not in self.i2item:
            return
        it = self.i2item[sel[0]]
        is_ar = lang.get_lang() == 'ar'
        name = it.get('name', 'unknown')
        size = it.get('size', 0)
        path = it.get('path', '')
        if is_ar:
            status = 'محذوف / مستخرج بالتوقيع' if it.get('deleted') else 'سليم وموجود'
            info = f"الاسم: {name}\nالحجم: {human_size(size)} ({size} بايت)\nالحالة: {status}\n\nالمسار: {path}"
        else:
            status = 'Deleted / Carved' if it.get('deleted') else 'Existing'
            info = f"Name: {name}\nSize: {human_size(size)} ({size} bytes)\nStatus: {status}\n\nPath: {path}"
        self.preview_lbl.configure(text=info)

    def _to_cpdef(self):
        sel_items = [self.i2item[k] for k, v in self.checks.items() if v and k in self.i2item]
        if not sel_items:
            is_ar = lang.get_lang() == 'ar'
            title = 'لم يتم تحديد ملفات' if is_ar else 'No Files Selected'
            msg = 'يرجى تحديد ملف أو مجلد واحد على الأقل للاسترجاع.' if is_ar else 'Please check at least one file to recover.'
            messagebox.showwarning(title, msg, parent=self.root)
            return
        self.recover_items = sel_items
        self.show('cpdef')

    # ---------- STEP 5: Destination Selection ----------

    def _page_cpdef(self):
        is_ar = lang.get_lang() == 'ar'
        frame = tk.Frame(self.body, bg=C_WIN_BG)
        frame.pack(fill='both', expand=True, padx=30, pady=24)

        heading_txt = (
            'اختر مجلد حفظ الملفات المسترجعة' if is_ar else
            'Choose Destination Folder for Recovered Files'
        )
        tk.Label(
            frame, text=heading_txt,
            font=('Segoe UI', 13, 'bold'), fg=C_TITLE, bg=C_WIN_BG
        ).pack(anchor='w', pady=(0, 6))

        warn_txt = (
            'هام جداً: لتجنب الكتابة فوق بياناتك المحذوفة، اختر قرصاً مختلفاً عن قرص المصدر.' if is_ar else
            'Important: To prevent data overwriting, select a drive DIFFERENT from the source disk.'
        )
        tk.Label(
            frame, text=warn_txt,
            font=('Segoe UI', 9, 'italic'), fg=C_ORANGE, bg=C_WIN_BG
        ).pack(anchor='w', pady=(0, 16))

        dir_box = tk.Frame(frame, bg=C_WIN_BG)
        dir_box.pack(fill='x', pady=10)

        default_out = os.path.abspath('./MiniSaver_Output')
        self.dest_var = tk.StringVar(value=default_out)

        tk.Entry(dir_box, textvariable=self.dest_var, font=('Segoe UI', 10), width=50).pack(side='left', fill='x', expand=True, padx=(0, 10))
        browse_txt = 'استعراض...' if is_ar else 'Browse...'
        tk.Button(dir_box, text=browse_txt, command=self._browse_dest, font=('Segoe UI', 9)).pack(side='left')

        nav = tk.Frame(self.body, bg='#F1F5F9', height=50)
        nav.pack(fill='x', side='bottom')

        back_txt = '< رجوع' if is_ar else '< Back'
        start_txt = 'بدء الاسترجاع' if is_ar else 'Start Recovery'
        tk.Button(nav, text=back_txt, command=lambda: self.show('explorer'), font=('Segoe UI', 9)).pack(side='left', padx=14, pady=10)
        tk.Button(nav, text=start_txt, command=self._start_recovery, bg='#2B5885', fg='#FFFFFF', font=('Segoe UI', 10, 'bold'), padx=20).pack(side='right', padx=14, pady=10)

    def _browse_dest(self):
        is_ar = lang.get_lang() == 'ar'
        t = 'اختر مجلد الحفظ' if is_ar else 'Select Recovery Folder'
        d = filedialog.askdirectory(parent=self.root, title=t)
        if d:
            self.dest_var.set(d)

    def _start_recovery(self):
        self.target_dir = self.dest_var.get().strip()
        if not self.target_dir:
            return
        os.makedirs(self.target_dir, exist_ok=True)
        self.show('copying')

    # ---------- STEP 6: Copying Files & Completion ----------

    def _page_copying(self):
        is_ar = lang.get_lang() == 'ar'
        frame = tk.Frame(self.body, bg=C_WIN_BG)
        frame.pack(fill='both', expand=True, padx=30, pady=30)

        head_txt = 'جاري استخراج وحفظ الملفات المسترجعة...' if is_ar else 'Extracting and Saving Recovered Files...'
        tk.Label(
            frame, text=head_txt,
            font=('Segoe UI', 13, 'bold'), fg=C_TITLE, bg=C_WIN_BG
        ).pack(anchor='w', pady=(0, 10))

        self.copy_pbar = ttk.Progressbar(frame, orient='horizontal', mode='determinate')
        self.copy_pbar.pack(fill='x', pady=10)

        init_st = 'بدء عملية الاستخراج...' if is_ar else 'Starting extraction...'
        self.copy_status_var = tk.StringVar(value=init_st)
        tk.Label(frame, textvariable=self.copy_status_var, font=('Segoe UI', 10), fg=C_TITLE, bg=C_WIN_BG).pack(anchor='w')

        self.worker = threading.Thread(target=self._copy_worker, daemon=True)
        self.worker.start()

    def _copy_worker(self):
        def progress(stage, done, total, msg):
            self.uiq.put(lambda s=stage, d=done, t=total, m=msg: self._on_copy_progress(s, d, t, m))

        try:
            ok, fail, written = self.engine.recover(self.recover_items, self.target_dir, progress=progress)
            self.uiq.put(lambda o=ok, f=fail, w=written: self._copy_done(o, f, w, None))
        except Exception as e:
            self.uiq.put(lambda er=e: self._copy_done(0, len(self.recover_items), 0, er))

    def _on_copy_progress(self, stage, done, total, msg):
        pct = (100 * done // max(1, total)) if total else 0
        self.copy_pbar['value'] = pct
        self.copy_status_var.set(f'{pct}% - {msg}')

    def _copy_done(self, ok, fail, written, error):
        self._copy_results = {'ok': ok, 'fail': fail, 'written': written, 'error': error}
        self.show('done')

    def _page_done(self):
        is_ar = lang.get_lang() == 'ar'
        res = getattr(self, '_copy_results', {'ok': 0, 'fail': 0, 'written': 0, 'error': None})
        frame = tk.Frame(self.body, bg=C_WIN_BG)
        frame.pack(fill='both', expand=True, padx=30, pady=30)

        head_txt = 'اكتمل استرجاع البيانات بنجاح!' if is_ar else 'Data Recovery Completed!'
        tk.Label(
            frame, text=head_txt,
            font=('Segoe UI', 15, 'bold'), fg='#15803D', bg=C_WIN_BG
        ).pack(anchor='w', pady=(0, 12))

        if is_ar:
            msg = (
                f"الملفات المسترجعة بنجاح: {res['ok']} ملف\n"
                f"فشل: {res['fail']} ملف\n"
                f"إجمالي البيانات المكتوبة: {human_size(res['written'])}\n\n"
                f"مجلد الحفظ:\n{self.target_dir}"
            )
        else:
            msg = (
                f"Successfully recovered: {res['ok']} files\n"
                f"Failed: {res['fail']} files\n"
                f"Total bytes written: {human_size(res['written'])}\n\n"
                f"Destination directory:\n{self.target_dir}"
            )
        tk.Label(frame, text=msg, font=('Segoe UI', 10), justify='left', bg=C_WIN_BG, fg='#334155').pack(anchor='w', pady=(0, 20))

        btn_box = tk.Frame(frame, bg=C_WIN_BG)
        btn_box.pack(anchor='w', pady=10)

        open_txt = 'فتح مجلد الحفظ' if is_ar else 'Open Destination Folder'
        ret_txt = 'العودة للبداية' if is_ar else 'Return to Start'
        close_txt = 'إغلاق' if is_ar else 'Close'

        tk.Button(
            btn_box, text=open_txt, command=lambda: os.startfile(self.target_dir),
            bg='#2B5885', fg='#FFFFFF', font=('Segoe UI', 10, 'bold'), padx=16, pady=6
        ).pack(side='left', padx=(0, 12))

        tk.Button(
            btn_box, text=ret_txt, command=lambda: self.show('disksel'),
            font=('Segoe UI', 10), padx=14, pady=6
        ).pack(side='left', padx=(0, 12))

        tk.Button(
            btn_box, text=close_txt, command=self.root.destroy,
            font=('Segoe UI', 10), padx=14, pady=6
        ).pack(side='left')


def run_gui(argv=None):
    root = tk.Tk()
    app = Wizard(root)
    root.mainloop()


if __name__ == '__main__':
    run_gui()
