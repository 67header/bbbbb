# -*- coding: utf-8 -*-
"""MiniSaver - Icon Generator for R.saver 6.9.5 Interface"""
import math
from PIL import Image, ImageDraw, ImageTk

_cache = {}

def render_supersampled(draw_fn, target_size=(64, 64), scale=4):
    w, h = target_size[0] * scale, target_size[1] * scale
    im = Image.new('RGBA', (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    draw_fn(d, w, h)
    return im.resize(target_size, Image.Resampling.LANCZOS)

def _draw_win_hdd(d, w, h):
    margin = int(w * 0.08)
    d.rounded_rectangle([margin, margin, w - margin, h - margin], radius=int(w*0.1), fill='#E8EFF5', outline='#7C93A8', width=int(w*0.03))
    pad = int(w * 0.12)
    d.rounded_rectangle([pad, pad, w - pad, h - pad], radius=int(w*0.06), fill='#FDFDFE', outline='#BAC7D5', width=int(w*0.02))
    sc = int(w * 0.04)
    for cx, cy in [(pad+sc, pad+sc), (w-pad-sc, pad+sc), (pad+sc, h-pad-sc), (w-pad-sc, h-pad-sc)]:
        d.ellipse([cx-sc, cy-sc, cx+sc, cy+sc], fill='#8B9DAE')
        d.line([cx-sc//2, cy, cx+sc//2, cy], fill='#5A6E80', width=int(w*0.01))
    blue = '#00A8EC'
    cx, cy = w // 2, h // 2
    pw, ph = int(w * 0.38), int(h * 0.38)
    gap = int(w * 0.03)
    d.polygon([(cx - pw//2, cy - ph//2 + int(ph*0.05)), (cx - gap, cy - ph//2), (cx - gap, cy - gap), (cx - pw//2, cy - gap)], fill=blue)
    d.polygon([(cx + gap, cy - ph//2), (cx + pw//2, cy - ph//2 - int(ph*0.05)), (cx + pw//2, cy - gap), (cx + gap, cy - gap)], fill=blue)
    d.polygon([(cx - pw//2, cy + gap), (cx - gap, cy + gap), (cx - gap, cy + ph//2), (cx - pw//2, cy + ph//2 - int(ph*0.05))], fill=blue)
    d.polygon([(cx + gap, cy + gap), (cx + pw//2, cy + gap), (cx + pw//2, cy + ph//2 + int(ph*0.05)), (cx + gap, cy + ph//2)], fill=blue)
    led_x, led_y = w - pad - int(sc*2.5), h - pad - int(sc*2.5)
    d.ellipse([led_x-sc, led_y-sc, led_x+sc, led_y+sc], fill='#00C853', outline='#A5D6A7', width=int(w*0.01))

def _draw_usb_drive(d, w, h):
    cw, ch = int(w * 0.44), int(h * 0.65)
    cx, cy = w // 2, int(h * 0.58)
    mw, mh = int(cw * 0.65), int(h * 0.22)
    mx = cx - mw // 2
    my = cy - ch // 2 - mh + int(h * 0.04)
    d.rounded_rectangle([mx, my, mx + mw, my + mh], radius=int(w*0.02), fill='#CBD5E1', outline='#64748B', width=int(w*0.02))
    hw = int(mw * 0.22)
    hh = int(mh * 0.35)
    d.rectangle([mx + int(mw*0.18), my + int(mh*0.25), mx + int(mw*0.18) + hw, my + int(mh*0.25) + hh], fill='#334155')
    d.rectangle([mx + mw - int(mw*0.18) - hw, my + int(mh*0.25), mx + mw - int(mw*0.18), my + int(mh*0.25) + hh], fill='#334155')
    bx0, by0, bx1, by1 = cx - cw // 2, cy - ch // 2, cx + cw // 2, cy + ch // 2
    d.rounded_rectangle([bx0, by0, bx1, by1], radius=int(w*0.06), fill='#F57C00', outline='#E65100', width=int(w*0.02))
    uw = int(cw * 0.5)
    ux, uy = cx, cy
    d.line([ux, uy + int(ch*0.22), ux, uy - int(ch*0.15)], fill='#FFFFFF', width=int(w*0.03))
    d.polygon([(ux, uy - int(ch*0.22)), (ux - int(uw*0.3), uy - int(ch*0.12)), (ux + int(uw*0.3), uy - int(ch*0.12))], fill='#FFFFFF')
    d.line([ux, uy + int(ch*0.05), ux - int(uw*0.35), uy - int(ch*0.05)], fill='#FFFFFF', width=int(w*0.025))
    d.rectangle([ux - int(uw*0.35) - int(w*0.02), uy - int(ch*0.09), ux - int(uw*0.35) + int(w*0.02), uy - int(ch*0.05)], fill='#FFFFFF')
    d.line([ux, uy + int(ch*0.05), ux + int(uw*0.35), uy - int(ch*0.05)], fill='#FFFFFF', width=int(w*0.025))
    d.ellipse([ux + int(uw*0.35) - int(w*0.025), uy - int(ch*0.08), ux + int(uw*0.35) + int(w*0.025), uy - int(ch*0.03)], fill='#FFFFFF')
    d.ellipse([ux - int(w*0.025), uy + int(ch*0.2) - int(w*0.025), ux + int(w*0.025), uy + int(ch*0.2) + int(w*0.025)], fill='#FFFFFF')

def _draw_physical_hdd(d, w, h):
    margin = int(w * 0.08)
    d.rounded_rectangle([margin, margin, w - margin, h - margin], radius=int(w*0.08), fill='#2A374A', outline='#607289', width=int(w*0.03))
    pad = int(w * 0.12)
    d.rounded_rectangle([pad, pad, w - pad, h - pad], radius=int(w*0.06), fill='#1B2430', outline='#3A4B5F', width=int(w*0.02))
    cx, cy = int(w * 0.52), int(h * 0.52)
    pr = int(w * 0.28)
    d.ellipse([cx - pr, cy - pr, cx + pr, cy + pr], fill='#A0B2C6', outline='#BACADB', width=int(w*0.02))
    d.ellipse([cx - int(pr*0.35), cy - int(pr*0.35), cx + int(pr*0.35), cy + int(pr*0.35)], fill='#4A5B6E')
    d.polygon([(int(w*0.2), int(h*0.25)), (cx, cy), (int(w*0.24), int(h*0.2))], fill='#E2E8F0')
    d.ellipse([int(w*0.2)-int(w*0.03), int(h*0.23)-int(w*0.03), int(w*0.2)+int(w*0.03), int(h*0.23)+int(w*0.03)], fill='#64748B')

def _draw_image_disk(d, w, h):
    margin = int(w * 0.08)
    d.rounded_rectangle([margin, margin, w - margin, h - margin], radius=int(w*0.1), fill='#F1F5F9', outline='#94A3B8', width=int(w*0.03))
    cx, cy = w // 2, h // 2
    r = int(w * 0.28)
    d.ellipse([cx - r, cy - r, cx + r, cy + r], fill='#E2E8F0', outline='#64748B', width=int(w*0.02))
    d.ellipse([cx - int(r*0.3), cy - int(r*0.3), cx + int(r*0.3), cy + int(r*0.3)], fill='#F1F5F9', outline='#64748B', width=int(w*0.02))
    pw = int(w * 0.04)
    pl = int(w * 0.14)
    px, py = int(w * 0.75), int(h * 0.75)
    d.ellipse([px - pl, py - pl, px + pl, py + pl], fill='#0284C7')
    d.line([px - int(pl*0.6), py, px + int(pl*0.6), py], fill='#FFFFFF', width=pw)
    d.line([px, py - int(pl*0.6), px, py + int(pl*0.6)], fill='#FFFFFF', width=pw)

def _draw_profile_icon(d, w, h):
    d.ellipse([w*0.05, h*0.05, w*0.95, h*0.95], fill='#687C94')
    cx, cy = w // 2, h // 2
    d.ellipse([cx - w*0.16, cy - h*0.32, cx + w*0.16, cy], fill='#FFFFFF')
    d.pieslice([cx - w*0.32, cy - h*0.02, cx + w*0.32, cy + h*0.62], start=180, end=0, fill='#FFFFFF')

def _draw_gear_icon(d, w, h):
    d.ellipse([w*0.05, h*0.05, w*0.95, h*0.95], fill='#687C94')
    cx, cy = w // 2, h // 2
    for i in range(8):
        ang = i * (math.pi / 4)
        tx = cx + int(w * 0.35 * math.cos(ang))
        ty = cy + int(h * 0.35 * math.sin(ang))
        d.ellipse([tx-w*0.08, ty-h*0.08, tx+w*0.08, ty+h*0.08], fill='#FFFFFF')
    d.ellipse([cx-w*0.3, cy-h*0.3, cx+w*0.3, cy+h*0.3], fill='#FFFFFF')
    d.ellipse([cx-w*0.13, cy-h*0.13, cx+w*0.13, cy+h*0.13], fill='#687C94')

def _draw_help_icon(d, w, h):
    d.ellipse([w*0.05, h*0.05, w*0.95, h*0.95], fill='#687C94')
    cx, cy = w // 2, h // 2
    d.arc([cx - w*0.18, cy - h*0.32, cx + w*0.18, cy - h*0.02], start=180, end=0, fill='#FFFFFF', width=int(w*0.1))
    d.line([cx + w*0.18, cy - h*0.17, cx, cy], fill='#FFFFFF', width=int(w*0.1))
    d.line([cx, cy, cx, cy + h*0.1], fill='#FFFFFF', width=int(w*0.1))
    d.ellipse([cx - w*0.05, cy + h*0.2, cx + w*0.05, cy + h*0.3], fill='#FFFFFF')

def _draw_refresh_icon(d, w, h):
    d.ellipse([w*0.05, h*0.05, w*0.95, h*0.95], fill='#4A709C')
    cx, cy = w // 2, h // 2
    r = int(w * 0.26)
    d.arc([cx - r, cy - r, cx + r, cy + r], start=30, end=300, fill='#FFFFFF', width=int(w*0.1))
    d.polygon([(cx + r - int(w*0.06), cy - int(h*0.12)), (cx + r + int(w*0.12), cy - int(h*0.12)), (cx + r + int(w*0.03), cy + int(h*0.04))], fill='#FFFFFF')

def _draw_close_icon(d, w, h):
    d.ellipse([w*0.05, h*0.05, w*0.95, h*0.95], fill='#4A709C')
    cx, cy = w // 2, h // 2
    arm = int(w * 0.22)
    th = int(w * 0.09)
    d.line([cx - arm, cy - arm, cx + arm, cy + arm], fill='#FFFFFF', width=th)
    d.line([cx - arm, cy + arm, cx + arm, cy - arm], fill='#FFFFFF', width=th)

def get_pil_image(name, size=None):
    key = (name, size)
    if key in _cache:
        return _cache[key]
    builders = {
        'hdd_win': (_draw_win_hdd, (72, 72)),
        'hdd_usb': (_draw_usb_drive, (72, 72)),
        'hdd_physical': (_draw_physical_hdd, (72, 72)),
        'disk_image': (_draw_image_disk, (72, 72)),
        'btn_profile': (_draw_profile_icon, (32, 32)),
        'btn_gear': (_draw_gear_icon, (32, 32)),
        'btn_help': (_draw_help_icon, (32, 32)),
        'btn_refresh': (_draw_refresh_icon, (26, 26)),
        'btn_close': (_draw_close_icon, (26, 26)),
    }
    if name not in builders:
        return None
    fn, default_sz = builders[name]
    sz = size or default_sz
    img = render_supersampled(fn, sz)
    _cache[key] = img
    return img

_tk_cache = {}

def get_tk_image(name, size=None):
    key = (name, size)
    if key in _tk_cache:
        return _tk_cache[key]
    img = get_pil_image(name, size)
    if img:
        tk_img = ImageTk.PhotoImage(img)
        _tk_cache[key] = tk_img
        return tk_img
    return None
