"""MiniSaver - تحليل جداول الأقسام MBR / GPT وكشف نظام الملفات"""
from .util import u16, u32, u64, utf16le

PART_TYPES = {
    0x01: 'FAT12', 0x04: 'FAT16', 0x05: 'Extended', 0x06: 'FAT16',
    0x07: 'NTFS/exFAT', 0x0B: 'FAT32', 0x0C: 'FAT32 (LBA)', 0x0E: 'FAT16 (LBA)',
    0x0F: 'Extended (LBA)', 0x11: 'FAT12 مخفي', 0x14: 'FAT16 مخفي',
    0x16: 'FAT16 مخفي', 0x17: 'NTFS مخفي', 0x1B: 'FAT32 مخفي',
    0x1C: 'FAT32 مخفي (LBA)', 0x1E: 'FAT16 مخفي (LBA)',
    0x27: 'قسم استعادة ويندوز', 0x82: 'Linux swap', 0x83: 'Linux',
    0x85: 'Linux Extended', 0x8E: 'Linux LVM', 0xA5: 'FreeBSD',
    0xEE: 'GPT حماية', 0xEF: 'EFI System', 0xDE: 'Dell Utility',
}

GPT_TYPES = {
    '00000000-0000-0000-0000-000000000000': 'غير مستخدم',
    'ebd0a0a2-b9e5-4433-87c0-68b6b72699c7': 'بيانات أساسية',
    'c12a7328-f81f-11d2-ba4b-00a0c93ec93b': 'EFI System',
    'de94bba4-06d1-4d40-a16a-bfd50179d6ac': 'استعادة ويندوز',
    'e3c9e316-0b5c-4db8-817d-f92df00215ae': 'Microsoft Reserved',
    '0fc63daf-8483-4772-8e79-3d69d8477de4': 'Linux filesystem',
    '0657fd6d-a4ab-43c4-84e5-0933c84b4f4f': 'Linux swap',
    'a19d880f-05fc-4d3b-a006-743f0f84911e': 'FreeBSD boot',
    '21686148-6449-6e6f-744e-656564454649': 'BIOS boot',
}


def guid_str(b: bytes) -> str:
    a = b[0:4][::-1]
    b4 = b[4:6][::-1]
    c = b[6:8][::-1]
    rest = b[8:16]
    return f'{a.hex()}-{b4.hex()}-{c.hex()}-{rest[0:2].hex()}-{rest[2:8].hex()}'


class Partition:
    def __init__(self, start_lba, num_sectors, ptype=None, name='', kind='mbr'):
        self.start_lba = start_lba
        self.num_sectors = num_sectors
        self.ptype = ptype
        self.name = name
        self.kind = kind

    def describe(self, sector_size):
        tname = PART_TYPES.get(self.ptype, '') if self.kind == 'mbr' else \
            GPT_TYPES.get(self.ptype, self.name)
        return f'{self.kind.upper()} @{self.start_lba}+{self.num_sectors} ({tname})'


def parse_mbr(sector: bytes):
    """تحليل جدول أقسام MBR من القطاع الأول"""
    parts = []
    if len(sector) < 512 or sector[510:512] != b'\x55\xAA':
        return parts
    for i in range(4):
        e = sector[446 + 16 * i: 446 + 16 * (i + 1)]
        lba = u32(e, 8)
        nsec = u32(e, 12)
        ptype = e[4]
        if nsec == 0 or ptype == 0:
            continue
        if ptype == 0x05 or ptype == 0x0F:
            # قسم موسع: تفكيك السلسلة EBR
            parts.extend(_walk_ebr(lba, nsec, None))
            continue
        parts.append(Partition(lba, nsec, ptype, kind='mbr'))
    return parts


def _walk_ebr(ext_lba, ext_size, seen=None):
    """تفكيك سلسلة EBR للأقسام المنطقية"""
    from .util import u32 as _u32
    parts = []
    base = ext_lba
    ebr = ext_lba
    guard = 0
    while ebr and guard < 64:
        guard += 1
        yield_lba = None
        next_lba = None
        try:
            sec = _ebr_cache_read(ebr)
        except Exception:
            break
        if not sec or len(sec) < 512 or sec[510:512] != b'\x55\xAA':
            break
        for slot in (0, 1):
            e = sec[446 + 16 * slot: 446 + 16 * (slot + 1)]
            lba_rel = _u32(e, 8)
            nsec = _u32(e, 12)
            ptype = e[4]
            if nsec == 0 or ptype == 0:
                continue
            if slot == 0:
                yield_lba = ebr + lba_rel
            elif ptype in (0x05, 0x0F):
                next_lba = base + lba_rel
        if yield_lba:
            e0 = sec[446:462]
            parts.append(Partition(yield_lba, _u32(e0, 12), e0[4], kind='mbr'))
        ebr = next_lba
    return parts


# مخزن مؤقت للقطاعات المستخدم في _walk_ebr - يضبطه engine قبل النداء
_ebr_reader = None


def _ebr_cache_read(lba):
    if _ebr_reader is None:
        return None
    return _ebr_reader(lba)


def set_ebr_reader(fn):
    global _ebr_reader
    _ebr_reader = fn


def parse_gpt(source, sector_size=512):
    """تحليل أقسام GPT (LBA1 رئيسي)"""
    parts = []
    lba1 = source.read(sector_size, sector_size)
    if lba1[:8] != b'EFI PART':
        return parts
    entry_lba = u64(lba1, 72)
    num = u32(lba1, 80)
    esize = u32(lba1, 84)
    if esize < 128 or num > 512:
        return parts
    raw = source.read(entry_lba * sector_size, num * esize)
    for i in range(num):
        e = raw[i * esize:(i + 1) * esize]
        if len(e) < 128:
            break
        tg = guid_str(e[0:16])
        if tg == '00000000-0000-0000-0000-000000000000':
            continue
        first = u64(e, 32)
        last = u64(e, 40)
        name = utf16le(e[56:128]).rstrip('\x00')
        parts.append(Partition(first, last - first + 1, tg, name=name, kind='gpt'))
    return parts


def detect_fs(boot: bytes):
    """كشف نظام الملفات من قطاع الإقلاع"""
    if not boot or len(boot) < 64:
        return None
    if boot[3:11] == b'NTFS    ':
        return 'NTFS'
    if boot[3:11] == b'EXFAT   ':
        return 'exFAT'
    bps = u16(boot, 11)
    spc = boot[13]
    if bps not in (128, 256, 512, 1024, 2048, 4096, 8192):
        return None
    if spc == 0 or (spc & (spc - 1)) != 0:
        return None
    total16 = u16(boot, 19)
    total32 = u32(boot, 32)
    total = total16 or total32
    reserved = u16(boot, 14)
    fats = boot[16]
    root_entries = u16(boot, 17)
    if fats not in (1, 2, 3, 4) or reserved < 1 or total == 0:
        return None
    fat_size = u16(boot, 22) or u32(boot, 36)
    if fat_size == 0:
        return None
    root_sectors = (root_entries * 32 + bps - 1) // bps
    data_sectors = total - reserved - fats * fat_size - root_sectors
    if data_sectors <= 0:
        return None
    clusters = data_sectors // spc
    if clusters < 4085:
        return 'FAT12'
    if clusters < 65525:
        return 'FAT16'
    return 'FAT32'
