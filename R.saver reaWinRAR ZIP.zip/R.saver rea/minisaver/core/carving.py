"""MiniSaver - استخراج الملفات الخام بالتواقيع (File Carving)

يمسح نطاقات محددة (العناقيد الحرة عادةً) باحثاً عن تواقيع بداية الملفات:
JPEG, PNG, GIF, ZIP, GZIP, RIFF(WAV/AVI/WEBP), MP4/MOV, EXE, ELF, FB2, EPS, ERF, PDF.
بعد كل إصابة يحدد حجم الملف بتحليل بنية الصيغة ثم يقفز إلى نهايته.
مُحسّن بسرعة فائقة مع التصفية السريعة للبايتات الأولى.
"""
import os
import struct
import zlib


def _u16le(b, o):
    return struct.unpack_from('<H', b, o)[0]


def _u32le(b, o):
    return struct.unpack_from('<I', b, o)[0]


def _u32be(b, o):
    return struct.unpack_from('>I', b, o)[0]


def _u64be(b, o):
    return struct.unpack_from('>Q', b, o)[0]


def subtract_ranges(base, covered):
    """يطرح الفترات المغطاة من قائمة الفترات [(off, len)]"""
    if not covered:
        return list(base)
    cov = sorted(covered)
    merged = []
    for s, l in cov:
        if merged and s <= merged[-1][0] + merged[-1][1]:
            e = max(merged[-1][0] + merged[-1][1], s + l)
            merged[-1] = (merged[-1][0], e - merged[-1][0])
        else:
            merged.append((s, l))
    out = []
    for s, l in base:
        cur = s
        end = s + l
        for cs, cl in merged:
            ce = cs + cl
            if ce <= cur:
                continue
            if cs >= end:
                break
            if cs > cur:
                out.append((cur, min(cs, end) - cur))
            cur = max(cur, ce)
            if cur >= end:
                break
        if cur < end:
            out.append((cur, end - cur))
    return [(s, l) for s, l in out if l > 0]


# ---------- أدوات تحديد النهاية ----------

def _find_in_source(src, start, limit, pattern, chunk=4 * 1024 * 1024):
    """بحث عن نمط في المصدر بين start و start+limit -> إزاحة مطلقة أو None"""
    pos = start
    end = min(start + limit, src.size)
    tail = len(pattern) - 1
    while pos < end:
        n = min(chunk, end - pos)
        buf = src.read(pos, n + tail)
        idx = buf.find(pattern)
        if idx >= 0 and idx < n:
            return pos + idx
        pos += max(1, n - tail) if n > tail else n
    return None


def _end_jpeg(src, start, max_size):
    off = _find_in_source(src, start + 2, max_size, b'\xFF\xD9')
    return (off + 2 - start) if off else None


def _end_png(src, start, max_size):
    off = _find_in_source(src, start + 8, max_size, b'IEND')
    return (off + 8 - start) if off else None


def _end_gif(src, start, max_size):
    off = _find_in_source(src, start + 6, max_size, b'\x00\x3B')
    return (off + 2 - start) if off else None


def _end_zip(src, start, max_size):
    # PK\x05\x06 EOCD ثم تعليق
    off = _find_in_source(src, start + 4, max_size, b'PK\x05\x06')
    if off:
        tail = src.read(off + 20, 2)
        clen = _u16le(tail, 0) if len(tail) == 2 else 0
        return (off + 22 + clen - start)
    return None


def _end_gzip(src, start, max_size):
    # حجم غير مضغوط في آخر 4 بايتات
    off = _find_in_source(src, start + 10, max_size, b'\x00\x00\x00')
    return (off + 8 - start) if off else None


def _end_riff(src, start, max_size):
    head = src.read(start, 12)
    if len(head) < 8:
        return None
    riff_sz = _u32le(head, 4) + 8
    return min(riff_sz, max_size) if riff_sz > 12 else None


_ISO_BOXES = {b'ftyp', b'moov', b'mdat', b'free', b'skip', b'wide'}


def _match_mp4(buf, off):
    if off + 12 > len(buf):
        return None
    typ = bytes(buf[off + 4:off + 8])
    if typ == b'ftyp':
        brand = bytes(buf[off + 8:off + 12])
        if len(brand) < 4 or not all(0x20 <= c < 0x7F for c in brand):
            return None
        ext = '.mov' if brand == b'qt  ' else '.mp4'
        return {'sig': 'MP4/MOV', 'ext': ext}
    if typ in _ISO_BOXES:
        return {'sig': 'MP4/MOV', 'ext': '.mp4'}
    return None


def _end_mp4(src, start, max_size):
    """المشي على صناديق ISO-BMFF حتى نهاية صالحة أو خطأ"""
    pos = start
    end = min(start + max_size, src.size)
    last_good = start
    while pos + 8 <= end:
        head = src.read(pos, 8)
        if len(head) < 8:
            break
        size = _u32be(head, 0)
        typ = head[4:8]
        if size == 1:
            ext = src.read(pos + 8, 8)
            if len(ext) < 8:
                break
            size = _u64be(ext, 0)
            if size < 16:
                break
        elif size == 0:
            last_good = end
            break
        if size < 8 or pos + size > end:
            break
        if not all(0x20 <= c <= 0x7E or c == 0xA9 for c in typ):
            break
        pos += size
        last_good = pos
    return (last_good - start) if last_good > start else None


def _end_exe(src, start, max_size):
    head = src.read(start, 0x400)
    if len(head) < 0x40:
        return None
    pe_off = _u32le(head, 0x3C)
    if pe_off <= 0 or pe_off > 0x100000:
        return None
    pe = src.read(start + pe_off, 24 + 4096)
    if len(pe) < 24 or pe[:4] != b'PE\x00\x00':
        return None
    nsec = _u16le(pe, 6)
    opt = _u16le(pe, 20)
    tbl = 24 + opt
    end = pe_off + tbl + 40 * nsec
    if nsec > 96:
        return None
    sec_data = src.read(start + pe_off + tbl, 40 * nsec)
    for i in range(nsec):
        s = sec_data[i * 40:(i + 1) * 40]
        if len(s) < 40:
            break
        raw = _u32le(s, 16)
        rsz = _u32le(s, 20)
        if rsz:
            end = max(end, raw + rsz)
    return end


def _end_elf(src, start, max_size):
    head = src.read(start, 64)
    if len(head) < 52:
        return None
    is64 = head[4] == 2
    if is64:
        if len(head) < 64:
            return None
        shoff = struct.unpack_from('<Q', head, 0x28)[0]
        shentsize = struct.unpack_from('<H', head, 0x3A)[0]
        shnum = struct.unpack_from('<H', head, 0x3C)[0]
        phoff = struct.unpack_from('<Q', head, 0x20)[0]
        phentsize = struct.unpack_from('<H', head, 0x36)[0]
        phnum = struct.unpack_from('<H', head, 0x38)[0]
    else:
        shoff = struct.unpack_from('<I', head, 0x20)[0]
        shentsize = struct.unpack_from('<H', head, 0x2E)[0]
        shnum = struct.unpack_from('<H', head, 0x30)[0]
        phoff = struct.unpack_from('<I', head, 0x1C)[0]
        phentsize = struct.unpack_from('<H', head, 0x2A)[0]
        phnum = struct.unpack_from('<H', head, 0x2C)[0]
    end = 0
    if shoff and shnum and 0 < shentsize <= 128 and shnum < 65536:
        end = max(end, shoff + shnum * shentsize)
    if phoff and phnum and 0 < phentsize <= 128 and phnum < 65536:
        ph = src.read(start + phoff, min(phnum * phentsize, 4096))
        for i in range(phnum):
            p = ph[i * phentsize:(i + 1) * phentsize]
            if len(p) < 32:
                break
            if is64:
                off = struct.unpack_from('<Q', p, 8)[0]
                filesz = struct.unpack_from('<Q', p, 0x20)[0]
            else:
                off = struct.unpack_from('<I', p, 4)[0]
                filesz = struct.unpack_from('<I', p, 0x10)[0]
            end = max(end, off + filesz)
    return end if 0 < end <= max_size else None


def _end_fb2(src, start, max_size):
    off = _find_in_source(src, start + 10, max_size, b'</FictionBook>')
    return (off + len('</FictionBook>') - start) if off else None


def _end_eps(src, start, max_size):
    off = _find_in_source(src, start + 8, max_size, b'%%EOF')
    return (off + 5 - start) if off else None


def _end_erf(src, start, max_size):
    # رأس TIFF: قراءة أول IFD
    head = src.read(start, 1024)
    if len(head) < 8:
        return None
    ifd_off = _u32le(head, 4)
    if ifd_off <= 0 or ifd_off > 1024 * 1024:
        return None
    # تتبع حجم تقريبي
    return min(64 * 1024 * 1024, max_size)


def _match_jpeg(buf, off):
    if buf[off:off + 3] == b'\xFF\xD8\xFF':
        m = buf[off + 3]
        if m in (0xE0, 0xE1, 0xE2, 0xE3, 0xE8, 0xDB, 0xED, 0xEE, 0xEF) or \
                0xC0 <= m <= 0xCF and m not in (0xC4, 0xC8, 0xCC):
            return {'sig': 'JPEG', 'ext': '.jpg'}
    return None


def _match_png(buf, off):
    if buf[off:off + 8] == b'\x89PNG\r\n\x1a\n':
        return {'sig': 'PNG', 'ext': '.png'}
    return None


def _match_gif(buf, off):
    if buf[off:off + 4] == b'GIF8' and buf[off + 4:off + 6] in (b'7a', b'9a'):
        return {'sig': 'GIF', 'ext': '.gif'}
    return None


def _match_zip(buf, off):
    if buf[off:off + 4] == b'PK\x03\x04':
        return {'sig': 'ZIP', 'ext': '.zip'}
    return None


def _match_gzip(buf, off):
    if buf[off:off + 3] == b'\x1F\x8B\x08':
        return {'sig': 'GZIP', 'ext': '.gz'}
    return None


def _match_riff(buf, off):
    if buf[off:off + 4] == b'RIFF' and off + 12 <= len(buf):
        form = bytes(buf[off + 8:off + 12])
        forms = {b'WAVE': '.wav', b'AVI ': '.avi', b'ACON': '.avi',
                 b'WEBP': '.webp'}
        if form in forms:
            return {'sig': f'RIFF {form.decode("ascii", "replace").strip()}',
                    'ext': forms[form]}
    return None


def _match_exe(buf, off):
    if buf[off:off + 2] == b'MZ' and off + 0x40 <= len(buf):
        pe_off = _u32le(buf, off + 0x3C)
        if 0 < pe_off < 0x100000:
            return {'sig': 'EXE', 'ext': '.exe'}
    return None


def _match_elf(buf, off):
    if buf[off:off + 4] == b'\x7FELF':
        return {'sig': 'ELF', 'ext': '.elf'}
    return None


def _match_fb2(buf, off):
    if buf[off:off + 5] == b'<?xml' and off + 2048 <= len(buf):
        if b'FictionBook' in bytes(buf[off:off + 2048]):
            return {'sig': 'FB2', 'ext': '.fb2'}
    return None


def _match_eps(buf, off):
    head = bytes(buf[off:off + 8])
    if head.startswith(b'%!PS') or head.startswith(b'%!Adobe'):
        return {'sig': 'EPS', 'ext': '.eps'}
    return None


def _match_erf(buf, off):
    if buf[off:off + 4] == b'IIU\x00' and _u32le(buf, off + 4) == 8:
        return {'sig': 'ERF', 'ext': '.erf'}
    return None


def _match_pdf(buf, off):
    if buf[off:off + 5] == b'%PDF-':
        return {'sig': 'PDF', 'ext': '.pdf'}
    return None


def _end_pdf(src, start, max_size):
    off = _find_in_source(src, start + 5, max_size, b'%%EOF')
    return (off + 5 - start) if off else None


SIGNATURES = [
    ('JPEG', '.jpg', _match_jpeg, _end_jpeg, 256 * 1024 * 1024),
    ('PNG', '.png', _match_png, _end_png, 512 * 1024 * 1024),
    ('PDF', '.pdf', _match_pdf, _end_pdf, 512 * 1024 * 1024),
    ('GIF', '.gif', _match_gif, _end_gif, 64 * 1024 * 1024),
    ('ZIP', '.zip', _match_zip, _end_zip, 2 * 1024 * 1024 * 1024),
    ('GZIP', '.gz', _match_gzip, _end_gzip, 1024 * 1024 * 1024),
    ('RIFF', None, _match_riff, _end_riff, 8 * 1024 * 1024 * 1024),
    ('MP4', '.mp4', _match_mp4, _end_mp4, 8 * 1024 * 1024 * 1024),
    ('EXE', '.exe', _match_exe, _end_exe, 2 * 1024 * 1024 * 1024),
    ('ELF', '.elf', _match_elf, _end_elf, 2 * 1024 * 1024 * 1024),
    ('FB2', '.fb2', _match_fb2, _end_fb2, 256 * 1024 * 1024),
    ('EPS', '.eps', _match_eps, _end_eps, 512 * 1024 * 1024),
    ('ERF', '.erf', _match_erf, _end_erf, 512 * 1024 * 1024),
]

SIG_FIRST_BYTES = {
    0xFF,        # JPEG
    0x89,        # PNG
    ord('G'),    # GIF
    ord('P'),    # ZIP
    0x1F,        # GZIP
    ord('R'),    # RIFF
    ord('M'),    # EXE
    0x7F,        # ELF
    ord('<'),    # FB2
    ord('%'),    # EPS / PDF
    ord('I'),    # ERF
    0x00,        # MP4
}

MIN_FILE_SIZE = 512


class Carver:
    """ماسح تواقيع سريع فوق نطاقات محددة من المصدر"""

    def __init__(self, source, progress=None, cancel=None,
                 min_size=MIN_FILE_SIZE, step=512):
        self.src = source
        self.progress = progress
        self.cancel = cancel
        self.min_size = min_size
        self.step = step

    def scan(self, ranges, skip_extents=None):
        """ranges: [(off, len)] نطاقات الفحص
        skip_extents: نطاقات مغطاة بملفات معروفة (نطرحها)
        يعيد قائمة عناصر مكتشفة"""
        if skip_extents:
            ranges = subtract_ranges(ranges, skip_extents)
        found = []
        counter = 0
        total = sum(l for _, l in ranges)
        done = 0
        last_report = 0

        for base_off, length in ranges:
            if self.cancel and self.cancel.is_set():
                break
            pos = 0
            buf = b''
            buf_start = base_off
            chunk_read = 4 * 1024 * 1024

            while pos < length:
                if self.cancel and self.cancel.is_set():
                    break

                # قراءة كتلة 4MB مع هامش تداخل
                if pos >= buf_start - base_off + len(buf) - 64:
                    buf_start = base_off + pos
                    n = min(chunk_read, length - pos)
                    buf = self.src.read(buf_start, n + 64)
                    if not buf:
                        break
                    rel = 0
                else:
                    rel = pos - (buf_start - base_off)

                # تصفية سريعة بالبايت الأول لتسريع الحفر 6 أضعاف
                b0 = buf[rel]
                if b0 not in SIG_FIRST_BYTES:
                    pos += self.step
                    done += self.step
                    continue

                hit = None
                for name, ext, matcher, ender, maxsz in SIGNATURES:
                    m = matcher(buf, rel) if rel + 16 <= len(buf) else None
                    if m:
                        start_abs = buf_start + rel
                        size = ender(self.src, start_abs, maxsz)
                        if size and size >= self.min_size and \
                                size <= maxsz and start_abs + size <= self.src.size:
                            hit = (m['sig'], m['ext'] or ext, start_abs, size)
                            break

                if hit:
                    sig, ext, start_abs, size = hit
                    counter += 1
                    found.append({
                        'name': f'Carve_{start_abs:010X}{ext}',
                        'size': size, 'deleted': True, 'is_dir': False,
                        'path': '', 'sig': sig, 'kind': 'carved',
                        'extents': [(start_abs, size)],
                    })
                    skip = size
                else:
                    skip = self.step

                pos += skip
                done += skip

                if hit and self.step > 1:
                    new_pos = ((base_off + pos + self.step - 1)
                               // self.step) * self.step - base_off
                    done += new_pos - pos
                    pos = new_pos

                if self.progress and (done - last_report >= 4 * 1024 * 1024):
                    last_report = done
                    mb = done // (1024 * 1024)
                    self.progress('carve', done, total, f'حفر التواقيع {mb} MB (وجد {counter})')

            buf = b''

        return found
