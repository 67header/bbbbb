"""MiniSaver - محلل NTFS

قراءة قطاع الإقلاع، سجلات MFT مع مصفوفة الإصلاح (fixup)، الخصائص
المقيمة وغير المقيمة، قوائم التشغيل (data runs)، شجرة فهرس المجلدات
($INDEX_ROOT / $INDEX_ALLOCATION - INDX)، خريطة التخصيص $Bitmap،
وكشف/استرجاع الملفات المحذوفة واليتيمة.

مبني على المواصفات العامة لـ NTFS (Microsoft Open Specification).
"""
from .util import u16, u32, u64, s64, utf16le

ATTR_STD_INFO = 0x10
ATTR_ATTR_LIST = 0x20
ATTR_FILE_NAME = 0x30
ATTR_DATA = 0x80
ATTR_INDEX_ROOT = 0x90
ATTR_INDEX_ALLOC = 0xA0
ATTR_BITMAP = 0xB0

ATTR_NAMES = {
    0x10: '$STANDARD_INFORMATION', 0x20: '$ATTRIBUTE_LIST', 0x30: '$FILE_NAME',
    0x40: '$OBJECT_ID', 0x50: '$SECURITY_DESCRIPTOR', 0x60: '$VOLUME_NAME',
    0x70: '$VOLUME_INFORMATION', 0x80: '$DATA', 0x90: '$INDEX_ROOT',
    0xA0: '$INDEX_ALLOCATION', 0xB0: '$BITMAP', 0xC0: '$REPARSE_POINT',
    0x100: '$LOGGED_UTILITY_STREAM',
}

NAME_SPACES = {0: 'POSIX', 1: 'Windows', 2: 'DOS', 3: 'Windows&DOS'}


class NtfsBoot:
    def __init__(self, sec: bytes):
        if len(sec) < 512 or sec[3:11] != b'NTFS    ':
            raise ValueError('ليس قطاع إقلاع NTFS')
        self.bytes_per_sector = u16(sec, 0x0B)
        self.sectors_per_cluster = sec[0x0D]
        self.cluster_size = self.bytes_per_sector * self.sectors_per_cluster
        self.total_sectors = s64(sec, 0x28)
        self.mft_lcn = s64(sec, 0x30)
        self.mftmirr_lcn = s64(sec, 0x38)
        cpm = sec[0x40] - 256 if sec[0x40] > 127 else sec[0x40]  # قيمة موقّعة
        if cpm > 0:
            self.mft_record_size = self.cluster_size * cpm
        else:
            self.mft_record_size = 1 << (-cpm)
        cpi = sec[0x44] - 256 if sec[0x44] > 127 else sec[0x44]
        if cpi > 0:
            self.index_record_size = self.cluster_size * cpi
        else:
            self.index_record_size = 1 << (-cpi)
        self.serial = sec[0x48:0x50].hex().upper()


class Attr:
    """خاصية NTFS (مقيمة أو غير مقيمة)"""
    __slots__ = ('atype', 'name', 'non_resident', 'flags', 'value',
                 'runs', 'first_vcn', 'last_vcn', 'alloc_size',
                 'real_size', 'init_size', 'extents')

    def __init__(self):
        self.atype = 0
        self.name = ''
        self.non_resident = False
        self.flags = 0
        self.value = b''          # للخصائص المقيمة
        self.runs = []            # [(lcn|None, length_clusters)]
        self.first_vcn = self.last_vcn = 0
        self.alloc_size = self.real_size = self.init_size = 0
        self.extents = []         # [(abs_offset, bytes)] للاستخدام في نطاقات الحجز


def apply_fixup(data: bytearray, rec_size: int) -> bool:
    """تطبيق مصفوفة تحديث التسلسل (Update Sequence Array)"""
    if len(data) < 8:
        return False
    usa_off = u16(data, 4)
    usa_cnt = u16(data, 6)
    if usa_off < 0x28 or usa_cnt < 1:
        return False
    stride = rec_size // max(1, usa_cnt - 1) if usa_cnt > 1 else 512
    if stride <= 0:
        stride = 512
    ok = True
    for i in range(1, usa_cnt):
        val = data[usa_off + i * 2: usa_off + i * 2 + 2]
        sec_end = i * stride - 2
        if sec_end + 2 > len(data):
            ok = False
            break
        data[sec_end:sec_end + 2] = val
    return ok


def decode_runs(buf: bytes, off: int):
    """فك تشفير قائمة التشغيل (data runs) -> [(lcn|None, length)]"""
    runs = []
    lcn = 0
    n = len(buf)
    while off < n:
        h = buf[off]
        if h == 0:
            break
        len_n = h & 0x0F
        off_n = h >> 4
        if len_n == 0 or len_n > 8 or off_n > 8:
            break
        off += 1
        if off + len_n + off_n > n:
            break
        length = int.from_bytes(buf[off:off + len_n], 'little')
        off += len_n
        if off_n:
            delta = int.from_bytes(buf[off:off + off_n], 'little', signed=True)
            off += off_n
            lcn += delta
            if length <= 0:
                break
            runs.append((lcn, length))
        else:
            if length <= 0:
                break
            runs.append((None, length))  # عنقود متفرق (sparse)
    return runs


def parse_attr(data: bytes, off: int):
    """تحليل ترويسة خاصية واحدة عند إزاحة معينة"""
    if off + 16 > len(data):
        return None
    atype = u32(data, off)
    if atype in (0xFFFFFFFF, 0):
        return None
    alen = u32(data, off + 4)
    if alen < 24 or off + alen > len(data):
        return None
    a = Attr()
    a.atype = atype
    a.non_resident = data[off + 8]
    name_len = data[off + 9]
    name_off = u16(data, off + 10)
    a.flags = u16(data, off + 12)
    if name_len and off + name_off + name_len * 2 <= off + alen:
        a.name = utf16le(data[off + name_off: off + name_off + name_len * 2])
    if not a.non_resident:
        vlen = u32(data, off + 16)
        voff = u16(data, off + 20)
        if voff + vlen <= len(data) and off + voff + vlen <= off + alen:
            a.value = bytes(data[off + voff: off + voff + vlen])
        a.real_size = vlen
    else:
        a.first_vcn = s64(data, off + 16)
        a.last_vcn = s64(data, off + 24)
        runs_off = u16(data, off + 32)
        a.alloc_size = u64(data, off + 40)
        a.real_size = u64(data, off + 48)
        a.init_size = u64(data, off + 56)
        if runs_off:
            a.runs = decode_runs(data[off:off + alen], runs_off)
    return a


class MftRecord:
    def __init__(self, num):
        self.num = num
        self.used = False
        self.is_dir = False
        self.base_record = 0
        self.attrs = {}          # (atype, name) -> [Attr]
        self.names = []          # [(name, namespace, parent_rec)]
        self.std_info = None
        self.parse_error = None

    def first_data(self, name=''):
        lst = self.attrs.get((ATTR_DATA, name))
        return lst[0] if lst else None

    def all_data(self, name=''):
        return self.attrs.get((ATTR_DATA, name), [])

    def index_root(self):
        lst = self.attrs.get((ATTR_INDEX_ROOT, '$I30'))
        return lst[0] if lst else None

    def index_alloc(self):
        lst = self.attrs.get((ATTR_INDEX_ALLOC, '$I30'))
        return lst[0] if lst else None

    def index_bitmap(self):
        lst = self.attrs.get((ATTR_BITMAP, '$I30'))
        return lst[0] if lst else None


class NtfsParser:
    """محلل حجم NTFS كامل يبدأ من إزاحة base_offset داخل المصدر"""

    def __init__(self, source, base_offset=0, progress=None, cancel=None):
        self.src = source
        self.base = base_offset
        self.progress = progress
        self.cancel = cancel
        boot_sec = source.read(base_offset, 512)
        self.boot = NtfsBoot(boot_sec)
        self.cluster = self.boot.cluster_size
        self.mft_abs = base_offset + self.boot.mft_lcn * self.cluster
        self.rec_size = self.boot.mft_record_size
        self.indx_size = self.boot.index_record_size
        self._bitmap = None
        self._mft_count = None

    # ---------- قراءة سجلات MFT ----------

    def mft_count(self):
        if self._mft_count is not None:
            return self._mft_count
        try:
            rec0 = self.read_record(0)
        except Exception:
            rec0 = None
        if rec0:
            d = rec0.first_data()
            if d and d.real_size:
                self._mft_count = int(d.real_size // self.rec_size)
                return self._mft_count
        # احتياطي: حتى نهاية القرص
        avail = self.src.size - self.mft_abs
        self._mft_count = max(16, avail // self.rec_size)
        return self._mft_count

    def read_record(self, num):
        off = self.mft_abs + num * self.rec_size
        if off + self.rec_size > self.src.size:
            return None
        raw = self.src.read(off, self.rec_size)
        if len(raw) < self.rec_size:
            return None
        buf = bytearray(raw)
        if buf[:4] != b'FILE':
            return None
        apply_fixup(buf, self.rec_size)
        rec = MftRecord(num)
        rec.used = bool(u16(buf, 0x1E) & 1)
        rec.is_dir = bool(u16(buf, 0x1E) & 2)
        rec.base_record = u64(buf, 0x20) & 0x0000FFFFFFFFFFFF
        off_attr = u16(buf, 0x14)
        end = u16(buf, 4) if u16(buf, 4) > off_attr else self.rec_size
        end = self.rec_size
        while off_attr + 24 <= end:
            a = parse_attr(buf, off_attr)
            if a is None:
                break
            lst = rec.attrs.setdefault((a.atype, a.name), [])
            lst.append(a)
            if a.atype == ATTR_FILE_NAME and a.value:
                self._parse_fname(rec, a.value)
            elif a.atype == ATTR_STD_INFO and a.value and rec.std_info is None:
                rec.std_info = a.value[:32]
            alen = u32(buf, off_attr + 4)
            if alen <= 0:
                break
            off_attr += alen
        return rec

    def _parse_fname(self, rec, body):
        if len(body) < 66:
            return
        parent = u64(body, 0) & 0x0000FFFFFFFFFFFF
        nlen = body[0x40]
        ns = body[0x41]
        name_raw = body[0x42:0x42 + nlen * 2]
        if len(name_raw) < nlen * 2:
            return
        name = utf16le(name_raw)
        rec.names.append((name, ns, parent))

    # ---------- القراءة عبر نطاقات التشغيل ----------

    def read_stream(self, attr, offset=0, size=None, as_generator=False):
        """قراءة بيانات خاصية غير مقيمة عبر data runs"""
        if attr is None:
            return b''
        if not attr.non_resident:
            v = attr.value
            if offset:
                v = v[offset:]
            return v[:size] if size is not None else v
        total = attr.real_size if size is None else min(size, attr.real_size - offset)
        if total is None or total < 0:
            total = attr.alloc_size
        out = bytearray()
        logical = 0
        want_end = offset + total
        for lcn, ln in attr.runs:
            run_bytes = ln * self.cluster
            run_start = logical
            logical += run_bytes
            s = max(offset, run_start)
            e = min(want_end, run_start + run_bytes)
            if s >= e:
                continue
            if lcn is None:
                out.extend(b'\x00' * (e - s))
            else:
                abs_off = self.base + lcn * self.cluster + (s - run_start)
                if as_generator:
                    yield abs_off, e - s
                else:
                    out.extend(self.src.read(abs_off, e - s))
            if not as_generator and len(out) >= total:
                break
        if as_generator:
            return
        if len(out) < total:
            out.extend(b'\x00' * (total - len(out)))
        return bytes(out)

    def attr_extents(self, attr):
        """النطاقات الفيزيائية المطلقة للخاصية غير المقيمة"""
        ext = []
        logical = 0
        for lcn, ln in attr.runs:
            run_bytes = ln * self.cluster
            if lcn is not None:
                ext.append((self.base + lcn * self.cluster, run_bytes))
            logical += run_bytes
        return ext

    # ---------- خريطة التخصيص ----------

    def cluster_bitmap(self):
        if self._bitmap is not None:
            return self._bitmap
        try:
            rec = self.read_record(6)
            if rec:
                for a in rec.attrs.get((ATTR_BITMAP, ''), []):
                    if a.non_resident:
                        self._bitmap = self.read_stream(a)
                        break
                    else:
                        self._bitmap = a.value
                        break
        except Exception:
            self._bitmap = b''
        if self._bitmap is None:
            self._bitmap = b''
        return self._bitmap

    def cluster_allocated(self, lcn):
        bm = self.cluster_bitmap()
        idx = lcn // 8
        if idx >= len(bm):
            return False  # خارج الخريطة = غير معروف
        return bool(bm[idx] >> (lcn % 8) & 1)

    # ---------- شجرة المجلدات ----------

    def _parse_index_entries(self, buf, entries_off, index_len, flags, out):
        """تحليل مدخلات فهرس من عقدة (INDEX_ROOT أو INDX)"""
        if entries_off >= len(buf):
            return
        pos = entries_off
        end = min(len(buf), entries_off + max(0, index_len))
        while pos + 16 <= end:
            entry_len = u16(buf, pos + 8)
            if entry_len < 16 or pos + entry_len > end + 8:
                break
            flags_e = u16(buf, pos + 12)
            if flags_e & 0x02:  # آخر مدخلة
                break
            key_len = u16(buf, pos + 10)
            file_ref = u64(buf, pos) & 0x0000FFFFFFFFFFFF
            key = bytes(buf[pos + 16: pos + 16 + key_len]) if key_len else b''
            sub_vcn = None
            if flags_e & 0x01 and entry_len >= 8:
                sub_vcn = s64(buf, pos + entry_len - 8)
            out.append((file_ref, key, sub_vcn))
            pos += entry_len

    def _read_indx_node(self, dir_rec, vcn):
        ia = dir_rec.index_alloc()
        if not ia:
            return None
        # إيجاد مدى يحتوي هذا VCN
        logical = 0
        for lcn, ln in ia.runs:
            if lcn is None:
                logical += ln
                continue
            if logical <= vcn < logical + ln:
                abs_off = self.base + (lcn + (vcn - logical)) * self.indx_size
                raw = bytearray(self.src.read(abs_off, self.indx_size))
                if raw[:4] != b'INDX':
                    return None
                apply_fixup(raw, self.indx_size)
                eo = u16(raw, 0x18)
                il = u16(raw, 0x1A)
                fl = raw[0x1C]
                return (raw, eo, il, fl)
            logical += ln
        return None

    def walk_index(self, dir_rec, visited_dirs=None, depth=0):
        """اجتياز شجرة فهرس المجلد -> [(file_ref, file_name_bytes)]"""
        if depth > 32:
            return []
        if visited_dirs is None:
            visited_dirs = set()
        if dir_rec.num in visited_dirs:
            return []
        visited_dirs.add(dir_rec.num)
        entries = []
        ir = dir_rec.index_root()
        if ir is None or not ir.value:
            return entries
        v = ir.value
        if len(v) < 24:
            return entries
        eo = u16(v, 0x14)
        il = u16(v, 0x16)
        fl = v[0x18]
        self._parse_index_entries(v, 0x14 + eo, il, fl, entries)
        # العقد الفرعية
        for _ref, _key, sub_vcn in list(entries):
            if sub_vcn is None:
                continue
            node = self._read_indx_node(dir_rec, sub_vcn)
            if node:
                sub = []
                self._parse_index_entries(node[0], 0x18 + node[1], node[2], node[3], sub)
                entries.extend(sub)
        return entries

    # ---------- المسح الرئيسي ----------

    def scan(self):
        """إرجاع (قائمة ملفات سليمة، قائمة محذوفة/يتيمة، معلومات)"""
        total = self.mft_count()
        records = {}
        if self.progress:
            self.progress('mft', 0, total, 'قراءة سجلات MFT')

        def _note(i, t):
            if self.progress:
                self.progress('mft', i, total, f'MFT {i}/{t}')
            if self.cancel and self.cancel.is_set():
                raise InterruptedError('أُلغي الفحص')

        for n in range(min(total, 4_000_000)):
            _note(n, total)
            try:
                rec = self.read_record(n)
            except Exception:
                continue
            if rec:
                records[n] = rec

        live = []
        lost = []
        visited = set()

        def file_info(rec, name, namespace, parent, deleted=False):
            data = rec.first_data()
            size = 0
            ext = []
            if data:
                size = data.real_size or len(data.value)
                ext = self.attr_extents(data) if data.non_resident else []
            return {
                'record': rec.num, 'name': name, 'namespace': namespace,
                'parent': parent, 'size': size, 'deleted': deleted,
                'is_dir': rec.is_dir, 'extents': ext,
                'record_ref': rec,
            }

        # 1) اجتياز الشجرة من الجذر (5)
        def walk_dir(rec, parent_path, depth=0):
            if depth > 64 or self.cancel and self.cancel.is_set():
                return
            for ref, key, _sub in self.walk_index(rec, depth=depth):
                if not key or len(key) < 0x42:
                    continue
                nlen = key[0x40]
                name = utf16le(key[0x42:0x42 + nlen * 2]) if nlen else '?'
                child = records.get(ref)
                if child is None:
                    continue
                visited.add(ref)
                ns = key[0x41]
                if child.is_dir:
                    path = f'{parent_path}{name}\\'
                    live.append(file_info(child, name, ns, rec.num, deleted=False))
                    live[-1]['path'] = path
                    walk_dir(child, path, depth + 1)
                else:
                    live.append(file_info(child, name, ns, rec.num, deleted=False))
                    live[-1]['path'] = parent_path

        root = records.get(5)
        if root:
            visited.add(5)
            walk_dir(root, '')

        # 2) السجلات المحذوفة واليتيمة
        if self.progress:
            self.progress('lost', 0, len(records), 'فحص المحذوف واليتيم')
        for n, rec in sorted(records.items()):
            if self.cancel and self.cancel.is_set():
                break
            if n <= 15 and n != 5:
                continue
            if rec.num in visited:
                continue
            if not rec.names:
                continue
            name, ns, parent = rec.names[0]
            deleted_marker = name.startswith('\x00')
            clean = name.lstrip('\x00').strip() or f'#{rec.num}'
            is_lost = (not rec.used) or deleted_marker or parent == 0
            if not is_lost:
                continue  # ملف سليم لم يُعثر على أثره في الفهرس (يتيم ظرفي)
            info = file_info(rec, clean, ns, parent, deleted=True)
            info['path'] = ''
            lost.append(info)

        info = {
            'fs': 'NTFS',
            'serial': self.boot.serial,
            'cluster_size': self.cluster,
            'mft_records': total,
        }
        return live, lost, info
