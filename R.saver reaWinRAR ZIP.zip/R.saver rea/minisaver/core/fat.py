"""MiniSaver - محلل FAT12/16/32

قراءة قطاع إقلاع BIOS Parameter Block، جداول التخصيص FAT (12/16/32 بت)،
الدليل الجذر، مدخلات الدليل 32 بايت مع الأسماء الطويلة LFN (UTF-16LE)،
سلاسل العناقيد، واسترجاع الملفات والمجلدات المحذوفة (المحذوفين يحملون
0xE5 في البايت الأول وتُصفَّر سلاسلهم في FAT فنفترض التخصيص المتتالي).

مبني على المواصفات العامة لـ Microsoft extensible FAT (EFAT).
"""
from .util import u16, u32, oem1251, utf16le

ATTR_RO = 0x01
ATTR_HIDDEN = 0x02
ATTR_SYSTEM = 0x04
ATTR_VOLUME = 0x08
ATTR_DIR = 0x10
ATTR_ARCHIVE = 0x20
ATTR_LFN = 0x0F
ATTR_MASK = 0x3F

BAD12, BAD16, BAD32 = 0x0FF7, 0xFFF7, 0x0FFFFFF7
MAX_LFN_PARTS = 20


def lfn_checksum(short: bytes) -> int:
    s = 0
    for b in short:
        s = (((s & 1) << 7) + (s >> 1) + b) & 0xFF
    return s


def dos_datetime(t: int, d: int) -> str:
    try:
        sec = (t & 0x1F) * 2
        mi = (t >> 5) & 0x3F
        hr = (t >> 11) & 0x1F
        day = d & 0x1F
        mon = (d >> 5) & 0x0F
        yr = ((d >> 9) & 0x7F) + 1980
        if not (1 <= mon <= 12 and 1 <= day <= 31):
            return ''
        return f'{yr:04d}-{mon:02d}-{day:02d} {hr:02d}:{mi:02d}:{sec:02d}'
    except Exception:
        return ''


def _lfn_chars(e: bytes) -> str:
    """13 حرف UTF-16LE من مدخلة LFN (1-10، 14-25، 28-31)"""
    raw = e[1:11] + e[14:26] + e[28:32]
    s = ''
    for i in range(0, len(raw) - 1, 2):
        ch = raw[i] | (raw[i + 1] << 8)
        if ch == 0x0000:
            break
        if ch == 0xFFFF:
            continue
        s += chr(ch)
    return s


class FatBoot:
    def __init__(self, sec: bytes):
        if len(sec) < 512:
            raise ValueError('قطاع الإقلاع قصير')
        self.oem = sec[3:11]
        self.bytes_per_sector = u16(sec, 11)
        self.sectors_per_cluster = sec[13]
        self.reserved = u16(sec, 14)
        self.num_fats = sec[16]
        self.root_entries = u16(sec, 17)
        self.total_sectors = u16(sec, 19) or u32(sec, 32)
        self.media = sec[21]
        self.fat_size = u16(sec, 22)
        self.root_cluster = 0
        if self.fat_size == 0:
            self.fat_size = u32(sec, 36)          # FAT32
            self.root_cluster = u32(sec, 44) or 2
        if (self.bytes_per_sector not in (128, 256, 512, 1024, 2048, 4096)
                or self.sectors_per_cluster == 0
                or self.sectors_per_cluster & (self.sectors_per_cluster - 1)
                or self.reserved < 1 or self.num_fats < 1 or self.num_fats > 8
                or self.fat_size == 0 or self.total_sectors == 0):
            raise ValueError('BPB غير صالح')
        self.cluster_size = self.bytes_per_sector * self.sectors_per_cluster
        self.fat_start = self.reserved                       # قطاعات
        self.fat_bytes = self.fat_size * self.bytes_per_sector
        root_sectors = (self.root_entries * 32 + self.bytes_per_sector - 1) \
            // self.bytes_per_sector
        self.root_start = self.fat_start + self.num_fats * self.fat_size
        self.data_start = self.root_start + root_sectors     # قطاعات
        self.cluster_count = (self.total_sectors - self.data_start) \
            // self.sectors_per_cluster
        if self.cluster_count < 4085:
            self.fs_type = 'FAT12'
        elif self.cluster_count < 65525:
            self.fs_type = 'FAT16'
        else:
            self.fs_type = 'FAT32'
        if self.fs_type != 'FAT32':
            self.root_cluster = 0


class FatParser:
    """محلل حجم FAT كامل يبدأ من إزاحة base_offset داخل المصدر"""

    def __init__(self, source, base_offset=0, progress=None, cancel=None):
        self.src = source
        self.base = base_offset
        self.progress = progress
        self.cancel = cancel
        self.boot = FatBoot(source.read(base_offset, 512))
        self.cluster = self.boot.cluster_size
        self.fs_type = self.boot.fs_type
        self._fat = None
        self._visited_dirs = set()
        self.volume_label = ''
        self.volume_id = ''

    # ---------- جدول التخصيص ----------

    def _load_fat(self):
        if self._fat is not None:
            return
        off = self.base + self.boot.fat_start * self.boot.bytes_per_sector
        self._fat = self.src.read(off, self.boot.fat_bytes)

    def fat_entry(self, n: int) -> int:
        """قيمة مدخلة FAT (0 = حرة، قيم EOC الكبرى = نهاية)"""
        self._load_fat()
        f = self._fat
        if self.fs_type == 'FAT12':
            off = n + (n >> 1)
            if off + 1 >= len(f):
                return 0
            if n & 1:
                v = (f[off] >> 4) | (f[off + 1] << 4)
            else:
                v = f[off] | ((f[off + 1] & 0x0F) << 8)
            if v >= 0x0FF8:
                return 0x0FFF          # EOC
            if v == 0x0FF7:
                return 0               # عنقود تالف = غير قابل للاستخدام
            return v
        if self.fs_type == 'FAT16':
            off = n * 2
            if off + 2 > len(f):
                return 0
            v = u16(f, off)
            if v >= 0xFFF8:
                return 0xFFFF
            if v == 0xFFF7:
                return 0
            return v
        off = n * 4
        if off + 4 > len(f):
            return 0
        v = u32(f, off) & 0x0FFFFFFF
        if v >= 0x0FFFFFF8:
            return 0x0FFFFFFF
        if v == 0x0FFFFFF7:
            return 0
        return v

    def chain(self, start: int, max_clusters=None):
        """سلسلة عناقيد من FAT مع حماية من الحلقات"""
        out = []
        seen = set()
        c = start
        total = self.boot.cluster_count
        limit = max_clusters or total
        while 2 <= c < total + 2 and len(out) < limit:
            if c in seen:
                break
            seen.add(c)
            out.append(c)
            nxt = self.fat_entry(c)
            if nxt < 2:
                break
            c = nxt
        return out

    def cluster_abs(self, c: int) -> int:
        b = self.boot
        return self.base + (b.data_start + (c - 2) * b.sectors_per_cluster) \
            * b.bytes_per_sector

    def chain_extents(self, clusters):
        """دمج العناقيد المتتالية -> [(abs_off, bytes)]"""
        ext = []
        i = 0
        while i < len(clusters):
            j = i
            while j + 1 < len(clusters) and clusters[j + 1] == clusters[j] + 1:
                j += 1
            ext.append((self.cluster_abs(clusters[i]),
                        (j - i + 1) * self.cluster))
            i = j + 1
        return ext

    def _read_chain(self, clusters, cap=16 * 1024 * 1024):
        """قراءة سلسلة عناقيد كاملة في الذاكرة (للأدلة فقط)"""
        out = bytearray()
        for c in clusters:
            if len(out) >= cap:
                break
            out.extend(self.src.read(self.cluster_abs(c), self.cluster))
        return bytes(out)

    # ---------- مدخلات الدليل ----------

    def _parse_entries(self, buf, path, live, lost, is_recovered_dir=False):
        """تحليل كتلة دليل: مدخلات قصيرة + LFN + المحذوف"""
        i = 0
        n_slots = len(buf) // 32
        lfn_parts = []          # [(idx، نص)]
        while i < n_slots:
            e = buf[i * 32:(i + 1) * 32]
            if e == b'\x00' * 32:
                i += 1
                continue
            attr = e[11]
            first = e[0]
            deleted = first == 0xE5
            if (attr & ATTR_MASK) == ATTR_LFN or (attr == 0x0F):
                if deleted:
                    # المحذوف: السلسلة فقدت رقمها؛ نحفظها بالترتيب المعاكس
                    lfn_parts.append((i, _lfn_chars(b'\x00' + e[1:])))
                else:
                    seq = first
                    lfn_parts.append((i, _lfn_chars(e), seq, e[13]))
                i += 1
                continue
            # مدخلة قصيرة (حقيقية أو محذوفة)
            short_raw = e[0:11]
            attr = e[11]
            is_lfn_orphan = (attr & ATTR_MASK) == ATTR_LFN
            if is_lfn_orphan:
                i += 1
                continue
            cluster = u16(e, 26)
            if self.fs_type == 'FAT32':
                cluster |= u16(e, 20) << 16
            size = u32(e, 28)
            is_dir = bool(attr & ATTR_DIR)
            is_vol = bool(attr & ATTR_VOLUME) and not is_dir
            # الاسم
            name = None
            if lfn_parts:
                frags = [p[1] for p in lfn_parts]
                frags.reverse()                      # ترتيب القرص معكوس
                cand = ''.join(frags)
                cand = cand.split('\x00', 1)[0].strip()
                if cand and len(cand) <= 255:
                    name = cand
                lfn_parts = []
            if name is None:
                base = oem1251(short_raw[0:8]).rstrip()
                ext = oem1251(short_raw[8:11]).rstrip()
                if deleted:
                    base = '_' + base[1:] if len(base) else '_'
                name = f'{base}.{ext}' if ext else base
            if is_vol:
                if not deleted and not is_recovered_dir:
                    self.volume_label = name.strip()
                i += 1
                continue
            if name in ('.', '..'):
                i += 1
                continue
            mtime = dos_datetime(u16(e, 22), u16(e, 24))
            item = {
                'name': name, 'size': 0 if is_dir else size,
                'deleted': deleted, 'is_dir': is_dir,
                'cluster': cluster, 'mtime': mtime,
                'first_byte_lost': deleted,
            }
            # نطاقات البيانات
            item['extents'] = self._extents_for(item)
            entries = live if not deleted else lost
            item['path'] = path
            entries.append(item)
            # مجلد: متابعة
            if is_dir and 2 <= cluster < self.boot.cluster_count + 2:
                key = (path, cluster)
                if cluster not in self._visited_dirs:
                    self._visited_dirs.add(cluster)
                    sub_path = f'{path}{name}\\'
                    if deleted:
                        self._recover_dir_tree(item, sub_path, lost)
                    else:
                        sub = self._read_chain(self.chain(cluster))
                        self._parse_entries(sub, sub_path, live, lost)
            i += 1

    def _extents_for(self, item):
        cl = item['cluster']
        if cl < 2:
            return []
        if item['deleted']:
            # المحذوف: سلسلة FAT مُصفَّرة -> افتراض تخصيص متتالٍ
            need = (item['size'] + self.cluster - 1) // self.cluster if \
                item['size'] else 0
            if item['is_dir'] or need == 0:
                need = min(max(need, 1), 64) if item['is_dir'] else 0
            if need == 0:
                return []
            first = self.cluster_abs(cl)
            end = first + need * self.cluster
            if end > self.src.size:
                need = max(0, (self.src.size - first) // self.cluster)
                if need == 0:
                    return []
            return [(first, need * self.cluster)]
        return self.chain_extents(self.chain(cl))

    def _recover_dir_tree(self, item, path, lost):
        """محاولة استرجاع شجرة مجلد محذوف (عناقيد متتالية)"""
        ext = item['extents']
        if not ext:
            return
        start, ln = ext[0]
        max_cl = min(ln // self.cluster, 512)
        i = 0
        while i < max_cl:
            buf = self.src.read(start + i * self.cluster, self.cluster)
            if buf == b'\x00' * len(buf):
                break
            sub_live, _ = [], []
            self._parse_entries(buf, path, sub_live, lost,
                                is_recovered_dir=True)
            # أفراد المجلد المحذوف كلهم يذهبون إلى المحذوف
            for it in sub_live:
                it['deleted'] = True
                lost.append(it)
            i += 1

    # ---------- العناقيد اليتيمة ----------

    def find_orphans(self, live, lost, max_orphans=5000, progress=None):
        """سلاسل FAT غير مشار إليها من أي دليل -> ملفات/أدلة يتيمة"""
        self._load_fat()
        total = self.boot.cluster_count
        referenced = set()
        for it in live + lost:
            for off, ln in it.get('extents', []):
                if off is None:
                    continue
                c0 = ((off - self.cluster_abs(2)) // self.cluster) + 2
                for c in range(c0, c0 + max(1, ln // self.cluster)):
                    if 2 <= c < total + 2:
                        referenced.add(c)
        found = 0
        c = 2
        while c < total + 2 and found < max_orphans:
            if self.progress and c % 65536 == 0:
                self.progress('orphans', c, total, f'العناقيد اليتيمة {c}/{total}')
            if self.cancel and self.cancel.is_set():
                break
            v = self.fat_entry(c)
            if v != 0 and c not in referenced:
                ch = self.chain(c)
                for x in ch:
                    referenced.add(x)
                found += 1
                ext = self.chain_extents(ch)
                head = self.src.read(self.cluster_abs(c), min(512, self.cluster))
                looks_dir = self._sniff_dir(head)
                name = (f'DIR_{c:07d}' if looks_dir else f'ORPH_{c:07d}')
                item = {
                    'name': name, 'size': sum(l for _, l in ext) if not looks_dir else 0,
                    'deleted': True, 'is_dir': looks_dir, 'cluster': c,
                    'mtime': '', 'extents': ext, 'path': '', 'orphan': True,
                }
                lost.append(item)
                if looks_dir:
                    sub_live = []
                    buf = self._read_chain(ch)
                    self._parse_entries(buf, '', sub_live, lost,
                                        is_recovered_dir=True)
                    for it in sub_live:
                        it['deleted'] = True
                        lost.append(it)
                c = (ch[-1] + 1) if ch else c + 1
            else:
                c += 1

    def _sniff_dir(self, head: bytes) -> bool:
        if len(head) < 32:
            return False
        e = head[:32]
        if e == b'\x00' * 32 or e[0] in (0x00, 0xE5):
            return False
        attr = e[11]
        if attr & ~0x3F and attr != 0x0F:
            return False
        if attr == 0x0F:
            return False
        name = e[0:11]
        ok = all(32 <= b < 127 or b >= 0x80 for b in name)
        size = u32(e, 28)
        cluster = u16(e, 26) | (u16(e, 20) << 16)
        return ok and (attr & (ATTR_DIR | ATTR_ARCHIVE | ATTR_VOLUME)) and \
            (size < (1 << 31)) and (cluster < self.boot.cluster_count + 2)

    # ---------- نطاقات الحرة ----------

    def free_ranges(self, referenced_extra=None):
        """فترات العناقيد الحرة (FAT==0) للحفر - [(abs_off, bytes)]"""
        self._load_fat()
        used = set(referenced_extra or ())
        total = self.boot.cluster_count
        out = []
        run_start = None
        for c in range(2, total + 2):
            free = self.fat_entry(c) == 0 and c not in used
            off = self.cluster_abs(c)
            if free and run_start is None:
                run_start = off
            elif not free and run_start is not None:
                out.append((run_start, off - run_start))
                run_start = None
        if run_start is not None:
            out.append((run_start, self.cluster_abs(total + 1) - run_start))
        return out

    # ---------- المسح الرئيسي ----------

    def scan(self, find_orphans=True):
        """إرجاع (قائمة سليمة، قائمة محذوف/يتيم، معلومات)"""
        self._load_fat()
        live, lost = [], []
        self._visited_dirs = set()
        b = self.boot
        if self.progress:
            self.progress('fat', 0, 1, f'تحليل {self.fs_type} - {b.cluster_count} عنقود')
        if self.fs_type == 'FAT32':
            root = self._read_chain(self.chain(b.root_cluster))
        else:
            root = self.src.read(
                self.base + b.root_start * b.bytes_per_sector,
                b.root_entries * 32)
        # الرقم التسلسلي
        s_off = 67 if self.fs_type == 'FAT32' else 39
        sec = self.src.read(self.base, 96)
        self.volume_id = sec[s_off:s_off + 4].hex().upper()
        self._parse_entries(root, '', live, lost)
        if find_orphans:
            self.find_orphans(live, lost)
        info = {
            'fs': self.fs_type,
            'serial': self.volume_id,
            'cluster_size': self.cluster,
            'label': self.volume_label,
            'clusters': b.cluster_count,
        }
        return live, lost, info
