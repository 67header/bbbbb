"""MiniSaver - أدوات مساعدة مشتركة

إعادة تنفيذ نظيفة (clean-room) لمفاهيم أداة استرجاع البيانات،
مبنية على المواصفات العامة لأنظمة الملفات NTFS / FAT / exFAT.
"""
import struct


def u8(b, o=0):
    return b[o]


def u16(b, o=0):
    return struct.unpack_from('<H', b, o)[0]


def u32(b, o=0):
    return struct.unpack_from('<I', b, o)[0]


def u64(b, o=0):
    return struct.unpack_from('<Q', b, o)[0]


def s64(b, o=0):
    return struct.unpack_from('<q', b, o)[0]


def utf16le(raw: bytes) -> str:
    """فك ترميز UTF-16LE (أسماء الملفات في NTFS/exFAT/LFN)"""
    return raw.decode('utf-16-le', errors='replace')


def oem1251(raw: bytes) -> str:
    """فك ترميز OEM/CP1251 (أسماء DOS قصيرة في FAT)"""
    try:
        return raw.decode('cp437')
    except Exception:
        return raw.decode('cp1251', errors='replace')


def hexdump(b, limit=256):
    out = []
    for i in range(0, min(len(b), limit), 16):
        chunk = b[i:i + 16]
        hexs = ' '.join(f'{x:02X}' for x in chunk)
        asc = ''.join(chr(x) if 32 <= x < 127 else '.' for x in chunk)
        out.append(f'{i:08X}  {hexs:<47}  {asc}')
    return '\n'.join(out)


def human_size(n):
    n = float(n)
    for unit in ('B', 'KB', 'MB', 'GB', 'TB'):
        if n < 1024 or unit == 'TB':
            return f'{int(n)} {unit}' if unit == 'B' else f'{n:.1f} {unit}'
        n /= 1024.0


def safe_name(name: str) -> str:
    """تنظيف اسم الملف/المجلد للاستخدام في ويندوز"""
    cleaned = []
    for ch in name:
        o = ord(ch)
        if o < 32 or ch in '<>:"|?*':
            continue
        cleaned.append(ch)
    s = ''.join(cleaned).replace('/', '_').replace('\\', '_')
    s = s.rstrip('. ')
    return s.strip() or 'unnamed'


def unique_path(path: str) -> str:
    """إنشاء مسار غير موجود: name.ext -> name (2).ext"""
    import os
    if not os.path.exists(path):
        return path
    base, ext = os.path.splitext(path)
    i = 2
    while True:
        cand = f'{base} ({i}){ext}'
        if not os.path.exists(cand):
            return cand
        i += 1
