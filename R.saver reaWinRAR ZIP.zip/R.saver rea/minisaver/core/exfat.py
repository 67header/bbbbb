"""MiniSaver - محلل exFAT

قراءة قطاع إقلاع exFAT، جدول FAT، كومة العناقيد، مجموعات مدخلات الدليل
(ملف 0x85 + امتداد مجرى 0xC0 + امتدادات أسماء 0xC1)، التحقق بمجموع
الاختبار checksum لمجموعة المدخلات، واسترجاع المحذوف: الحذف في exFAT
يُصفّر البت الأعلى من نوع المدخلة فقط (0x85->0x05) فيبقى الأول-عنقود
والحجم والاسم قابلين للاستعادة، وغالباً تبقى سلسلة FAT سليمة.

مبني على المواصفات العامة لـ Microsoft exFAT 1.00.
"""
from .util import u16, u32, u64, utf16le

# أنواع المدخلات
E_BITMAP = 0x81
E_UPCASE = 0x82
E_LABEL = 0x83
E_FILE = 0x85
E_STREAM = 0xC0
E_NAME = 0xC1

DELETED_BIT = 0x80          # البت الأعلى: 1 = مستخدم، 0 = محذوف

NAME_CHARS_PER_ENTRY = 15


def exfat_checksum(data: bytes, secondary_count: int) -> int:
    """مجموع اختبار مجموعة المدخلات حسب المواصفة (يستثني حقل المجموع)"""
    chk = 0
    entries = secondary_count + 1
    for i in range(entries):
        for j in range(0, 32, 2):
            if i == 0 and j in (2, 3):
                continue
            off = i * 32 + j
            if off + 2 > len(data):
                break
            chk = (((chk << 15) | (chk >> 1)) + u16(data, off)) & 0xFFFF
    return chk


def exfat_time(ts: int) -> str:
    try:
        sec2 = ts & 0x1F
        mi = (ts >> 5) & 0x3F
        hr = (ts >> 11) & 0x1F
        day = (ts >> 16) & 0x1F
        mon = (ts >> 21) & 0x0F
        yr = ((ts >> 25) & 0x7F) + 1980
        if not (1 <= mon <= 12 and 1 <= day <= 31):
            return ''
        return f'{yr:04d}-{mon:02d}-{day:02d} {hr:02d}:{mi:02d}:{sec2 * 2:02d}'
    except Exception:
        return ''


class ExFatBoot:
    def __init__(self, sec: bytes):
        if len(sec) < 512 or sec[3:11] != b'EXFAT   ':
            raise ValueError('ليس قطاع إقلاع exFAT')
        self.bytes_per_sector = 1 << sec[100]
        self.sectors_per_cluster = 1 << sec[101]
        self.num_fats = sec[102] or 1
        self.cluster_size = self.bytes_per_sector * self.sectors_per_cluster
        self.volume_sectors = u64(sec, 64)
        self.fat_off = u32(sec, 72)
        self.fat_len = u32(sec, 76)
        self.heap_off = u32(sec, 80)
        self.cluster_count = u32(sec, 84)
        self.root_cluster = u32(sec, 88) or 2
        self.serial = u32(sec, 92)
        if not (512 <= self.bytes_per_sector <= 4096 * 8
                or 512 <= self.bytes_per_sector <= 32768):
            raise ValueError('حجم قطاع غير منطقي')
        if self.cluster_count == 0 or self.cluster_size == 0:
            raise ValueError('BPB غير صالح')


class ExFatParser:
    """محلل حجم exFAT كامل يبدأ من إزاحة base_offset داخل المصدر"""

    def __init__(self, source, base_offset=0, progress=None, cancel=None):
        self.src = source
        self.base = base_offset
        self.progress = progress
        self.cancel = cancel
        sec = source.read(base_offset, 512)
        self.boot = ExFatBoot(sec)
        self.cluster = self.boot.cluster_size
        self._fat = None
        self._bitmap = None
        self._visited_dirs = set()
        self.volume_label = ''

    # ---------- FAT وسلاسل العناقيد ----------

    def _load_fat(self):
        if self._fat is not None:
            return
        b = self.boot
        off = self.base + b.fat_off * b.bytes_per_sector
        self._fat = self.src.read(off, b.fat_len * b.bytes_per_sector)

    def fat_entry(self, n: int) -> int:
        self._load_fat()
        off = n * 4
        if off + 4 > len(self._fat):
            return 0
        return u32(self._fat, off)

    def cluster_abs(self, c: int) -> int:
        b = self.boot
        return self.base + (b.heap_off + (c - 2) * b.sectors_per_cluster) \
            * b.bytes_per_sector

    def chain(self, start, count=None, no_fat=False):
        """سلسلة عناقيد؛ مع no_fat=true تكون متتالية بدون FAT"""
        b = self.boot
        if no_fat:
            return list(range(start, min(start + (count or 0), b.cluster_count + 2)))
        out = []
        seen = set()
        c = start
        total = b.cluster_count
        while 2 <= c < total + 2 and len(out) < (count or total):
            if c in seen:
                break
            seen.add(c)
            out.append(c)
            if count and len(out) >= count:
                break
            v = self.fat_entry(c) & 0xFFFFFFFF
            if v < 2:
                break                      # حرة = نهاية (أو مُصفَّرة بعد الحذف)
            if v >= 0xFFFFFFF8:
                break                      # EOC
            c = v
        return out

    def chain_extents(self, clusters):
        ext = []
        i = 0
        while i < len(clusters):
            j = i
            while j + 1 < len(clusters) and clusters[j + 1] == clusters[j] + 1:
                j += 1
            ext.append((self.cluster_abs(clusters[i]),
                        (j - i + 1) * self.cluster))
            i = j + 1
        return ext

    def _read_chain(self, clusters, cap=16 * 1024 * 1024):
        out = bytearray()
        for c in clusters:
            if len(out) >= cap:
                break
            out.extend(self.src.read(self.cluster_abs(c), self.cluster))
        return bytes(out)

    # ---------- تحليل مجموعة مدخلات ----------

    def _parse_entry_set(self, buf, off, deleted_ok=False):
        """تحليل مجموعة (ملف+امتدادات) عند off
        يعيد dict أو None. يتحقق بمجموع الاختبار."""
        t = buf[off] if off < len(buf) else 0
        if t in (E_FILE, E_FILE & ~DELETED_BIT):
            deleted = t == (E_FILE & ~DELETED_BIT)
            if deleted and not deleted_ok:
                return None
            if off + 32 > len(buf):
                return None
            sec_count = buf[off + 1]
            if not (1 <= sec_count <= 18):
                return None
            if off + 32 * (sec_count + 1) > len(buf):
                return None
            stored = u16(buf, off + 2)
            calc = exfat_checksum(buf[off: off + 32 * (sec_count + 1)],
                                  sec_count)
            checksum_ok = stored == calc
            attr = u16(buf, off + 4)
            mtime = exfat_time(u32(buf, off + 12))
            # امتداد المجرى
            s_off = off + 32
            st = buf[s_off]
            if st not in (E_STREAM, E_STREAM & ~DELETED_BIT):
                return None
            flags = buf[s_off + 1]
            name_len = buf[s_off + 3]
            if not (1 <= name_len <= 255):
                return None
            valid_len = u64(buf, s_off + 8)
            first_cluster = u32(buf, s_off + 20)
            data_len = u64(buf, s_off + 24)
            no_fat = bool(flags & 0x02)
            # امتدادات الاسم
            name_parts = []
            for k in range(1, sec_count):
                n_off = off + 32 * (k + 1)
                nt = buf[n_off]
                if nt != E_NAME and nt != (E_NAME & ~DELETED_BIT):
                    return None
                raw = buf[n_off + 2: n_off + 32]
                name_parts.append(raw.decode('utf-16-le', errors='replace'))
            name = ''.join(name_parts)
            name = name[:name_len]
            if deleted and not checksum_ok:
                return None               # نرفض المزيفات
            return {
                'name': name, 'attr': attr, 'deleted': deleted,
                'is_dir': bool(attr & 0x10),
                'size': data_len, 'valid_size': min(valid_len, data_len),
                'first_cluster': first_cluster, 'no_fat': no_fat,
                'mtime': mtime, 'checksum_ok': checksum_ok,
            }
        return None

    def _item_extents(self, ent):
        b = self.boot
        cl = ent['first_cluster']
        size = ent['size']
        if cl < 2 or size == 0:
            return []
        need = (size + self.cluster - 1) // self.cluster
        if ent['no_fat']:
            clusters = self.chain(cl, count=need, no_fat=True)
            if len(clusters) < need:
                return []                  # الحجم لا يتسع في الكومة
            return self.chain_extents(clusters)
        clusters = self.chain(cl, count=need)
        if len(clusters) < need:
            # السلسلة قُطعت (حذف قديم) -> متتالي كاحتياط
            clusters = list(range(cl, min(cl + need, b.cluster_count + 2)))
            if len(clusters) < need:
                return []
        ext = self.chain_extents(clusters)
        # قص الفائض في آخر عنقود
        total = need * self.cluster
        if total > size:
            last_off, last_len = ext[-1]
            trim = total - size
            if trim < last_len:
                ext[-1] = (last_off, last_len - trim)
        return ext

    # ---------- تحليل دليل ----------

    def _parse_dir(self, buf, path, live, lost, is_recovered=False):
        n = len(buf) // 32
        i = 0
        while i < n:
            off = i * 32
            t = buf[off]
            if t in (0x00, 0xFF):
                i += 1
                continue
            if t in (E_FILE, E_FILE & ~DELETED_BIT):
                ent = self._parse_entry_set(buf, off, deleted_ok=True)
                if ent is None:
                    i += 1
                    continue
                consumed = 1 + buf[off + 1]
                name = ent['name'] or f'#{off // 32}'
                item = {
                    'name': name, 'size': 0 if ent['is_dir'] else ent['size'],
                    'deleted': ent['deleted'], 'is_dir': ent['is_dir'],
                    'mtime': ent['mtime'], 'first_byte_lost': False,
                    'checksum_ok': ent['checksum_ok'],
                }
                item['extents'] = self._item_extents(ent) if not ent['is_dir'] \
                    else self._dir_extents(ent)
                entries = lost if ent['deleted'] else live
                item['path'] = path
                entries.append(item)
                if ent['is_dir']:
                    key = (path, ent['first_cluster'])
                    if ent['first_cluster'] >= 2 and \
                            key not in self._visited_dirs:
                        self._visited_dirs.add(key)
                        sub_path = f'{path}{name}\\'
                        if ent['deleted']:
                            self._recover_subtree(ent, sub_path, lost)
                        else:
                            self._walk_dir(ent, sub_path, live, lost)
                i += consumed
                continue
            if t == E_LABEL or t == (E_LABEL & ~DELETED_BIT):
                cnt = buf[off + 1]
                if 0 < cnt <= 31 and off + 2 + cnt * 2 <= len(buf):
                    label = utf16le(buf[off + 2: off + 2 + cnt * 2])
                    if not t & DELETED_BIT and label.strip():
                        self.volume_label = label.strip()
                i += 1
                continue
            if t == E_BITMAP and not is_recovered:
                self._bitmap = (u32(buf, off + 20), u32(buf, off + 24),
                                buf[off + 1])
                i += 1
                continue
            i += 1

    def _dir_extents(self, ent):
        """نطاقات عناقيد الدليل نفسه (للحفر والحماية)"""
        cl = ent['first_cluster']
        if cl < 2:
            return []
        # الدليل: نقرأه كاملاً دون حد معروف - نحسب حتى EOC أو سقف
        clusters = self.chain(cl, count=1024)
        return self.chain_extents(clusters)

    def _walk_dir(self, ent, path, live, lost, cap=64 * 1024 * 1024):
        clusters = self.chain(ent['first_cluster'], count=1024)
        buf = self._read_chain(clusters, cap=cap)
        self._parse_dir(buf, path, live, lost)

    def _recover_subtree(self, ent, path, lost):
        """مجلد محذوف: نقرأ عناقيده المتوفرة ونحلل ما بداخلها"""
        ext = self._dir_extents(ent)
        if not ext:
            return
        start, total = ext[0][0], sum(l for _, l in ext)
        # المجلد المحذوف قد تكون سلسلته متقطعة؛ نقرأ الموجود
        for off, ln in ext[:256]:
            buf = self.src.read(off, ln)
            if buf == b'\x00' * len(buf):
                break
            sub_live = []
            self._parse_dir(buf, path, sub_live, lost, is_recovered=True)
            for it in sub_live:
                it['deleted'] = True
                lost.append(it)

    # ---------- خريطة التخصيص ----------

    def _load_bitmap(self):
        if self._bitmap is not None and isinstance(self._bitmap, bytes):
            return self._bitmap
        bm = b''
        if isinstance(self._bitmap, tuple):
            first_cl, length, flags = self._bitmap
            if first_cl >= 2 and length:
                bm = self.src.read(self.cluster_abs(first_cl), min(length,
                                   64 * 1024 * 1024))
        self._bitmap = bm
        return bm

    def cluster_allocated(self, c: int) -> bool:
        bm = self._load_bitmap()
        idx = c // 8
        if idx >= len(bm):
            return False
        return bool(bm[idx] >> (c % 8) & 1)

    # ---------- نطاقات الحرة ----------

    def free_ranges(self, referenced_extra=None):
        bm = self._load_bitmap()
        b = self.boot
        out = []
        run_start = None
        total = b.cluster_count
        used = set(referenced_extra or ())
        for c in range(2, total + 2):
            idx, bit = c // 8, c % 8
            free = (idx >= len(bm) or not (bm[idx] >> bit & 1)) and c not in used
            off = self.cluster_abs(c)
            if free and run_start is None:
                run_start = off
            elif not free and run_start is not None:
                out.append((run_start, off - run_start))
                run_start = None
        if run_start is not None:
            out.append((run_start, self.cluster_abs(total + 1) - run_start))
        return out

    # ---------- الفحص العميق ----------

    def deep_scan(self, live, lost):
        """مسح كومة العناقيد بحثاً عن مجموعات محذوفة لم تُعثر عليها الأدلة"""
        b = self.boot
        heap_off = self.cluster_abs(2)
        heap_len = b.cluster_count * self.cluster
        known = {(it['name'], it['size']) for it in lost}
        step = 32
        CH = 4 * 1024 * 1024
        pos = 0
        while pos < heap_len:
            if self.cancel and self.cancel.is_set():
                break
            if self.progress and (pos // CH) % 8 == 0:
                self.progress('deep', pos, heap_len,
                              f'فحص عميق {pos // (1024 * 1024)}MB')
            chunk = self.src.read(heap_off + pos, min(CH + 64, heap_len - pos))
            j = 0
            while j + 32 <= len(chunk):
                t = chunk[j]
                if t == (E_FILE & ~DELETED_BIT):
                    ent = self._parse_entry_set(chunk, j, deleted_ok=True)
                    if ent and (ent['name'], ent['size']) not in known:
                        known.add((ent['name'], ent['size']))
                        name = ent['name'] or 'deep_lost'
                        item = {
                            'name': name,
                            'size': 0 if ent['is_dir'] else ent['size'],
                            'deleted': True, 'is_dir': ent['is_dir'],
                            'mtime': ent['mtime'], 'path': '',
                            'checksum_ok': ent['checksum_ok'],
                            'extents': self._item_extents(ent)
                            if not ent['is_dir'] else [],
                        }
                        lost.append(item)
                        j += 32 * (1 + chunk[j + 1])
                        continue
                j += step
            pos += CH
        return lost

    # ---------- المسح الرئيسي ----------

    def scan(self, deep=False):
        live, lost = [], []
        self._visited_dirs = set()
        b = self.boot
        if self.progress:
            self.progress('exfat', 0, 1,
                          f'تحليل exFAT - {b.cluster_count} عنقود')
        root_ent = {'first_cluster': b.root_cluster, 'is_dir': True,
                    'name': ''}
        self._walk_dir(root_ent, '', live, lost)
        if deep:
            self.deep_scan(live, lost)
        info = {
            'fs': 'exFAT',
            'serial': f'{b.serial:08X}',
            'cluster_size': self.cluster,
            'label': self.volume_label,
            'clusters': b.cluster_count,
        }
        return live, lost, info
