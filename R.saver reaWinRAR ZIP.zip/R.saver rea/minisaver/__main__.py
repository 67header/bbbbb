"""MiniSaver - Entry point
python -m minisaver [options] or python __main__.py [options]
Without options: opens the GUI directly.
"""
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from minisaver.core.disk import is_admin, relaunch_as_admin, WIN

IMAGE_EXTS = ('.img', '.dd', '.raw', '.iso', '.bin', '.vhd', '.vhdx',
              '.e01', '.dmg')


def main():
    argv = list(sys.argv[1:])

    # Info commands
    if any(a in ('-h', '--help') for a in argv):
        from minisaver.app import cli_main
        return cli_main(argv)

    # Launch GUI directly if requested or if no arguments passed
    if not argv or '--gui' in argv:
        from minisaver.gui import run_gui
        return run_gui(argv)

    from minisaver.app import cli_main
    return cli_main(argv)


if __name__ == '__main__':
    sys.exit(main() or 0)
