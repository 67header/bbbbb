"""MiniSaver - محرك المسح والاسترجاع

يربط بين طبقة المصدر، جداول الأقسام، محللات أنظمة الملفات والحفر
بالتواقيع، ثم يكتب الملفات المسترجعة إلى مجلد الإخراج بنفس منطق
R.saver: مجلدات سليمة بمساراتها + مجلد $LostFiles للمحذوف/المحفور.
"""
import os
import threading
import time

from .core import (DataSource, parse_mbr, parse_gpt, detect_fs,
                   set_ebr_reader, NtfsParser, FatParser, ExFatParser, Carver)
from .core.util import safe_name, unique_path, human_size

LOST_DIR = '$LostFiles'
BAD_DIR = '$BadFiles'
CHUNK = 1024 * 1024


class Volume:
    """فوليوم مكتشف داخل المصدر (قسم أو قرص كامل)"""

    def __init__(self, source, offset, length, fs=None, part=None):
        self.src = source
        self.offset = offset          # إزاحة البداية المطلقة داخل المصدر
        self.length = length          # الطول بالبايت
        self.fs = fs                  # NTFS / FAT12 / FAT16 / FAT32 / exFAT
        self.part = part
        self.label = ''
        self.serial = ''
        self.live = []
        self.lost = []
        self.info = {}

    def describe(self):
        p = f' [{self.part.describe(512)}]' if self.part else ''
        fs = self.fs or 'غير معروف'
        lab = f' "{self.label}"' if self.label else ''
        ser = f' SN:{self.serial}' if self.serial else ''
        return f'{fs}{lab}{ser}{p} @+{self.offset} ({human_size(self.length)})'


def _detect_label(parser, fs):
    return getattr(parser, 'volume_label', '') or ''


class ScanEngine:
    """محرك موحد: مصدر واحد -> فوليومات -> ملفات (سليمة + محذوفة + محفورة)"""

    def __init__(self, source_path, progress=None, cancel=None):
        self.path = source_path
        self.progress = progress or (lambda *a: None)
        self.cancel = cancel or threading.Event()
        self.src = None
        self.volumes = []

    def open(self):
        self.src = DataSource(self.path)
        if self.src.size <= 0:
            # محاولة أخيرة إذا كان المسار جهازاً
            pass
        return self

    def close(self):
        if self.src:
            self.src.close()
            self.src = None

    # ---------- اكتشاف الفوليومات ----------

    def discover(self):
        """تحليل جداول الأقسام وكشف أنظمة الملفات"""
        self.progress('discover', 0, 1, 'قراءة جداول الأقسام')
        ss = self.src.sector_size if self.src else 512
        mbr = self.src.read_sector(0, 1) if self.src else b''
        parts = []
        try:
            set_ebr_reader(lambda lba: self.src.read_sector(lba, 1))
            parts = parse_mbr(mbr)
            if not parts and self.src:
                parts = parse_gpt(self.src, ss)
        except Exception:
            parts = []
        finally:
            set_ebr_reader(None)

        if parts and self.src:
            for p in parts:
                off = p.start_lba * ss
                length = p.num_sectors * ss
                if self.src.size and off + length > self.src.size:
                    length = max(0, self.src.size - off)
                if length < 512 * 1024:
                    continue
                vol = self._probe(off, length, p)
                if vol:
                    self.volumes.append(vol)

        # القرص كله بلا أقسام أو فشل التحليل أو وحدة منطقية مباشرة: فحص من الإزاحة 0
        if not self.volumes and self.src:
            vol = self._probe(0, self.src.size, None)
            if vol:
                self.volumes.append(vol)
            else:
                # فوليوم "غير معروف" للحفر المباشر بالتواقيع
                vol = Volume(self.src, 0, self.src.size, fs=None)
                self.volumes.append(vol)

        self.progress('discover', 1, 1, f'اكتُشف {len(self.volumes)} فوليوم')
        return self.volumes

    def _probe(self, off, length, part):
        """قراءة قطاع الإقلاع وتحديد نوع نظام الملفات"""
        try:
            boot = self.src.read(off, 512)
        except Exception:
            return None
        if not boot or len(boot) < 512:
            return None
        fs = detect_fs(boot)
        if fs is None and part is not None and part.kind == 'mbr' and part.ptype == 0x07:
            fs = 'NTFS' if boot[3:11] != b'EXFAT   ' else 'exFAT'
        if fs is None:
            return None
        return Volume(self.src, off, length, fs=fs, part=part)

    # ---------- المسح ----------

    def scan(self, volumes=None, deep=False, carve=False):
        """مسح الفوليومات المحددة أو كل الفوليومات المكتشفة"""
        if not self.volumes:
            self.discover()
        vols_to_scan = volumes if volumes is not None else self.volumes
        all_live, all_lost = [], []

        for i, vol in enumerate(vols_to_scan):
            if self.cancel.is_set():
                break
            self.progress('volume', i, len(vols_to_scan), f'فحص {vol.describe()}')
            try:
                live, lost = self.scan_volume(vol, deep=deep)
            except InterruptedError:
                break
            except Exception as e:
                self.progress('error', 0, 0, f'فشل فحص {vol.fs or "?"} @+{vol.offset}: {e}')
                live, lost = [], []

            vol.live, vol.lost = live, lost
            # تشغيل الحفر إذا طُلب أو إذا كان الفوليوم غير معروف (RAW)
            if carve or not vol.fs:
                self.carve_volume(vol)
            all_live.extend(live)
            all_lost.extend(vol.lost)

        self.progress('done', 1, 1,
                      f'انتهى المسح: {len(all_live)} سليم، {len(all_lost)} محذوف/محفور')
        return all_live, all_lost

    def scan_volume(self, vol, deep=False):
        """مسح فوليوم واحد حسب نوعه"""
        if vol.fs == 'NTFS':
            parser = NtfsParser(self.src, vol.offset,
                                progress=self.progress, cancel=self.cancel)
            live, lost, info = parser.scan()
        elif vol.fs in ('FAT12', 'FAT16', 'FAT32'):
            parser = FatParser(self.src, vol.offset,
                               progress=self.progress, cancel=self.cancel)
            live, lost, info = parser.scan()
        elif vol.fs == 'exFAT':
            parser = ExFatParser(self.src, vol.offset,
                                 progress=self.progress, cancel=self.cancel)
            live, lost, info = parser.scan(deep=deep)
        else:
            # نظام ملفات غير معروف / RAW: لا نرفع استثناء بل نتيح الحفر
            vol.info = {'fs': 'RAW'}
            vol.parser = None
            return [], []

        vol.info = info
        vol.label = info.get('label', '')
        vol.serial = info.get('serial', '')
        vol.parser = parser
        return live, lost

    def carve_volume(self, vol):
        """حفر بالتواقيع في المساحة الحرة/غير المغطاة للفوليوم"""
        covered = []
        for it in (vol.live or []) + (vol.lost or []):
            for off, ln in it.get('extents', []):
                if off and ln:
                    covered.append((off, ln))
        ranges = [(vol.offset, vol.length)]
        carver = Carver(self.src, progress=self.progress, cancel=self.cancel)
        found = carver.scan(ranges, skip_extents=covered)

        taken = {(it.get('name'), it.get('size')) for it in vol.lost}
        for item in found:
            key = (item.get('name'), item.get('size'))
            if key in taken:
                continue
            taken.add(key)
            vol.lost.append(item)
        return found

    # ---------- الاسترجاع ----------

    def recover(self, items, output_dir, progress=None):
        """كتابة قائمة عناصر إلى مجلد الإخراج
        items: قواميس بنفس بنية عناصر المسح
        يعيد (نجاح، فشل، بايتات)
        """
        progress = progress or (lambda *a: None)
        os.makedirs(output_dir, exist_ok=True)
        ok = fail = 0
        written = 0
        used = set()

        for i, it in enumerate(items):
            if self.cancel.is_set():
                break
            progress('recover', i + 1, len(items), it.get('name', '?'))
            try:
                n = self._recover_one(it, output_dir, used)
                if n is None:
                    fail += 1
                else:
                    ok += 1
                    written += n
            except Exception:
                fail += 1

        progress('recover-done', ok, ok + fail,
                 f'استُرجع {ok} ملف ({human_size(written)})، فشل {fail}')
        return ok, fail, written

    def _recover_one(self, it, output_dir, used):
        name = safe_name(it.get('name') or 'unknown')
        sub = it.get('path', '') or ''
        if it.get('deleted'):
            sub = os.path.join(LOST_DIR, sub)
        rel = os.path.join(sub, name)
        
        base = os.path.join(output_dir, rel)
        i = 2
        while base in used or os.path.exists(base):
            b, e = os.path.splitext(rel)
            base = os.path.join(output_dir, f'{b} ({i}){e}')
            i += 1
        used.add(base)
        os.makedirs(os.path.dirname(base), exist_ok=True)

        # المجلد: ننشئه كدليل حقيقي
        if it.get('is_dir'):
            if os.path.isfile(base):
                base = unique_path(base)
            os.makedirs(base, exist_ok=True)
            return 0

        size = it.get('size', 0)
        rec = it.get('record_ref')
        # NTFS مقيم (resident)
        if rec is not None and not it.get('extents'):
            data = rec.first_data()
            if data is not None and not data.non_resident:
                with open(base, 'wb') as f:
                    f.write(data.value[:size] if size else data.value)
                return len(data.value)
            return None if size else 0

        exts = it.get('extents', [])
        if not exts:
            if size == 0:
                with open(base, 'wb') as f:
                    pass
                return 0
            return None

        budget = size if size and size > 0 else sum(l for _, l in exts)
        n = 0
        src_size = self.src.size if self.src else float('inf')

        with open(base, 'wb') as f:
            for off, ln in exts:
                if self.cancel.is_set() or n >= budget:
                    break
                if not off or not ln:
                    continue
                ln = min(ln, budget - n)
                pos = off
                while ln > 0 and (src_size == 0 or pos < src_size):
                    if self.cancel.is_set():
                        break
                    chunk = self.src.read(pos, min(CHUNK, ln))
                    if not chunk:
                        break
                    f.write(chunk)
                    n += len(chunk)
                    pos += len(chunk)
                    ln -= len(chunk)
        return n


def run_full_scan(source_path, deep=False, carve=False, progress=None,
                  cancel=None):
    """تشغيل سريع: يفتح المصدر ويكتشف ويمسح ثم يغلق"""
    eng = ScanEngine(source_path, progress=progress, cancel=cancel)
    eng.open()
    try:
        eng.discover()
        live, lost = eng.scan(deep=deep, carve=carve)
        return eng, live, lost
    except Exception:
        eng.close()
        raise
