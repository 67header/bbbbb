# -*- coding: utf-8 -*-
"""MiniSaver - R.saver 6.9.5 User Interface Implementation

Step 1: Choose storage containing your data (Logical volumes & Physical disks)
Full recovery wizard:
  disksel -> partsel -> scan -> explorer -> cpdef -> copying -> done
"""
import os
import sys
import time
import queue
import threading
import datetime
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

from .core.disk import list_sources, is_admin
from .core.util import human_size
from .engine import ScanEngine
from . import lang
from . import icons

APP_TITLE = 'R.saver - version 6.9.5'

# Theme Palette matching R.saver 6.9.5
C_WIN_BG = '#FFFFFF'
C_HEADER_BG = '#FFFFFF'
C_TITLE = '#203A58'
C_SUBTITLE = '#5C7186'
C_BAR_BG = '#EDF2F7'
C_BAR_BORDER = '#D6E0EA'
C_TAB_ACTIVE = '#203A58'
C_TAB_INACTIVE = '#697B8E'
C_ACCENT_RED = '#E04A3A'
C_ORANGE = '#D9532F'
C_SIDE_TEXT = '#4A5568'
C_FOOTER_BG = '#27496D'
C_FOOTER_BTN_BG = '#325C8A'
C_FOOTER_BTN_BORDER = '#5682B2'
C_CARD_BG = '#FFFFFF'
C_CARD_BORDER = '#D8E2EC'
C_CARD_HOVER_BG = '#F6F9FD'
C_CARD_SEL_BG = '#EDF4FE'
C_CARD_SEL_BORDER = '#1A73E8'

STAGE_MAP = {
    'discover': 6, 'mft': 6, 'fat': 6, 'carve': 7, 'deep': 8,
    'orphans': 8, 'recycle': 8, 'volume': 9, 'error': 9,
}


def fmt_size(n):
    kb, mb, gb, tb = 1024, 1024**2, 1024**3, 1024**4
    if n >= tb:
        return f'{round(n / tb, 1)} TB'
    if n >= gb:
        return f'{n // gb} GB'
    if n >= mb:
        return f'{n // mb} MB'
    return f'{n} B'


class Wizard:
    """R.saver 6.9.5 Multi-step Data Recovery Wizard"""

    def __init__(self, root):
        self.root = root
        root.title(APP_TITLE)
        root.geometry('1000x670')
        root.minsize(880, 580)
        root.configure(bg=C_WIN_BG)

        self.engine = None
        self.worker = None
        self.cancel_event = threading.Event()
        self.uiq = queue.Queue()
        self.current = None

        # Data state
        self.selected_source = None
        self.volumes = []
        self.live, self.lost = [], []
        self.scan_volumes = None
        self.recover_items = []
        self.opt_lost = tk.BooleanVar(value=True)
        self.opt_recy = tk.BooleanVar(value=False)
        self.opt_carve = tk.BooleanVar(value=False)
        self.checks = {}
        self.i2item = {}
        self.target_dir = None
        self.report_html = None

        # Disksel tab: 'logical' or 'physical'
        self.current_disksel_tab = 'logical'
        self.card_widgets = []
        self._selected_card_path = None

        self._build_chrome()
        self.show('disksel')
        self._poll()

    # ---------- Chrome: Header, Stepper, Content, Footer ----------

    def _build_chrome(self):
        # 1. Header Frame
        self.head_frame = tk.Frame(self.root, bg=C_HEADER_BG, height=64)
        self.head_frame.pack(fill='x', padx=20, pady=(10, 0))

        # Title container
        title_box = tk.Frame(self.head_frame, bg=C_HEADER_BG)
        title_box.pack(side='left', fill='both', expand=True)

        self.title_var = tk.StringVar(value='Step 1. Choose storage containing your data')
        self.title_lbl = tk.Label(
            title_box, textvariable=self.title_var, bg=C_HEADER_BG, fg=C_TITLE,
            font=('Segoe UI', 15, 'bold'), anchor='w'
        )
        self.title_lbl.pack(anchor='w', pady=(4, 0))

        # Top Right Circular Buttons (Profile, Settings, Help)
        act_box = tk.Frame(self.head_frame, bg=C_HEADER_BG)
        act_box.pack(side='right', pady=(4, 0))

        self.icon_profile = icons.get_tk_image('btn_profile', (30, 30))
        self.icon_gear = icons.get_tk_image('btn_gear', (30, 30))
        self.icon_help = icons.get_tk_image('btn_help', (30, 30))

        self.btn_profile = tk.Label(act_box, image=self.icon_profile, bg=C_HEADER_BG, cursor='hand2')
        self.btn_profile.pack(side='left', padx=5)
        self.btn_profile.bind('<Button-1>', lambda e: self._on_about())

        self.btn_gear = tk.Label(act_box, image=self.icon_gear, bg=C_HEADER_BG, cursor='hand2')
        self.btn_gear.pack(side='left', padx=5)
        self.btn_gear.bind('<Button-1>', lambda e: self._settings_dialog())

        self.btn_help = tk.Label(act_box, image=self.icon_help, bg=C_HEADER_BG, cursor='hand2')
        self.btn_help.pack(side='left', padx=5)
        self.btn_help.bind('<Button-1>', lambda e: self._on_help())

        # 2. Stepper / Breadcrumbs Bar
        self.stepper_frame = tk.Frame(self.root, bg=C_BAR_BG, height=26)
        self.stepper_frame.pack(fill='x', pady=(6, 0))
        tk.Frame(self.root, bg=C_BAR_BORDER, height=1).pack(fill='x')

        self.stepper_canvas = tk.Canvas(self.stepper_frame, bg=C_BAR_BG, height=26, bd=0, highlightthickness=0)
        self.stepper_canvas.pack(fill='both', expand=True)

        # 3. Main Body Container
        self.body = tk.Frame(self.root, bg=C_WIN_BG)
        self.body.pack(fill='both', expand=True)

        # 4. Bottom Footer Bar (Slate Navy)
        self.footer = tk.Frame(self.root, bg=C_FOOTER_BG, height=52)
        self.footer.pack(fill='x', side='bottom')

        self.footer_left = tk.Frame(self.footer, bg=C_FOOTER_BG)
        self.footer_left.pack(side='left', padx=18, pady=8)

        self.icon_refresh = icons.get_tk_image('btn_refresh', (22, 22))
        self.icon_close = icons.get_tk_image('btn_close', (22, 22))

        # Refresh button
        self.f_btn_refresh = tk.Button(
            self.footer_left, image=self.icon_refresh, text=' ' + self._t_rsaver('btn_refresh', 'Refresh list'),
            compound='left', bg=C_FOOTER_BG, fg='#FFFFFF', activebackground='#355B82', activeforeground='#FFFFFF',
            bd=0, font=('Segoe UI', 9), cursor='hand2', padx=8, pady=4, command=self._on_refresh_click
        )
        self.f_btn_refresh.pack(side='left', padx=(0, 16))

        # Close Assistant button
        self.f_btn_close = tk.Button(
            self.footer_left, image=self.icon_close, text=' ' + self._t_rsaver('btn_close', 'Close Assistant'),
            compound='left', bg=C_FOOTER_BG, fg='#FFFFFF', activebackground='#355B82', activeforeground='#FFFFFF',
            bd=0, font=('Segoe UI', 9), cursor='hand2', padx=8, pady=4, command=self._on_close_click
        )
        self.f_btn_close.pack(side='left')

        # Footer Right: Continue button
        self.footer_right = tk.Frame(self.footer, bg=C_FOOTER_BG)
        self.footer_right.pack(side='right', padx=18, pady=8)

        self.btn_continue = tk.Button(
            self.footer_right, text=self._t_rsaver('btn_continue', 'Continue') + '  \u25B6',
            bg=C_FOOTER_BTN_BG, fg='#FFFFFF', activebackground='#4374A7', activeforeground='#FFFFFF',
            font=('Segoe UI', 10, 'bold'), padx=24, pady=5, bd=1, relief='raised',
            cursor='hand2', command=self._on_continue_click
        )
        self.btn_continue.pack(side='right')

    def _t_rsaver(self, key, fallback=''):
        table = lang.section('rsaver')
        if isinstance(table, dict) and key in table:
            return table[key]
        return fallback

    def _draw_stepper(self, active_step=1):
        self.stepper_canvas.delete('all')
        w = self.stepper_canvas.winfo_width()
        if w < 100:
            w = 1000
        steps = self._t_rsaver('step_crumbs', [
            '1: Storage', '2: Partition', '3: Scan', '4: Select Files', '5: Destination', '6: Recover'
        ])
        num = len(steps)
        step_w = w / num
        for i, s in enumerate(steps):
            x1 = i * step_w
            x2 = (i + 1) * step_w
            is_active = (i + 1 == active_step)
            is_past = (i + 1 < active_step)

            bg_c = '#E2EAF2' if is_active else C_BAR_BG
            fg_c = '#1A538C' if is_active else ('#334155' if is_past else '#7B8E9F')
            font = ('Segoe UI', 8, 'bold' if is_active else 'normal')

            self.stepper_canvas.create_rectangle(x1, 0, x2, 26, fill=bg_c, outline='')
            if is_active:
                self.stepper_canvas.create_rectangle(x1, 23, x2, 26, fill=C_ACCENT_RED, outline='')

            self.stepper_canvas.create_text(
                x1 + step_w / 2, 13, text=s, fill=fg_c, font=font
            )
            if i < num - 1:
                self.stepper_canvas.create_line(x2, 4, x2, 22, fill=C_BAR_BORDER)

    def _poll(self):
        try:
            while True:
                fn = self.uiq.get_nowait()
                fn()
        except queue.Empty:
            pass
        self.root.after(80, self._poll)

    def _clear_body(self):
        for w in self.body.winfo_children():
            w.destroy()

    def show(self, page):
        self._clear_body()
        self.current = page
        step_map = {
            'disksel': 1, 'partsel': 2, 'scan': 3, 'scan_direct': 3,
            'explorer': 4, 'cpdef': 5, 'copying': 6, 'done': 6
        }
        active_step = step_map.get(page, 1)
        self.root.update_idletasks()
        self._draw_stepper(active_step)

        # Update title text
        titles = {
            'disksel': self._t_rsaver('step1_title', 'Step 1. Choose storage containing your data'),
            'partsel': 'Step 2. ' + lang.T('partsel', 0),
            'scan': 'Step 3. ' + lang.T('scan', 0),
            'scan_direct': 'Step 3. ' + lang.T('scan', 0),
            'explorer': 'Step 4. ' + lang.T('explorer', 0),
            'cpdef': 'Step 5. ' + lang.T('cpdef', 0),
            'copying': 'Step 6. ' + lang.T('copying', 0),
            'done': 'Step 6. ' + lang.T('copying', 3)
        }
        self.title_var.set(titles.get(page, APP_TITLE))

        if page == 'disksel':
            self.footer.pack(fill='x', side='bottom')
            self._page_disksel()
        else:
            getattr(self, '_page_' + page)()

    # ---------- Dialogs & Header Actions ----------

    def _on_about(self):
        win = tk.Toplevel(self.root)
        win.title('About R.saver')
        win.geometry('420x290')
        win.resizable(False, False)
        win.configure(bg='#FFFFFF')
        win.transient(self.root)
        win.grab_set()

        tk.Label(win, text='R.saver', font=('Segoe UI', 18, 'bold'), fg=C_TITLE, bg='#FFFFFF').pack(pady=(20, 2))
        tk.Label(win, text='Version 6.9.5 (Professional Recovery Edition)', font=('Segoe UI', 10), fg='#64748B', bg='#FFFFFF').pack()

        box = tk.Frame(win, bg='#F8FAFC', bd=1, relief='solid', padx=14, pady=10)
        box.pack(fill='both', expand=True, padx=20, pady=15)

        info = (
            '• High-performance NTFS, FAT, and exFAT recovery\n'
            '• Signature-based deep file carving (JPEG, PNG, Office, PDF...)\n'
            '• Strict read-only low-level driver safety guarantee\n'
            '• Compatible with Windows 11/10/8/7 and Disk Images'
        )
        tk.Label(box, text=info, font=('Segoe UI', 9), justify='left', bg='#F8FAFC', fg='#334155').pack(anchor='w')

        tk.Button(win, text='OK', command=win.destroy, width=12, bg='#E2E8F0', font=('Segoe UI', 9)).pack(pady=(0, 14))

    def _on_help(self):
        msg = (
            "How to use Step 1:\n\n"
            "1. Select whether you want to scan a 'Logical volume' (e.g. C:, D:) or an entire 'Physical disk'.\n"
            "2. Click the card of the storage device where your lost files were located.\n"
            "3. Click 'Continue' or double-click the card to begin data discovery.\n\n"
            "Tip: You can also click '+ Open Disk Image' to load raw disk dumps (.img, .iso, .vhd, .dd)."
        )
        messagebox.showinfo('R.saver Help', msg, parent=self.root)

    def _settings_dialog(self):
        win = tk.Toplevel(self.root)
        win.title('Settings & Language')
        win.geometry('360x220')
        win.resizable(False, False)
        win.transient(self.root)
        win.grab_set()
        win.configure(bg='#FFFFFF')

        cur = lang.get_lang()
        var = tk.StringVar(value=cur)
        tk.Label(win, text='Select Interface Language:', font=('Segoe UI', 11, 'bold'), fg=C_TITLE, bg='#FFFFFF').pack(pady=(16, 10))

        names = {'en': 'English (United States)', 'ru': 'Русский (Russian)'}
        for code, nm in names.items():
            tk.Radiobutton(win, text=nm, value=code, variable=var, font=('Segoe UI', 10), bg='#FFFFFF', activebackground='#FFFFFF')\
                .pack(anchor='w', padx=40, pady=4)

        def apply():
            if var.get() != cur:
                lang.set_lang(var.get())
            win.destroy()
            self._update_footer_labels()
            self.show(self.current)

        btn_box = tk.Frame(win, bg='#FFFFFF')
        btn_box.pack(pady=16)
        tk.Button(btn_box, text='Apply', command=apply, width=12, bg='#2B5885', fg='#FFFFFF', font=('Segoe UI', 9, 'bold')).pack(side='left', padx=6)
        tk.Button(btn_box, text='Cancel', command=win.destroy, width=10, bg='#E2E8F0', font=('Segoe UI', 9)).pack(side='left', padx=6)

    def _update_footer_labels(self):
        self.f_btn_refresh.configure(text=' ' + self._t_rsaver('btn_refresh', 'Refresh list'))
        self.f_btn_close.configure(text=' ' + self._t_rsaver('btn_close', 'Close Assistant'))
        self.btn_continue.configure(text=self._t_rsaver('btn_continue', 'Continue') + '  \u25B6')

    # ---------- STEP 1: Storage Selection (R.saver 6.9.5 Match) ----------

    def _page_disksel(self):
        self.card_widgets.clear()
        self._selected_card_path = None
        self._update_continue_btn_state()

        # Top sub-bar with Tabs: 'Logical volumes' & 'Physical disks'
        tab_bar = tk.Frame(self.body, bg=C_WIN_BG, height=42)
        tab_bar.pack(fill='x', padx=24, pady=(12, 0))

        # Logical volumes Tab
        self.tab_logical_frame = tk.Frame(tab_bar, bg=C_WIN_BG, cursor='hand2')
        self.tab_logical_frame.pack(side='left', padx=(0, 24))
        self.lbl_tab_logical = tk.Label(
            self.tab_logical_frame, text=self._t_rsaver('tab_logical', 'Logical volumes'),
            bg=C_WIN_BG, fg=C_TAB_ACTIVE if self.current_disksel_tab == 'logical' else C_TAB_INACTIVE,
            font=('Segoe UI', 11, 'bold' if self.current_disksel_tab == 'logical' else 'normal')
        )
        self.lbl_tab_logical.pack(anchor='w')
        self.line_tab_logical = tk.Frame(
            self.tab_logical_frame, bg=C_ACCENT_RED if self.current_disksel_tab == 'logical' else C_WIN_BG,
            height=3
        )
        self.line_tab_logical.pack(fill='x', pady=(4, 0))

        # Physical disks Tab
        self.tab_physical_frame = tk.Frame(tab_bar, bg=C_WIN_BG, cursor='hand2')
        self.tab_physical_frame.pack(side='left')
        self.lbl_tab_physical = tk.Label(
            self.tab_physical_frame, text=self._t_rsaver('tab_physical', 'Physical disks'),
            bg=C_WIN_BG, fg=C_TAB_ACTIVE if self.current_disksel_tab == 'physical' else C_TAB_INACTIVE,
            font=('Segoe UI', 11, 'bold' if self.current_disksel_tab == 'physical' else 'normal')
        )
        self.lbl_tab_physical.pack(anchor='w')
        self.line_tab_physical = tk.Frame(
            self.tab_physical_frame, bg=C_ACCENT_RED if self.current_disksel_tab == 'physical' else C_WIN_BG,
            height=3
        )
        self.line_tab_physical.pack(fill='x', pady=(4, 0))

        # Tab click handlers
        self.tab_logical_frame.bind('<Button-1>', lambda e: self._switch_tab('logical'))
        self.lbl_tab_logical.bind('<Button-1>', lambda e: self._switch_tab('logical'))
        self.tab_physical_frame.bind('<Button-1>', lambda e: self._switch_tab('physical'))
        self.lbl_tab_physical.bind('<Button-1>', lambda e: self._switch_tab('physical'))

        # Content split: Left (Cards Grid) vs Right (Guidance Sidebar)
        split_frame = tk.Frame(self.body, bg=C_WIN_BG)
        split_frame.pack(fill='both', expand=True, padx=24, pady=(10, 10))

        # Right Guidance Sidebar
        sidebar = tk.Frame(split_frame, bg=C_WIN_BG, width=310)
        sidebar.pack(side='right', fill='y', padx=(20, 0))
        sidebar.pack_propagate(False)

        # Vertical divider
        tk.Frame(split_frame, bg='#E2E8F0', width=1).pack(side='right', fill='y', padx=0)

        # Build Sidebar Content
        self._build_sidebar(sidebar)

        # Left Cards Grid Area
        self.cards_container = tk.Frame(split_frame, bg=C_WIN_BG)
        self.cards_container.pack(side='left', fill='both', expand=True)

        self._render_cards()

    def _switch_tab(self, tab):
        if self.current_disksel_tab == tab:
            return
        self.current_disksel_tab = tab
        if tab == 'logical':
            self.lbl_tab_logical.configure(fg=C_TAB_ACTIVE, font=('Segoe UI', 11, 'bold'))
            self.line_tab_logical.configure(bg=C_ACCENT_RED)
            self.lbl_tab_physical.configure(fg=C_TAB_INACTIVE, font=('Segoe UI', 11, 'normal'))
            self.line_tab_physical.configure(bg=C_WIN_BG)
        else:
            self.lbl_tab_physical.configure(fg=C_TAB_ACTIVE, font=('Segoe UI', 11, 'bold'))
            self.line_tab_physical.configure(bg=C_ACCENT_RED)
            self.lbl_tab_logical.configure(fg=C_TAB_INACTIVE, font=('Segoe UI', 11, 'normal'))
            self.line_tab_logical.configure(bg=C_WIN_BG)

        self._selected_card_path = None
        self.selected_source = None
        self._update_continue_btn_state()
        self._render_cards()

    def _build_sidebar(self, parent):
        # Section 1: How to choose correctly
        tk.Label(
            parent, text=self._t_rsaver('how_to_choose_title', 'How to choose correctly'),
            bg=C_WIN_BG, fg=C_ORANGE, font=('Segoe UI', 10, 'bold'), anchor='w'
        ).pack(fill='x', pady=(0, 6))

        p1 = self._t_rsaver(
            'how_to_choose_p1',
            'Selecting an item from the device list will launch analysis of the entire storage device. A logical volume as an analysis target limits scanning to the corresponding boundaries.'
        )
        p2 = self._t_rsaver(
            'how_to_choose_p2',
            'In doubt? Choose the device. It slows down the analysis, but makes it comprehensive.'
        )
        p3 = self._t_rsaver(
            'how_to_choose_p3',
            'In the logical volumes list, refer to the name, size, and system identifier (Windows drive letter).'
        )
        p4 = self._t_rsaver(
            'how_to_choose_p4',
            'When choosing a physical disk, pay attention to the manufacturer, model, capacity, and serial number.'
        )

        for p in (p1, p2, p3, p4):
            lbl = tk.Label(parent, text=p, bg=C_WIN_BG, fg=C_SIDE_TEXT, font=('Segoe UI', 8),
                           wraplength=290, justify='left', anchor='w')
            lbl.pack(fill='x', pady=3)

        # Section 2: FAQ
        tk.Label(
            parent, text=self._t_rsaver('faq_title', 'Frequently Asked Questions:'),
            bg=C_WIN_BG, fg=C_ORANGE, font=('Segoe UI', 10, 'bold'), anchor='w'
        ).pack(fill='x', pady=(16, 6))

        faq_items = [
            (self._t_rsaver('faq_q1', '• Is data recovery safe?'), self._t_rsaver('faq_a1')),
            (self._t_rsaver('faq_q2', '• Why is my disk not listed?'), self._t_rsaver('faq_a2')),
            (self._t_rsaver('faq_q3', '• How to recover data from RAID?'), self._t_rsaver('faq_a3')),
            (self._t_rsaver('faq_q4', '• Other questions »'), self._t_rsaver('faq_a4')),
        ]

        for q_text, a_text in faq_items:
            q_lbl = tk.Label(parent, text=q_text, bg=C_WIN_BG, fg='#1A66B0', font=('Segoe UI', 8),
                             cursor='hand2', anchor='w', justify='left')
            q_lbl.pack(fill='x', pady=2)
            q_lbl.bind('<Button-1>', lambda e, title=q_text, ans=a_text: self._show_faq_modal(title, ans))
            q_lbl.bind('<Enter>', lambda e, l=q_lbl: l.configure(font=('Segoe UI', 8, 'underline')))
            q_lbl.bind('<Leave>', lambda e, l=q_lbl: l.configure(font=('Segoe UI', 8, 'normal')))

    def _show_faq_modal(self, title, text):
        clean_title = title.replace('•', '').replace('»', '').strip()
        messagebox.showinfo(clean_title, text, parent=self.root)

    def _render_cards(self):
        for w in self.cards_container.winfo_children():
            w.destroy()
        self.card_widgets.clear()

        # Canvas + Scrollbar for card grid
        canvas = tk.Canvas(self.cards_container, bg=C_WIN_BG, bd=0, highlightthickness=0)
        vs = ttk.Scrollbar(self.cards_container, orient='vertical', command=canvas.yview)
        grid_frame = tk.Frame(canvas, bg=C_WIN_BG)

        grid_frame.bind(
            '<Configure>',
            lambda e: canvas.configure(scrollregion=canvas.bbox('all'))
        )
        canvas.create_window((0, 0), window=grid_frame, anchor='nw')
        canvas.configure(yscrollcommand=vs.set)

        canvas.pack(side='left', fill='both', expand=True)
        vs.pack(side='right', fill='y')

        # Bind mouse wheel
        def _on_wheel(event):
            canvas.yview_scroll(int(-1 * (event.delta / 120)), 'units')
        canvas.bind_all('<MouseWheel>', _on_wheel)

        sources = list_sources()
        # Filter sources based on current tab
        if self.current_disksel_tab == 'logical':
            filtered = [s for s in sources if s['kind'] == 'logical']
        else:
            filtered = [s for s in sources if s['kind'] == 'physical']

        # Add image card option
        img_card_data = {
            'path': 'custom_image',
            'kind': 'image',
            'name': self._t_rsaver('btn_add_image', '+ Open Disk Image...'),
            'label': 'Raw image / ISO / VHD',
            'size': 0
        }
        all_cards = filtered + [img_card_data]

        col_count = 2
        for idx, item in enumerate(all_cards):
            r = idx // col_count
            c = idx % col_count
            self._create_card(grid_frame, item, r, c)

    def _create_card(self, parent, item, r, c):
        card = tk.Frame(
            parent, bg=C_CARD_BG, bd=1, relief='solid',
            padx=10, pady=10, cursor='hand2'
        )
        card.grid(row=r, column=c, padx=10, pady=10, sticky='nsew')
        parent.grid_columnconfigure(c, weight=1, minsize=260)

        # Determine icon
        if item.get('kind') == 'image':
            tk_img = icons.get_tk_image('disk_image', (60, 60))
        elif item.get('kind') == 'physical':
            tk_img = icons.get_tk_image('hdd_physical', (60, 60))
        elif item.get('drive_type') == 'usb':
            tk_img = icons.get_tk_image('hdd_usb', (60, 60))
        else:
            tk_img = icons.get_tk_image('hdd_win', (60, 60))

        icon_lbl = tk.Label(card, image=tk_img, bg=C_CARD_BG)
        icon_lbl.pack(side='left', padx=(0, 10))

        # Text information frame
        txt_frame = tk.Frame(card, bg=C_CARD_BG)
        txt_frame.pack(side='left', fill='both', expand=True)

        name_text = item.get('name') or item.get('path')
        label_text = f"{item.get('label', '')} ({item.get('fs', 'RAW')})" if item.get('fs') else item.get('label', '')
        size_val = item.get('size', 0)
        size_text = human_size(size_val) if size_val > 0 else ''

        name_lbl = tk.Label(txt_frame, text=name_text, font=('Segoe UI', 11, 'bold'), fg='#1E293B', bg=C_CARD_BG, anchor='w')
        name_lbl.pack(anchor='w')

        if label_text:
            desc_lbl = tk.Label(txt_frame, text=label_text, font=('Segoe UI', 9), fg='#475569', bg=C_CARD_BG, anchor='w')
            desc_lbl.pack(anchor='w', pady=(1, 0))
        else:
            desc_lbl = None

        if size_text:
            sz_lbl = tk.Label(txt_frame, text=size_text, font=('Segoe UI', 9), fg='#64748B', bg=C_CARD_BG, anchor='w')
            sz_lbl.pack(anchor='w', pady=(1, 0))
        else:
            sz_lbl = None

        all_children = [card, icon_lbl, txt_frame, name_lbl]
        if desc_lbl:
            all_children.append(desc_lbl)
        if sz_lbl:
            all_children.append(sz_lbl)

        card_info = {
            'card': card,
            'children': all_children,
            'item': item,
            'path': item['path']
        }
        self.card_widgets.append(card_info)

        def _on_click(_e=None):
            self._select_card(card_info)

        def _on_dbl_click(_e=None):
            self._select_card(card_info)
            self._on_continue_click()

        def _on_enter(_e=None):
            if self._selected_card_path != item['path']:
                card.configure(bg=C_CARD_HOVER_BG)
                for w in all_children:
                    w.configure(bg=C_CARD_HOVER_BG)

        def _on_leave(_e=None):
            if self._selected_card_path != item['path']:
                card.configure(bg=C_CARD_BG)
                for w in all_children:
                    w.configure(bg=C_CARD_BG)

        for w in all_children:
            w.bind('<Button-1>', _on_click)
            w.bind('<Double-Button-1>', _on_dbl_click)
            w.bind('<Enter>', _on_enter)
            w.bind('<Leave>', _on_leave)

    def _select_card(self, card_info):
        self._selected_card_path = card_info['path']
        self.selected_source = card_info['item']
        self._update_continue_btn_state()

        # Update card visuals
        for ci in self.card_widgets:
            if ci['path'] == self._selected_card_path:
                ci['card'].configure(bg=C_CARD_SEL_BG, bd=2)
                for w in ci['children']:
                    w.configure(bg=C_CARD_SEL_BG)
            else:
                ci['card'].configure(bg=C_CARD_BG, bd=1)
                for w in ci['children']:
                    w.configure(bg=C_CARD_BG)

    def _update_continue_btn_state(self):
        if self._selected_card_path:
            self.btn_continue.configure(
                state='normal', bg=C_FOOTER_BTN_BG, fg='#FFFFFF', cursor='hand2'
            )
        else:
            self.btn_continue.configure(
                state='disabled', bg='#1E344E', fg='#68829E', cursor='arrow'
            )

    def _on_refresh_click(self):
        self._selected_card_path = None
        self.selected_source = None
        self._update_continue_btn_state()
        self._render_cards()

    def _on_close_click(self):
        if messagebox.askyesno('R.saver', 'Are you sure you want to exit R.saver?', parent=self.root):
            self.root.destroy()

    def _on_continue_click(self):
        if not self.selected_source:
            return

        if self.selected_source['path'] == 'custom_image':
            p = filedialog.askopenfilename(
                parent=self.root,
                filetypes=[
                    ('Disk Images', '*.img *.dd *.raw *.iso *.bin *.vhd *.vhdx *.e01'),
                    ('All Files', '*.*')
                ]
            )
            if not p:
                return
            sz = 0
            try:
                sz = os.path.getsize(p)
            except OSError:
                pass
            self.selected_source = {
                'path': p, 'kind': 'image', 'size': sz, 'sector': 512,
                'name': os.path.basename(p), 'label': 'Disk Image'
            }

        # Navigate to appropriate next step
        self.footer.pack_forget()
        if self.selected_source.get('kind') == 'logical':
            self.volumes = []
            self.show('scan_direct')
        else:
            self.show('partsel')

    # ---------- STEP 2: Partition Selection ----------

    def _page_partsel(self):
        self.status_var = tk.StringVar(value='Searching partitions...')

        wrap = tk.Frame(self.body, bg=C_WIN_BG)
        wrap.pack(fill='both', expand=True, padx=20, pady=14)

        tk.Label(
            wrap, text='Select the partition to scan from this device:',
            font=('Segoe UI', 11, 'bold'), fg=C_TITLE, bg=C_WIN_BG
        ).pack(anchor='w', pady=(0, 8))

        cols = ('size', 'fs', 'state')
        self.ptree = ttk.Treeview(wrap, columns=cols, show='tree headings', selectmode='browse', height=10)
        self.ptree.heading('#0', text='Partition')
        self.ptree.heading('size', text='Size')
        self.ptree.heading('fs', text='File System')
        self.ptree.heading('state', text='Status')
        self.ptree.column('#0', width=340)
        self.ptree.column('size', width=120, anchor='e')
        self.ptree.column('fs', width=120)
        self.ptree.column('state', width=180)

        vs = ttk.Scrollbar(wrap, orient='vertical', command=self.ptree.yview)
        self.ptree.configure(yscrollcommand=vs.set)
        self.ptree.pack(side='left', fill='both', expand=True)
        vs.pack(side='left', fill='y')

        side = tk.Frame(wrap, bg=C_WIN_BG)
        side.pack(side='left', fill='y', padx=(14, 0))

        tk.Label(side, text='Analysis Settings', bg=C_WIN_BG, font=('Segoe UI', 10, 'bold'), fg=C_TITLE).pack(anchor='w', pady=(0, 6))
        for var, text in (
            (self.opt_lost, 'Scan for lost/deleted files'),
            (self.opt_recy, 'Parse Recycle Bin'),
            (self.opt_carve, 'Enable signature carving (deep)')
        ):
            tk.Checkbutton(side, text=text, variable=var, bg=C_WIN_BG, font=('Segoe UI', 9)).pack(anchor='w', pady=2)

        self.ptree.insert('', 'end', iid='loading', text='Scanning storage device...')

        nav = tk.Frame(self.body, bg='#F1F5F9', height=50)
        nav.pack(fill='x', side='bottom')

        tk.Button(nav, text='< Back', command=lambda: self.show('disksel'), width=12, font=('Segoe UI', 9)).pack(side='left', padx=14, pady=10)
        tk.Button(nav, text='Scan Entire Disk', command=self._parts_ignore, width=18, font=('Segoe UI', 9)).pack(side='left', padx=6, pady=10)
        tk.Button(nav, text='Continue >', command=self._parts_next, bg='#2B5885', fg='#FFFFFF', font=('Segoe UI', 9, 'bold'), width=14).pack(side='right', padx=14, pady=10)

        self.worker = threading.Thread(target=self._discover_worker, daemon=True)
        self.worker.start()

    def _discover_worker(self):
        try:
            eng = ScanEngine(self.selected_source['path'], cancel=self.cancel_event)
            eng.open()
            eng.discover()
            self.engine = eng
            self.uiq.put(lambda: self._fill_parts(eng.volumes))
        except Exception as e:
            self.uiq.put(lambda er=e: self._discover_error(er))

    def _discover_error(self, e):
        self.ptree.delete(*self.ptree.get_children())
        self.ptree.insert('', 'end', text=f'Error reading device: {e}')

    def _fill_parts(self, vols):
        self.volumes = vols
        self.ptree.delete(*self.ptree.get_children())
        if not vols:
            self.ptree.insert('', 'end', text='No partitions detected (click "Scan Entire Disk" for raw scan)')
            return
        for i, v in enumerate(vols):
            name = f'Partition {i+1}' + (f' ("{v.label}")' if v.label else '')
            fs_val = v.fs or 'Unknown FS'
            state = 'Formatted' if v.fs else 'Unallocated / Raw'
            self.ptree.insert('', 'end', iid=f'v{i}', text=name,
                              values=(human_size(v.length), fs_val, state))

    def _parts_next(self):
        if not self.volumes:
            self.scan_volumes = None
            self.show('scan')
            return
        sel = self.ptree.selection()
        if sel and sel[0].startswith('v'):
            keep = int(sel[0][1:])
            self.scan_volumes = [self.volumes[keep]]
        else:
            self.scan_volumes = list(self.volumes)
        self.show('scan')

    def _parts_ignore(self):
        self.scan_volumes = None
        self.show('scan')

    # ---------- STEP 3: Scanning ----------

    def _page_scan_direct(self):
        self.scan_volumes = None
        self.show('scan')

    def _page_scan(self):
        info = tk.Frame(self.body, bg=C_WIN_BG)
        info.pack(fill='both', expand=True, padx=30, pady=24)

        tk.Label(
            info, text='Analyzing File System & Scanning for Data...',
            font=('Segoe UI', 14, 'bold'), fg=C_TITLE, bg=C_WIN_BG
        ).pack(anchor='w', pady=(0, 6))

        src_name = self.selected_source.get('name') or self.selected_source.get('path')
        self.scan_src_lbl = tk.Label(
            info, text=f'Target: {src_name}',
            font=('Segoe UI', 10), fg='#475569', bg=C_WIN_BG
        )
        self.scan_src_lbl.pack(anchor='w', pady=(0, 16))

        self.pbar = ttk.Progressbar(info, orient='horizontal', mode='determinate')
        self.pbar.pack(fill='x', pady=8)

        self.scan_pct_var = tk.StringVar(value='0% completed')
        tk.Label(info, textvariable=self.scan_pct_var, font=('Segoe UI', 10, 'bold'), fg=C_TITLE, bg=C_WIN_BG).pack(anchor='w')

        self.scan_msg_var = tk.StringVar(value='Initializing scan engine...')
        tk.Label(info, textvariable=self.scan_msg_var, font=('Segoe UI', 9), fg='#64748B', bg=C_WIN_BG).pack(anchor='w', pady=(4, 0))

        nav = tk.Frame(self.body, bg='#F1F5F9', height=50)
        nav.pack(fill='x', side='bottom')

        self.btn_skip_scan = tk.Button(nav, text='Skip Deep Scan', command=self._scan_skip, width=16, font=('Segoe UI', 9))
        self.btn_skip_scan.pack(side='left', padx=14, pady=10)

        self.btn_cancel_scan = tk.Button(nav, text='Cancel', command=self._scan_back, width=12, font=('Segoe UI', 9))
        self.btn_cancel_scan.pack(side='right', padx=14, pady=10)

        self.worker = threading.Thread(target=self._scan_worker, daemon=True)
        self.worker.start()

    def _scan_worker(self):
        def progress(stage, done, total, msg):
            self.uiq.put(lambda: self._on_scan_progress(stage, done, total, msg))

        try:
            if not self.engine:
                self.engine = ScanEngine(self.selected_source['path'], progress=progress, cancel=self.cancel_event)
                self.engine.open()
            else:
                self.engine.progress = progress
                self.engine.cancel = self.cancel_event

            if not self.engine.volumes:
                self.engine.discover()

            vols = self.scan_volumes or self.engine.volumes
            deep = self.opt_carve.get() or self.opt_lost.get()
            carve = self.opt_carve.get()
            live, lost = self.engine.scan(volumes=vols, deep=deep, carve=carve)
            self.uiq.put(lambda: self._scan_done(live, lost, None))
        except Exception as e:
            self.uiq.put(lambda: self._scan_done([], [], e))

    def _on_scan_progress(self, stage, done, total, msg):
        pct = (100 * done // max(1, total)) if total else 0
        self.pbar['value'] = pct
        self.scan_pct_var.set(f'{pct}% completed')
        self.scan_msg_var.set(f'[{stage.upper()}] {msg}')

    def _scan_skip(self):
        self.cancel_event.set()

    def _scan_back(self):
        self.cancel_event.set()
        self.show('disksel')

    def _scan_done(self, live, lost, error):
        self.live = live
        self.lost = lost
        if error:
            messagebox.showerror('Scan Error', f'Scan encountered an issue:\n{error}', parent=self.root)
        self.show('explorer')

    # ---------- STEP 4: File Explorer ----------

    def _page_explorer(self):
        self.checks.clear()
        self.i2item.clear()

        top_info = tk.Frame(self.body, bg=C_WIN_BG)
        top_info.pack(fill='x', padx=20, pady=(10, 6))

        total_files = len(self.live) + len(self.lost)
        tk.Label(
            top_info, text=f'Discovered Files ({total_files} total: {len(self.live)} existing, {len(self.lost)} lost/deleted)',
            font=('Segoe UI', 12, 'bold'), fg=C_TITLE, bg=C_WIN_BG
        ).pack(side='left')

        # Filter / Search
        filter_box = tk.Frame(top_info, bg=C_WIN_BG)
        filter_box.pack(side='right')
        tk.Label(filter_box, text='Filter: ', bg=C_WIN_BG, font=('Segoe UI', 9)).pack(side='left')
        self.filter_var = tk.StringVar(value='')
        fe = tk.Entry(filter_box, textvariable=self.filter_var, width=20, font=('Segoe UI', 9))
        fe.pack(side='left', padx=(0, 6))
        self.filter_var.trace_add('write', lambda *a: self._filter_tree())

        # Main splitter (Treeview left, Preview right)
        paned = tk.PanedWindow(self.body, orient='horizontal', bg='#CBD5E1', sashwidth=4)
        paned.pack(fill='both', expand=True, padx=20, pady=(0, 10))

        # Left: Files tree
        left_f = tk.Frame(paned, bg=C_WIN_BG)
        paned.add(left_f, minsize=400)

        cols = ('size', 'type', 'status')
        self.tree = ttk.Treeview(left_f, columns=cols, show='tree headings', selectmode='extended')
        self.tree.heading('#0', text='Name')
        self.tree.heading('size', text='Size')
        self.tree.heading('type', text='Type')
        self.tree.heading('status', text='Status')
        self.tree.column('#0', width=260)
        self.tree.column('size', width=90, anchor='e')
        self.tree.column('type', width=90)
        self.tree.column('status', width=90)

        vs = ttk.Scrollbar(left_f, orient='vertical', command=self.tree.yview)
        self.tree.configure(yscrollcommand=vs.set)
        self.tree.pack(side='left', fill='both', expand=True)
        vs.pack(side='left', fill='y')

        self.tree.bind('<Button-1>', self._tree_click)
        self.tree.bind('<<TreeviewSelect>>', self._tree_preview)

        # Right: Preview Frame
        right_f = tk.Frame(paned, bg='#F8FAFC', bd=1, relief='solid')
        paned.add(right_f, minsize=260)

        tk.Label(right_f, text='File Preview', font=('Segoe UI', 10, 'bold'), fg=C_TITLE, bg='#F8FAFC').pack(anchor='w', padx=10, pady=8)
        self.preview_lbl = tk.Label(right_f, text='Select a file to preview its content or metadata.', bg='#F8FAFC', fg='#64748B', font=('Segoe UI', 9), wraplength=240, justify='left')
        self.preview_lbl.pack(fill='both', expand=True, padx=10, pady=6)

        # Bottom Bar
        nav = tk.Frame(self.body, bg='#F1F5F9', height=50)
        nav.pack(fill='x', side='bottom')

        tk.Button(nav, text='Select All', command=lambda: self._check_all(True), font=('Segoe UI', 9)).pack(side='left', padx=14, pady=10)
        tk.Button(nav, text='Deselect All', command=lambda: self._check_all(False), font=('Segoe UI', 9)).pack(side='left', padx=4, pady=10)

        self.sel_count_lbl = tk.Label(nav, text='0 files selected', bg='#F1F5F9', font=('Segoe UI', 9, 'bold'), fg=C_TITLE)
        self.sel_count_lbl.pack(side='left', padx=16)

        tk.Button(nav, text='Recover Selected >', command=self._to_cpdef, bg='#2B5885', fg='#FFFFFF', font=('Segoe UI', 9, 'bold'), padx=16).pack(side='right', padx=14, pady=10)
        tk.Button(nav, text='< Back', command=lambda: self.show('disksel'), font=('Segoe UI', 9)).pack(side='right', padx=6, pady=10)

        self._fill_tree()

    def _fill_tree(self):
        self.tree.delete(*self.tree.get_children())
        # Lost / Deleted Files Folder
        lost_root = self.tree.insert('', 'end', iid='grp_lost', text='[x] $LostFiles (Deleted / Carved)', open=True)
        self.checks['grp_lost'] = True
        for i, it in enumerate(self.lost):
            iid = f'lost_{i}'
            self.i2item[iid] = it
            self.checks[iid] = True
            sz_str = human_size(it.size)
            typ = getattr(it, 'ext', 'file')
            self.tree.insert(lost_root, 'end', iid=iid, text=f'[x] {it.name}', values=(sz_str, typ, 'Deleted'))

        # Live / Existing Files Folder
        live_root = self.tree.insert('', 'end', iid='grp_live', text='[ ] Existing File System', open=False)
        self.checks['grp_live'] = False
        for i, it in enumerate(self.live):
            iid = f'live_{i}'
            self.i2item[iid] = it
            self.checks[iid] = False
            sz_str = human_size(it.size)
            typ = getattr(it, 'ext', 'file')
            self.tree.insert(live_root, 'end', iid=iid, text=f'[ ] {it.name}', values=(sz_str, typ, 'Live'))

        self._update_selection_count()

    def _filter_tree(self):
        q = self.filter_var.get().strip().lower()
        if not q:
            self._fill_tree()
            return
        self.tree.delete(*self.tree.get_children())
        filtered_root = self.tree.insert('', 'end', iid='grp_flt', text=f'Matching "{q}"', open=True)
        for i, it in enumerate(self.lost + self.live):
            if q in it.name.lower():
                iid = f'flt_{i}'
                self.i2item[iid] = it
                self.checks[iid] = True
                self.tree.insert(filtered_root, 'end', iid=iid, text=f'[x] {it.name}', values=(human_size(it.size), '', 'Found'))

    def _tree_click(self, event):
        region = self.tree.identify('region', event.x, event.y)
        iid = self.tree.identify_row(event.y)
        if not iid:
            return
        # Toggle checkbox on click
        cur = self.checks.get(iid, False)
        new_val = not cur
        self.checks[iid] = new_val

        # Update text prefix [x] or [ ]
        txt = self.tree.item(iid, 'text')
        if txt.startswith('[x] '):
            self.tree.item(iid, text='[ ] ' + txt[4:])
        elif txt.startswith('[ ] '):
            self.tree.item(iid, text='[x] ' + txt[4:])

        # If clicking group, toggle all children
        for child in self.tree.get_children(iid):
            self.checks[child] = new_val
            c_txt = self.tree.item(child, 'text')
            prefix = '[x] ' if new_val else '[ ] '
            if c_txt.startswith(('[x] ', '[ ] ')):
                self.tree.item(child, text=prefix + c_txt[4:])

        self._update_selection_count()

    def _check_all(self, val):
        for iid in list(self.checks.keys()):
            self.checks[iid] = val
            txt = self.tree.item(iid, 'text')
            prefix = '[x] ' if val else '[ ] '
            if txt.startswith(('[x] ', '[ ] ')):
                self.tree.item(iid, text=prefix + txt[4:])
        self._update_selection_count()

    def _update_selection_count(self):
        sel_items = [self.i2item[k] for k, v in self.checks.items() if v and k in self.i2item]
        total_sz = sum(it.size for it in sel_items)
        self.sel_count_lbl.configure(text=f'{len(sel_items)} files selected ({human_size(total_sz)})')

    def _tree_preview(self, _e=None):
        sel = self.tree.selection()
        if not sel or sel[0] not in self.i2item:
            return
        it = self.i2item[sel[0]]
        info = f"Name: {it.name}\nSize: {human_size(it.size)} ({it.size} bytes)\nStatus: {'Deleted / Carved' if it in self.lost else 'Existing'}\n\nPath: {getattr(it, 'path', '')}"
        self.preview_lbl.configure(text=info)

    def _to_cpdef(self):
        sel_items = [self.i2item[k] for k, v in self.checks.items() if v and k in self.i2item]
        if not sel_items:
            messagebox.showwarning('No Files Selected', 'Please check at least one file to recover.', parent=self.root)
            return
        self.recover_items = sel_items
        self.show('cpdef')

    # ---------- STEP 5: Destination Selection ----------

    def _page_cpdef(self):
        frame = tk.Frame(self.body, bg=C_WIN_BG)
        frame.pack(fill='both', expand=True, padx=30, pady=24)

        tk.Label(
            frame, text='Choose Destination Folder for Recovered Files',
            font=('Segoe UI', 13, 'bold'), fg=C_TITLE, bg=C_WIN_BG
        ).pack(anchor='w', pady=(0, 6))

        tk.Label(
            frame, text='Important: To prevent data overwriting, select a drive DIFFERENT from the source disk.',
            font=('Segoe UI', 9, 'italic'), fg=C_ORANGE, bg=C_WIN_BG
        ).pack(anchor='w', pady=(0, 16))

        dir_box = tk.Frame(frame, bg=C_WIN_BG)
        dir_box.pack(fill='x', pady=10)

        default_out = os.path.abspath('./MiniSaver_Output')
        self.dest_var = tk.StringVar(value=default_out)

        tk.Entry(dir_box, textvariable=self.dest_var, font=('Segoe UI', 10), width=50).pack(side='left', fill='x', expand=True, padx=(0, 10))
        tk.Button(dir_box, text='Browse...', command=self._browse_dest, font=('Segoe UI', 9)).pack(side='left')

        summary_box = tk.LabelFrame(frame, text='Recovery Summary', font=('Segoe UI', 10, 'bold'), bg=C_WIN_BG, padx=14, pady=10)
        summary_box.pack(fill='x', pady=20)

        total_sz = sum(it.size for it in self.recover_items)
        tk.Label(summary_box, text=f'Files to recover: {len(self.recover_items)}', bg=C_WIN_BG, font=('Segoe UI', 9)).pack(anchor='w')
        tk.Label(summary_box, text=f'Total data size: {human_size(total_sz)}', bg=C_WIN_BG, font=('Segoe UI', 9)).pack(anchor='w')

        nav = tk.Frame(self.body, bg='#F1F5F9', height=50)
        nav.pack(fill='x', side='bottom')

        tk.Button(nav, text='< Back', command=lambda: self.show('explorer'), font=('Segoe UI', 9)).pack(side='left', padx=14, pady=10)
        tk.Button(nav, text='Start Recovery', command=self._start_recovery, bg='#2B5885', fg='#FFFFFF', font=('Segoe UI', 10, 'bold'), padx=20).pack(side='right', padx=14, pady=10)

    def _browse_dest(self):
        d = filedialog.askdirectory(parent=self.root, title='Select Recovery Folder')
        if d:
            self.dest_var.set(d)

    def _start_recovery(self):
        self.target_dir = self.dest_var.get().strip()
        if not self.target_dir:
            return
        os.makedirs(self.target_dir, exist_ok=True)
        self.show('copying')

    # ---------- STEP 6: Copying Files & Completion ----------

    def _page_copying(self):
        frame = tk.Frame(self.body, bg=C_WIN_BG)
        frame.pack(fill='both', expand=True, padx=30, pady=30)

        tk.Label(
            frame, text='Extracting and Saving Recovered Files...',
            font=('Segoe UI', 13, 'bold'), fg=C_TITLE, bg=C_WIN_BG
        ).pack(anchor='w', pady=(0, 10))

        self.copy_pbar = ttk.Progressbar(frame, orient='horizontal', mode='determinate')
        self.copy_pbar.pack(fill='x', pady=10)

        self.copy_status_var = tk.StringVar(value='Starting extraction...')
        tk.Label(frame, textvariable=self.copy_status_var, font=('Segoe UI', 10), fg=C_TITLE, bg=C_WIN_BG).pack(anchor='w')

        self.worker = threading.Thread(target=self._copy_worker, daemon=True)
        self.worker.start()

    def _copy_worker(self):
        def progress(stage, done, total, msg):
            self.uiq.put(lambda: self._on_copy_progress(stage, done, total, msg))

        try:
            ok, fail, written = self.engine.recover(self.recover_items, self.target_dir, progress=progress)
            self.uiq.put(lambda: self._copy_done(ok, fail, written, None))
        except Exception as e:
            self.uiq.put(lambda: self._copy_done(0, len(self.recover_items), 0, e))

    def _on_copy_progress(self, stage, done, total, msg):
        pct = (100 * done // max(1, total)) if total else 0
        self.copy_pbar['value'] = pct
        self.copy_status_var.set(f'{pct}% - {msg}')

    def _copy_done(self, ok, fail, written, error):
        self._copy_results = {'ok': ok, 'fail': fail, 'written': written, 'error': error}
        self.show('done')

    def _page_done(self):
        res = getattr(self, '_copy_results', {'ok': 0, 'fail': 0, 'written': 0, 'error': None})
        frame = tk.Frame(self.body, bg=C_WIN_BG)
        frame.pack(fill='both', expand=True, padx=30, pady=30)

        tk.Label(
            frame, text='Data Recovery Completed!',
            font=('Segoe UI', 15, 'bold'), fg='#15803D', bg=C_WIN_BG
        ).pack(anchor='w', pady=(0, 12))

        msg = (
            f"Successfully recovered: {res['ok']} files\n"
            f"Failed: {res['fail']} files\n"
            f"Total bytes written: {human_size(res['written'])}\n\n"
            f"Destination directory:\n{self.target_dir}"
        )
        tk.Label(frame, text=msg, font=('Segoe UI', 10), justify='left', bg=C_WIN_BG, fg='#334155').pack(anchor='w', pady=(0, 20))

        btn_box = tk.Frame(frame, bg=C_WIN_BG)
        btn_box.pack(anchor='w', pady=10)

        tk.Button(
            btn_box, text='Open Destination Folder', command=lambda: os.startfile(self.target_dir),
            bg='#2B5885', fg='#FFFFFF', font=('Segoe UI', 10, 'bold'), padx=16, pady=6
        ).pack(side='left', padx=(0, 12))

        tk.Button(
            btn_box, text='Return to Start', command=lambda: self.show('disksel'),
            font=('Segoe UI', 10), padx=14, pady=6
        ).pack(side='left', padx=(0, 12))

        tk.Button(
            btn_box, text='Close', command=self.root.destroy,
            font=('Segoe UI', 10), padx=14, pady=6
        ).pack(side='left')


def run_gui(argv=None):
    root = tk.Tk()
    w = Wizard(root)
    root.mainloop()
    return 0


if __name__ == '__main__':
    run_gui()
