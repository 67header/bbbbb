r"""MiniSaver - طبقة الوصول للأقراص والصور

توحيد القراءة بين:
- ملف صورة قرص (.img/.dd/.raw/...)
- قرص فيزيائي   \\.\PhysicalDriveN   (يتطلب صلاحيات مدير على ويندوز)
- وحدة منطقية   \\.\C:
على ويندوز يجب أن تكون القراءات من الأقراص الخام محاذاة على حدود القطاع.
"""
import os
import sys
import struct
import subprocess
import json

WIN = sys.platform == 'win32'

if WIN:
    import ctypes
    from ctypes import wintypes
    _k32 = ctypes.WinDLL('kernel32', use_last_error=True)
    _k32.CreateFileW.restype = ctypes.c_void_p
    _k32.CreateFileW.argtypes = [ctypes.c_wchar_p, ctypes.c_ulong, ctypes.c_ulong,
                                 ctypes.c_void_p, ctypes.c_ulong, ctypes.c_ulong,
                                 ctypes.c_void_p]
    _k32.DeviceIoControl.restype = ctypes.c_int
    _k32.DeviceIoControl.argtypes = [ctypes.c_void_p, ctypes.c_ulong, ctypes.c_void_p,
                                     ctypes.c_ulong, ctypes.c_void_p, ctypes.c_ulong,
                                     ctypes.POINTER(ctypes.c_ulong), ctypes.c_void_p]
    _k32.CloseHandle.restype = ctypes.c_int
    _k32.CloseHandle.argtypes = [ctypes.c_void_p]

    GENERIC_READ = 0x80000000
    FILE_SHARE_READ = 0x1
    FILE_SHARE_WRITE = 0x2
    OPEN_EXISTING = 3
    INVALID_HANDLE_VALUES = (None, 0, -1, 0xFFFFFFFFFFFFFFFF, 0xFFFFFFFF)
    IOCTL_DISK_GET_LENGTH_INFO = 0x0007405C
    IOCTL_DISK_GET_DRIVE_GEOMETRY = 0x00070000


def is_admin() -> bool:
    if not WIN:
        return hasattr(os, 'geteuid') and os.geteuid() == 0
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def relaunch_as_admin(extra_args=None) -> bool:
    """إعادة تشغيل البرنامج بصلاحيات المدير (مكافئ ShellExecuteW 'runas')"""
    if not WIN:
        return False
    args = list(sys.argv[1:]) + list(extra_args or [])
    params = ' '.join(f'"{a}"' for a in args)
    ret = ctypes.windll.shell32.ShellExecuteW(None, 'runas', sys.executable, params, None, 1)
    return int(ret) > 32


def _win_open(path, access=GENERIC_READ):
    share = FILE_SHARE_READ | FILE_SHARE_WRITE
    h = _k32.CreateFileW(path, access, share, None, OPEN_EXISTING, 0, None)
    if h in INVALID_HANDLE_VALUES:
        return None
    return h


def _win_dev_size(handle):
    """حجم الجهاز بوحدات البايت عبر IOCTL_DISK_GET_LENGTH_INFO"""
    buf = ctypes.create_string_buffer(16)
    ret = ctypes.c_ulong(0)
    ok = _k32.DeviceIoControl(handle, IOCTL_DISK_GET_LENGTH_INFO,
                              None, 0, buf, 16, ctypes.byref(ret), None)
    if ok:
        return abs(struct.unpack('<q', buf.raw[:8])[0])
    return None


def _win_dev_sector(handle):
    """حجم القطاع عبر IOCTL_DISK_GET_DRIVE_GEOMETRY"""
    buf = ctypes.create_string_buffer(32)
    ret = ctypes.c_ulong(0)
    ok = _k32.DeviceIoControl(handle, IOCTL_DISK_GET_DRIVE_GEOMETRY,
                              None, 0, buf, 32, ctypes.byref(ret), None)
    if ok:
        bps = struct.unpack_from('<I', buf.raw, 24)[0]
        if bps in (512, 1024, 2048, 4096):
            return bps
    return None


class DataSource:
    """مصدر قراءة موحد لصورة أو قرص خام"""

    def __init__(self, path, sector_size=None, physical=None):
        self.path = path
        low = path.lower() if isinstance(path, str) else ''
        self.physical = physical if physical is not None else \
            low.startswith(('\\\\.\\', '/dev/'))
        self.sector_size = sector_size or 512
        self._fd = None
        self._size = None
        self._open()

    def _open(self):
        flags = os.O_RDONLY | getattr(os, 'O_BINARY', 0)
        try:
            self._fd = os.open(self.path, flags)
        except OSError:
            self._fd = None

        if WIN and self.physical:
            h = _win_open(self.path)
            if h:
                self._size = _win_dev_size(h)
                ss = _win_dev_sector(h)
                if ss:
                    self.sector_size = ss
                _k32.CloseHandle(h)
            if self._size is None and self._fd is not None:
                try:
                    self._size = os.lseek(self._fd, 0, os.SEEK_END)
                    os.lseek(self._fd, 0, os.SEEK_SET)
                except OSError:
                    self._size = None
        elif self._fd is not None:
            self._size = os.fstat(self._fd).st_size

    @property
    def size(self):
        return self._size or 0

    def read(self, offset, size):
        if size <= 0 or self._fd is None:
            return b''
        if WIN and self.physical:
            ss = self.sector_size
            start = (offset // ss) * ss
            end = ((offset + size + ss - 1) // ss) * ss
            os.lseek(self._fd, start, os.SEEK_SET)
            buf = bytearray()
            need = end - start
            while len(buf) < need:
                chunk = os.read(self._fd, need - len(buf))
                if not chunk:
                    break
                buf.extend(chunk)
            buf = bytes(buf)
            return buf[offset - start: offset - start + size]
        os.lseek(self._fd, offset, os.SEEK_SET)
        out = bytearray()
        while len(out) < size:
            chunk = os.read(self._fd, size - len(out))
            if not chunk:
                break
            out.extend(chunk)
        return bytes(out)

    def read_sector(self, index, count=1):
        return self.read(index * self.sector_size, count * self.sector_size)

    def close(self):
        if self._fd is not None:
            try:
                os.close(self._fd)
            except OSError:
                pass
            self._fd = None

    def __del__(self):
        try:
            self.close()
        except Exception:
            pass


def _get_wmi_disks():
    """استعلام محركات الأقراص عبر PowerShell/CIM للحصول على الموديل والأبعاد بدقة"""
    disks = []
    if not WIN:
        return disks
    try:
        cmd = [
            'powershell', '-NoProfile', '-NonInteractive', '-Command',
            'Get-CimInstance Win32_DiskDrive | Select-Object DeviceID, Model, Size, Partitions | ConvertTo-Json -Compress'
        ]
        res = subprocess.run(cmd, capture_output=True, text=True, timeout=5)
        if res.returncode == 0 and res.stdout.strip():
            data = json.loads(res.stdout)
            if isinstance(data, dict):
                data = [data]
            for item in data:
                dev_id = str(item.get('DeviceID') or '').strip()
                model = str(item.get('Model') or 'Fixed Disk').strip()
                sz = int(item.get('Size') or 0)
                if dev_id:
                    disks.append({
                        'path': dev_id,
                        'model': model,
                        'size': sz
                    })
    except Exception:
        pass
    return disks


def list_sources():
    """قائمة مصادر الإدخال المتاحة: أقراص فيزيائية + وحدات منطقية"""
    items = []
    if WIN:
        # 1. الأقراص المنطقية الحقيقية عبر GetLogicalDrives
        bitmask = _k32.GetLogicalDrives()
        for i in range(26):
            if not (bitmask & (1 << i)):
                continue
            letter = chr(ord('A') + i)
            root = f'{letter}:\\'
            dtype = _k32.GetDriveTypeW(root)
            if dtype in (0, 1):
                continue
            
            vol_buf = ctypes.create_unicode_buffer(261)
            fs_buf = ctypes.create_unicode_buffer(261)
            _k32.GetVolumeInformationW(root, vol_buf, 261, None, None, None, fs_buf, 261)
            
            free_bytes = ctypes.c_ulonglong(0)
            total_bytes = ctypes.c_ulonglong(0)
            total_free = ctypes.c_ulonglong(0)
            _k32.GetDiskFreeSpaceExW(root, ctypes.byref(free_bytes), ctypes.byref(total_bytes), ctypes.byref(total_free))
            
            label_val = vol_buf.value.strip()
            if not label_val:
                label_val = 'OS' if letter == 'C' else 'DATA'
            fs_val = fs_buf.value.strip() or 'NTFS'
            
            drive_type = 'usb' if dtype == 2 else ('cdrom' if dtype == 5 else 'fixed')
            
            items.append({
                'path': f'\\\\.\\{letter}:',
                'kind': 'logical',
                'size': total_bytes.value,
                'free': free_bytes.value,
                'sector': 512,
                'letter': letter,
                'label': label_val,
                'fs': fs_val,
                'drive_type': drive_type,
                'name': f'Disk {letter}:'
            })

        # 2. الأقراص الفيزيائية (Physical Drives)
        wmi_disks = _get_wmi_disks()
        seen_paths = set()
        for d in wmi_disks:
            p = d['path']
            seen_paths.add(p.lower())
            idx_str = p.lower().rsplit('physicaldrive', 1)[-1] if 'physicaldrive' in p.lower() else '0'
            items.append({
                'path': p,
                'kind': 'physical',
                'size': d['size'],
                'sector': 512,
                'model': d['model'],
                'label': d['model'],
                'name': f'Disk {idx_str}'
            })

        # فحص إضافي عبر CreateFileW للأقراص الفيزيائية إن لم تجلب عبر WMI
        if not items or not any(x['kind'] == 'physical' for x in items):
            for i in range(8):
                p = f'\\\\.\\PhysicalDrive{i}'
                if p.lower() in seen_paths:
                    continue
                h = _win_open(p, 0)
                if not h:
                    continue
                size = _win_dev_size(h)
                ss = _win_dev_sector(h) or 512
                _k32.CloseHandle(h)
                if size:
                    items.append({
                        'path': p,
                        'kind': 'physical',
                        'size': size,
                        'sector': ss,
                        'model': f'Drive {i}',
                        'label': f'PhysicalDrive{i}',
                        'name': f'Disk {i}'
                    })
    else:
        for dev in sorted(os.listdir('/dev')) if os.path.isdir('/dev') else []:
            if dev.startswith(('sd', 'nvme', 'hd', 'vd', 'mmcblk')) and \
                    not dev[-1].isdigit() and 'nvme' not in dev:
                p = f'/dev/{dev}'
                try:
                    size = os.path.getsize(p)
                    items.append({
                        'path': p, 'kind': 'physical', 'size': size,
                        'sector': 512, 'label': p, 'model': dev, 'name': dev
                    })
                except OSError:
                    pass
    return items
