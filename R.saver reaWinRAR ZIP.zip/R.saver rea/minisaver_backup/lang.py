import os
# -*- coding: utf-8 -*-
"""MiniSaver / R.saver - حزم النصوص المستخرجة من r.saver64.exe

الروسية: مستخرجة حرفياً من الحزمة RUS_5_19381 (أقسام rxw:: - معالج الاسترجاع).
الإنجليزية: ترجمة مطابقة لنفس القوالب.
الاستخدام:
    from .lang import T
    T('disksel', 3)            -> 'Логические тома'
    T('disksel', 9, 'D')       -> 'Диск D:'
    set_lang('en')
"""
LANG = os.environ.get('MINISAVER_LANG', 'en')

STRINGS = {
 "ru": {
  "rsaver": {
   "step1_title": "Шаг 1. Выберите хранилище с искомыми данными",
   "tab_logical": "Логические тома",
   "tab_physical": "Физические диски",
   "how_to_choose_title": "Как выбрать правильно",
   "how_to_choose_p1": "Выбрав элемент из списка устройств, вы запустите анализ содержимого всего накопителя. Логический том в качестве объекта для анализа ограничит сканирование соответствующими границами.",
   "how_to_choose_p2": "Сомневаетесь — выберите устройство. Это замедлит процесс анализа, но сделает его максимально полным.",
   "how_to_choose_p3": "В списке логических томов ориентируйтесь на имя, размер и системный идентификатор (буква диска Windows).",
   "how_to_choose_p4": "Выбирая физический диск, обратите внимание на производителя, модель, объём и серийный номер.",
   "faq_title": "Частые вопросы:",
   "faq_q1": "• Безопасно ли восстановление данных?",
   "faq_q2": "• Почему диска нет в списке?",
   "faq_q3": "• Как восстановить данные с RAID?",
   "faq_q4": "• Другие вопросы »",
   "faq_a1": "Восстановление данных в R.saver полностью безопасно. Программа работает исключительно в режиме чтения и никогда не производит запись на исходный накопитель.",
   "faq_a2": "Если нужный диск отсутствует в списке:\n1. Проверьте подключение диска и его питание;\n2. Убедитесь, что диск виден в «Управлении дисками»;\n3. Перезапустите программу с правами Администратора.",
   "faq_a3": "Для восстановления данных с RAID выберите физические диски, входящие в массив, или загрузите образ виртуального диска.",
   "faq_a4": "Для получения дополнительной информации и инструкций обратитесь к встроенной справке или посетите сайт поддержки.",
   "btn_refresh": "Обновить список",
   "btn_close": "Закрыть Помощник",
   "btn_continue": "Продолжить",
   "btn_add_image": "+ Открыть образ диска...",
   "version_title": "R.saver - версия 6.9.5",
   "step_crumbs": [
      "1: Хранилище",
      "2: Раздел",
      "3: Анализ",
      "4: Выбор файлов",
      "5: Место сохранения",
      "6: Восстановление"
   ]
},
  "copying": [
   "Восстанавливаются выбранные файлы",
   "-",
   "Назад к выбору файлов",
   "Завершить",
   "Что делать на этой странице",
   "Вы уверены, что хотите закрыть Помощник?\nПроверьте, были ли скопированы все искомые данные. После закрытия окна результат реконструкции будет потерян.",
   "Вы действительно хотите прервать копирование файлов и вернуться к окну выбора файлов?",
   "Файлы извлекаются из «%s» и сохраняются в «%s»...",
   "Данные для восстановления не выбраны",
   "Сохранить журнал",
   "Документы HTML",
   "Сохранить файл диалога как...",
   "Вы уверены, что хотите перезаписать этот файл?",
   "Объекты с этим именем уже существуют.",
   "Невозможно создать файл назначения!",
   "Невозможно записать файл назначения!",
   "Отчет восстановления данных",
   "Создан с помощью:",
   "Дата:",
   "Перейти к восстановленным данным",
   "Остановить",
   "Вы действительно хотите прервать копирование файлов?"
  ],
  "cpdef": [
   "Выберите место сохранения восстанавливаемых данных",
   "-",
   "Вернуться к выбору файлов",
   "Начать восстановление",
   "Лицензия программы",
   "Что делать на этой странице",
   "Формируется список подходящих хранилищ...",
   "Для восстановления выбрано:",
   "количество файлов: %lld",
   "общий размер: %s",
   "%d Kб",
   "%d Mб",
   "%.01f Гб",
   "Данные не могут быть скопированы по причине отсутствия этих лицензий:",
   "Некоторые данные не могут быть скопированы по причине отсутствия лицензий:",
   "Общая лицензия программы",
   "Поддержка восстановления RAID-массива",
   "Поддержка базовых файловых систем ОС Linux  ",
   "Поддержка файловых систем ОС Mac",
   "Поддержка файловой системы ReFS ",
   "Поддержка файловой системы XFS ",
   "(необходима для копирования всех файлов)",
   "(необходима для копирования %lld файлов с общим размером %s)",
   "При этом, возможно скопировать %lld файлов (%s).",
   "Заказать эту лицензию",
   "Заказать эти лицензии",
   "Восстановленные данные будут сохранены в папку:",
   " ",
   "размещённую в корне тома, выбранного из списка:",
   "Обновить список",
   "Другие места",
   "Восстановлено",
   "Папка назначения будет использована или создана под “%s”",
   "Обновить список",
   "Выбрать другое место для сохранения",
   "Выберите место назначения",
   "Вы ДЕЙСТВИТЕЛЬНО уверены, что хотите выбрать это место?\nМесто назначения, похоже, совпадает с исходным местом.\nЕсли Вы восстанавливаете УДАЛЁННЫЕ данные, сохранение файлов в то же самое место приведет к \nПЕРМАНЕНТНОЙ ПОТЕРЕ ДАННЫХ ДО ВОССТАНОВЛЕНИЯ.",
   "Вы действительно хотите использовать это место?\nЭто место не подходит для сохранения Ваших данных по причине:\n%s.",
   "Это место не может быть использовано для сохранения выбранных данных.\nПричиной является недостаточное место для хранения выбранных файлов или режим хранилища \"только чтение\".",
   "Невозможно создать целевую папку!\nПроверьте права на запись для места назначения и повторите попытку.\nВы также можете использовать другое место или другое имя папки.",
   "Невозможно создать целевую папку!\nСуществует другой объект с таким же именем, что и целевая папка.\nНеобходимо выбрать другое место или другое имя папки.",
   "Вы уверены, что хотите закрыть Помощник?\nПроверьте, были ли скопированы все искомые данные. После закрытия окна результат реконструкции будет потерян.",
   "Закрыть Помощник",
   "-",
   "Общая лицензия программы"
  ],
  "disksel": [
   "Выберите хранилище с искомыми данными",
   "-",
   "Подождите несколько секунд, пока мы определяем устройства...",
   "Логические тома",
   "Физические диски",
   "Комплексные хранилища (RAID)",
   "Виртуальные и основанные на файлах хранилища",
   "Продолжить",
   "Диск %d",
   "Диск %c:",
   "%d Mб",
   "%d Гб",
   "%.01f Tб",
   "Неизвестный формат",
   "Составной том",
   "Уровень RAID-массива %d",
   "Составной том (RAID-массива)",
   "Лицензия программы",
   "Конфигурация и настройки",
   "Что делать на этой странице",
   "Обновить список",
   "Где мой диск?",
   "Закрыть Помощник",
   "Открыть имеющуюся файловую систему (пропустить сканирование, если возможно)",
   "Выбранное хранилище или раздел не содержит файловую систему. Желаете запустить сканирование?"
  ],
  "explorer": [
   "Выберите файлы и папки для восстановления",
   "-",
   "Назад к выбору хранилищ",
   "Восстановить выбранное",
   "Вы уверены, что хотите вернуться к предыдущему шагу?\nРезультат реконструкции будет потерян.",
   "Лицензия программы",
   "Что делать на этой странице",
   "Текущая файловая система (%s том)",
   "%s (%s том)",
   "%d Kб",
   "%d Мб",
   "%.01f Гб",
   "Найденные файлы (%s, %s, %lld файлов)",
   "%s (%s, %s, %lld файлов)",
   "Дополнительно найденные файлы",
   "Папка",
   "Файл",
   "Архив",
   "Аудиофайл",
   "Документ",
   "Исполняемый файл",
   "Изображение",
   "Видеофайл",
   "Эта папка пуста",
   "Предыдущая папка",
   "Введите здесь имя искомого файла",
   "Файлы или папки не найдены",
   "Результат поиска",
   "Найдено “%s”",
   "Выбрать всё",
   "Отменить весь выбор",
   "Изменить кодировку имён файлов",
   "-",
   "-",
   "-",
   "-",
   "Вы уверены, что хотите закрыть Помощник?\nПроверьте, были ли скопированы все искомые данные. После закрытия окна результат реконструкции будет потерян.",
   "Закрыть Помощник",
   "Потерянные файлы",
   "Доступные файлы",
   "Все файлы"
  ],
  "fnenc": [
   "Выбрать кодировку",
   "Ок",
   "Отмена"
  ],
  "gen": [
   "Шаг %d.",
   "Процесс восстановления данных завершён"
  ],
  "hybridview": [
   "[Содержимое объекта]",
   "Этот файл пустой",
   "Этот файл невозможно открыть",
   "Визуализация",
   "Текстовый режим",
   "Шестнадцатеричный режим"
  ],
  "lic": [
   "Нет активных лицензий",
   "Эти лицензии активны:",
   "Добавить лицензию",
   "Пользовательское соглашение",
   "Варианты лицензирования программы",
   "Общая лицензия программы",
   "Поддержка восстановления RAID-массивов",
   "Поддержка основных систем Linux/Unix",
   "Поддержка файловых систем ОС Mac",
   "Поддержка файловой системы XFS",
   "Активация новой лицензии",
   "Этот файл невозможно сохранить по причине отсутствия лицензий:\n - %s;\n - %s;\n - %s.\n\nВы хотите заказать эти лицензии сейчас?",
   "Этот файл невозможно сохранить по причине отсутствия лицензий:\n - %s;\n - %s.\n\nВы хотите заказать эти лицензии сейчас?",
   "Этот файл невозможно сохранить по причине отсутствия \"%s\".\nВы хотите заказать эту лицензию сейчас?",
   "Все файлы",
   "Сохранить этот файл как...",
   "Вы хотите перезаписать существующий файл?",
   "Объект с этим именем уже существует!",
   "Общая лицензия программы"
  ],
  "licw": [
   "Имя регистрации:",
   "Код регистрации:",
   "Применить лицензию",
   "Варианты лицензирования",
   "Лицензионное соглашение",
   "Вы действительно хотите деактивировать эту лицензию?",
   "-",
   "Благодарим Вас за активацию лицензии!",
   "Введите Ваше имя здесь",
   "Эта лицензия уже активирована.",
   "Идентификатор ПО:",
   "Купить лицензию",
   "-",
   "-",
   "Общая лицензия программы не активна!\nАктивируйте Общую лицензию перед активацией этой лицензии."
  ],
  "licwd": [
   "Software license information",
   "License type",
   "Personal (single user)",
   "Commercial (1 seat)",
   "Corporate (10 seats)",
   "Unknown",
   "Updates expire",
   "Never",
   "Government (1 seat)",
   "Academic"
  ],
  "licwe": [
   "Менеджер Лицензий",
   "ОК",
   "Регистрационный код не принят",
   "Пожалуйста, убедитесь, что код регистрации копируется как есть, со всеми черточкам, сохраняя регистр букв. Также убедитесь, что код регистрации выпущен именно к этой версии и редакции программного обеспечения.",
   "Решить онлайн проблемы с регистрацией"
  ],
  "nodata": [
   "Файлы не выбраны!",
   "На данный момент нет выбранных для восстановления файлов. Необходимо вернуться к списку файлов и выбрать все или отдельные файлы, которые Вы планируете восстановить.\n\nПрограмма не будет восстанавливать пустые папки, которые могли быть выбраны для этого восстановления."
  ],
  "nodisk": [
   "Хранилища не определены!",
   "Программа закончила определение дисков и не нашла хранилищ. Похоже, необходимо перезапустить программу с правами Администратора.\n\nДля доступа к некоторым логическим томам могут не требоваться права Администратора. В этом случае, убедитесь, что том должным образом подключен и что Ваша операционная система установила все необходимые для него драйвера."
  ],
  "nofile": [
   "Файлы не найдены!",
   "Программа не смогла найти файлы на сканируемом хранилище. Похоже, данные, которые Вы ищите, находятся на другом хранилище. Если так и есть, вернитесь к выбору хранилища и выберите другое хранилище или раздел для сканирования.\n\nВ целом, рекомендуется:\n -убедитесь, что программа закончила сканирование;\n - попробуйте выбрать другой раздел или проигнорируйте разделы хранилища вообще;\n - попробуйте поискать данные на другом хранилище."
  ],
  "partbar": [
   "%d Mб",
   "%d Гб",
   "%.01f Tб",
   "Неизвестный формат"
  ],
  "partprop": [
   "Неизвестный/поврежденный том или компонент RAID",
   "%s том",
   "Размер раздела %s",
   "Начинается от %s",
   "Не поврежден",
   "Недействительная корневая папка",
   "Нет доступных файлов",
   "Поврежденная корневая папка",
   "Нет файловой системы",
   "Файловая система не читается",
   "Раздел выходит за пределы данного хранилища: это хранилище является частью RAID-массива?",
   "Раздел начинается за пределами данного хранилища: это хранилище является частью RAID-массива?",
   "Раздел является компонентом RAID-массива"
  ],
  "partsel": [
   "Выберите раздел хранилища с Вашими данными",
   "-",
   "Вернуться",
   "Лицензия программы",
   "Конфигурация и настройки",
   "Что делать на этой странице",
   "Начать сканирование",
   "Игнорировать эти разделы",
   "Возможно, размер данного хранилища был определен некорректно: определен размер %s, а ожидаемый размер %s.",
   "%.01f Tб",
   "Вы уверены, что хотите продолжать с этим компонентом хранилища?\nЭтот компонент является частью RAID-массива. Для корректной реконструкции файловой системы НЕОБХОДИМО восстановить данные со всего RAID-массива!\nВосстановление данных с отдельного компонента RAID-массива, вероятнее всего, НЕ даст какого-либо полезного результата.",
   "Закрыть Помощник",
   "Открыть имеющуюся файловую систему (пропустить сканирование, если возможно)"
  ],
  "preview": [
   "Изменено: %s",
   "Размер: %s",
   "%d байт",
   "%d Kб",
   "%d Mб",
   "%.01f Гб",
   "Файл",
   "Архив",
   "Аудиофайл",
   "Документ",
   "Исполнительный файл",
   "Изображение",
   "Видеофайл",
   "Просмотреть",
   "Сохранить как..."
  ],
  "progl": [
   "Текущая операция выполняется",
   "%.01f%%. Затраченное время: %02d:%02d:%02d",
   "%.01f%%. Затрачено: %02d:%02d:%02d. Предположительно осталось времени: %02d:%02d:%02d"
  ],
  "scan": [
   "Идёт анализ содержимого хранилища…",
   "-",
   "Вернуться",
   "Пропустить",
   "Лицензия программы",
   "Что делать на этой странице",
   "Анализируется размещение доступных файлов",
   "Идёт поиск потерянных данных",
   "Дополняется виртуальная файловая система",
   "Обрабатываются специальные типы данных и специальные места",
   "Вы уверены, что хотите прервать анализ?\nСканирование будет прервано и Вы вернетесь к выбору хранилища.\nУже найденная программой информация не будет сохранена.",
   "Вы уверены, что хотите прервать анализ?\nРезультат реконструкции может оказаться не полным.",
   "Вы уверены, что хотите прервать этот анализ и закрыть Помощника?"
  ],
  "sett": [
   "Кодировки имён файлов для:",
   "Имена файлов устаревших ОС Windows",
   "Файловые системы DOS",
   "Файловые системы Linux/Unix",
   "Перекодировать UTF-16 (Linux/Unix)",
   "Да",
   "Нет ",
   "Какие файлы искать",
   "Искать",
   "Пропустить",
   "Потерянные и удалённые файлы",
   "Из корзины",
   "По известному содержимому",
   "Маленькие (дискетные) файловые системы",
   "Если нет пользовательских файлов ",
   "Зачем нужны эти настройки?"
  ],
  "splash": [
   "Добро пожаловать в Помощник %s!",
   "-",
   "Я прочитал(а) и понял(а) приведённую выше информацию",
   "Больше не показывать мне эту информацию",
   "Давайте начнём "
  ],
  "targetbar": [
   "Доступно %d Kб",
   "Доступно %d Mб",
   "Доступно %.01f Гб",
   "Недостаточно свободного места для хранения всех выбранных файлов",
   "Нет места для хранения всех выбранных файлов. Некоторые из них также превышают ограничения хранилища на размер файла",
   "Невозможно сохранить некоторые из выбранных файлов по причине ограничений хранилища на размер файла",
   "Другие места"
  ]
 },
 "en": {
  "rsaver": {
   "step1_title": "Step 1. Choose storage containing your data",
   "tab_logical": "Logical volumes",
   "tab_physical": "Physical disks",
   "how_to_choose_title": "How to choose correctly",
   "how_to_choose_p1": "Selecting an item from the device list will launch analysis of the entire storage device. A logical volume as an analysis target limits scanning to the corresponding boundaries.",
   "how_to_choose_p2": "In doubt? Choose the device. It slows down the analysis, but makes it comprehensive.",
   "how_to_choose_p3": "In the logical volumes list, refer to the name, size, and system identifier (Windows drive letter).",
   "how_to_choose_p4": "When choosing a physical disk, pay attention to the manufacturer, model, capacity, and serial number.",
   "faq_title": "Frequently Asked Questions:",
   "faq_q1": "• Is data recovery safe?",
   "faq_q2": "• Why is my disk not listed?",
   "faq_q3": "• How to recover data from RAID?",
   "faq_q4": "• Other questions »",
   "faq_a1": "Data recovery in R.saver is completely safe. The program operates in strictly read-only mode and will never alter or write to your source drive.",
   "faq_a2": "If your drive does not appear:\n1. Check the physical cable connection and power.\n2. Ensure the disk is visible in Windows Disk Management (diskmgmt.msc).\n3. Relaunch R.saver as Administrator.",
   "faq_a3": "To recover from RAID arrays, select the physical disks composing the array or load a virtual disk image using \"+ Open Disk Image\".",
   "faq_a4": "For additional documentation and step-by-step recovery guides, consult the built-in Help or visit the official support page.",
   "btn_refresh": "Refresh list",
   "btn_close": "Close Assistant",
   "btn_continue": "Continue",
   "btn_add_image": "+ Open Disk Image...",
   "version_title": "R.saver - version 6.9.5",
   "step_crumbs": [
      "1: Storage",
      "2: Partition",
      "3: Scan",
      "4: Select Files",
      "5: Destination",
      "6: Recover"
   ]
},
  "splash": [
   "Welcome to the R.saver Assistant!",
   "-",
   "I have read and understood the information above",
   "Do not show me this information again",
   "Let's get started "
  ],
  "disksel": [
   "Choose storage containing your data",
   "-",
   "Please wait a few seconds while we detect devices...",
   "Logical volumes",
   "Physical disks",
   "Comprehensive storages (RAID)",
   "Virtual and file-based storages",
   "Continue",
   "Disk %d",
   "Disk %c:",
   "%d MB",
   "%d GB",
   "%.1f TB",
   "Unknown format",
   "Composed volume",
   "RAID array level %d",
   "Composed volume (RAID array)",
   "Software license",
   "Configuration and settings",
   "What to do on this page",
   "Refresh list",
   "Where is my disk?",
   "Close Assistant",
   "Open existing file system (skip scanning if possible)",
   "The selected storage or partition does not contain a file system. Do you want to start scanning?"
  ],
  "partsel": [
   "Choose a storage partition with your data",
   "-",
   "Back",
   "Software license",
   "Configuration and settings",
   "What to do on this page",
   "Start scanning",
   "Ignore these partitions",
   "The size of this storage may have been determined incorrectly: size %s was determined, while %s was expected.",
   "%.1f TB",
   "Are you sure you want to continue with this storage component?\nThis component is part of a RAID array. For correct file system reconstruction it is REQUIRED to recover data from the entire RAID array!\nRecovering data from a separate RAID array component will most likely NOT give any useful result.",
   "Close Assistant",
   "Open existing file system (skip scanning if possible)"
  ],
  "partbar": [
   "%d MB",
   "%d GB",
   "%.1f TB",
   "Unknown format"
  ],
  "partprop": [
   "Unknown/damaged volume or RAID component",
   "%s volume",
   "Partition size %s",
   "Starts at %s",
   "Not damaged",
   "Invalid root folder",
   "No files available",
   "Damaged root folder",
   "No file system",
   "File system is not readable",
   "The partition extends beyond this storage: is this storage part of a RAID array?",
   "The partition starts beyond this storage: is this storage part of a RAID array?",
   "The partition is a component of a RAID array"
  ],
  "scan": [
   "Analyzing storage contents…",
   "-",
   "Back",
   "Skip",
   "Software license",
   "What to do on this page",
   "Analyzing the location of available files",
   "Searching for lost data",
   "Extending the virtual file system",
   "Processing special data types and special places",
   "Are you sure you want to interrupt the analysis?\nScanning will be interrupted and you will return to storage selection.\nInformation already found by the program will not be saved.",
   "Are you sure you want to interrupt the analysis?\nThe reconstruction result may be incomplete.",
   "Are you sure you want to interrupt this analysis and close the Assistant?"
  ],
  "progl": [
   "Current operation is in progress",
   "%.1f%%. Elapsed time: %02d:%02d:%02d",
   "%.1f%%. Elapsed: %02d:%02d:%02d. Estimated time remaining: %02d:%02d:%02d"
  ],
  "sett": [
   "File name encodings for:",
   "File names of legacy Windows OS",
   "DOS file systems",
   "Linux/Unix file systems",
   "Re-encode UTF-16 (Linux/Unix)",
   "Yes",
   "No ",
   "Which files to search",
   "Search",
   "Skip",
   "Lost and deleted files",
   "From the Recycle Bin",
   "By known content",
   "Small (floppy) file systems",
   "If there are no user files ",
   "Why are these settings needed?"
  ],
  "explorer": [
   "Choose files and folders to recover",
   "-",
   "Back to storage selection",
   "Recover the selected",
   "Are you sure you want to return to the previous step?\nThe reconstruction result will be lost.",
   "Software license",
   "What to do on this page",
   "Current file system (%s volume)",
   "%s (%s volume)",
   "%d KB",
   "%d MB",
   "%.1f GB",
   "Found files (%s, %s, %lld files)",
   "%s (%s, %s, %lld files)",
   "Additionally found files",
   "Folder",
   "File",
   "Archive",
   "Audio file",
   "Document",
   "Executable file",
   "Image",
   "Video file",
   "This folder is empty",
   "Previous folder",
   "Enter the name of the file you are looking for here",
   "No files or folders found",
   "Search result",
   "Found “%s”",
   "Select all",
   "Deselect all",
   "Change file name encoding",
   "-",
   "-",
   "-",
   "-",
   "Are you sure you want to close the Assistant?\nCheck that all the data you were looking for has been copied. After the window is closed, the reconstruction result will be lost.",
   "Close Assistant",
   "Lost files",
   "Available files",
   "All files"
  ],
  "cpdef": [
   "Choose where to save the data being recovered",
   "-",
   "Back to file selection",
   "Start recovery",
   "Software license",
   "What to do on this page",
   "Building the list of suitable storages...",
   "Selected for recovery:",
   "number of files: %lld",
   "total size: %s",
   "%d KB",
   "%d MB",
   "%.1f GB",
   "Data cannot be copied due to missing licenses:",
   "Some data cannot be copied due to missing licenses:",
   "General software license",
   "RAID array recovery support",
   "Support for basic Linux OS file systems ",
   "Support for Mac OS file systems",
   "ReFS file system support ",
   "XFS file system support ",
   "(required to copy all files)",
   "(required to copy %lld files with total size %s)",
   "However, it is possible to copy %lld files (%s).",
   "Order this license",
   "Order these licenses",
   "The recovered data will be saved to the folder:",
   " ",
   "located in the root of the volume selected from the list:",
   "Refresh list",
   "Other places",
   "Recovered",
   "The destination folder will be used or created under “%s”",
   "Refresh list",
   "Choose another place to save",
   "Choose the destination",
   "Are you REALLY sure you want to choose this place?\nThe destination appears to be the same as the source.\nIf you are recovering DELETED data, saving files to the same place will lead to \nPERMANENT LOSS OF DATA BEFORE RECOVERY.",
   "Do you really want to use this place?\nThis place is not suitable for saving your data because:\n%s.",
   "This place cannot be used to save the selected data.\nThe reason is insufficient space to store the selected files or the storage is in \"read only\" mode.",
   "Cannot create the destination folder!\nCheck write permissions for the destination and try again.\nYou can also use another place or another folder name.",
   "Cannot create the destination folder!\nAnother object with the same name as the destination folder exists.\nYou need to choose another place or another folder name.",
   "Are you sure you want to close the Assistant?\nCheck that all the data you were looking for has been copied. After the window is closed, the reconstruction result will be lost.",
   "Close Assistant",
   "-",
   "General software license"
  ],
  "targetbar": [
   "%d KB available",
   "%d MB available",
   "%.1f GB available",
   "Not enough free space to store all selected files",
   "No space to store all selected files. Some of them also exceed the storage file size limits",
   "Some of the selected files cannot be saved due to storage file size limits",
   "Other places"
  ],
  "copying": [
   "Recovering the selected files",
   "-",
   "Back to file selection",
   "Finish",
   "What to do on this page",
   "Are you sure you want to close the Assistant?\nCheck that all the data you were looking for has been copied. After the window is closed, the reconstruction result will be lost.",
   "Do you really want to interrupt file copying and return to the file selection window?",
   "Files are being extracted from “%s” and saved to “%s”...",
   "No data selected for recovery",
   "Save log",
   "HTML documents",
   "Save dialog file as...",
   "Are you sure you want to overwrite this file?",
   "Objects with this name already exist.",
   "Cannot create the destination file!",
   "Cannot write to the destination file!",
   "Data recovery report",
   "Created with:",
   "Date:",
   "Go to the recovered data",
   "Stop",
   "Do you really want to interrupt file copying?"
  ],
  "gen": [
   "Step %d.",
   "The data recovery process is complete"
  ],
  "nodata": [
   "No files selected!",
   "No files are currently selected for recovery. You need to return to the file list and select all or individual files that you plan to recover.\n\nThe program will not recover empty folders that may have been selected for this recovery."
  ],
  "nodisk": [
   "No storages detected!",
   "The program finished detecting disks and found no storages. Apparently, the program needs to be restarted with Administrator rights.\n\nAccess to some logical volumes may not require Administrator rights. In this case, make sure the volume is properly mounted and that your operating system has installed all the necessary drivers for it."
  ],
  "nofile": [
   "No files found!",
   "The program could not find files on the storage being scanned. Apparently, the data you are looking for is located on a different storage. If so, return to the storage selection and choose a different storage or partition to scan.\n\nIn general, it is recommended to:\n - make sure the program has finished scanning;\n - try selecting a different partition or ignore the storage partitions altogether;\n - try searching for data on a different storage."
  ],
  "preview": [
   "Modified: %s",
   "Size: %s",
   "%d bytes",
   "%d KB",
   "%d MB",
   "%.1f GB",
   "File",
   "Archive",
   "Audio file",
   "Document",
   "Executable file",
   "Image",
   "Video file",
   "View",
   "Save as..."
  ],
  "hybridview": [
   "[Object contents]",
   "This file is empty",
   "This file cannot be opened",
   "Visualization",
   "Text mode",
   "Hexadecimal mode"
  ],
  "fnenc": [
   "Choose encoding",
   "OK",
   "Cancel"
  ],
  "lic": [
   "No active licenses",
   "These licenses are active:",
   "Add license",
   "User agreement",
   "Software licensing options",
   "General software license",
   "RAID array recovery support",
   "Support for major Linux/Unix systems",
   "Support for Mac OS file systems",
   "XFS file system support",
   "Activate new license",
   "This file cannot be saved due to missing licenses:\n - %s;\n - %s;\n - %s.\n\nDo you want to order these licenses now?",
   "This file cannot be saved due to missing licenses:\n - %s;\n - %s.\n\nDo you want to order these licenses now?",
   "This file cannot be saved due to missing \"%s\".\nDo you want to order this license now?",
   "All files",
   "Save this file as...",
   "Do you want to overwrite the existing file?",
   "An object with this name already exists!",
   "General software license"
  ],
  "licw": [
   "Registration name:",
   "Registration code:",
   "Apply license",
   "Licensing options",
   "License agreement",
   "Do you really want to deactivate this license?",
   "-",
   "Thank you for activating the license!",
   "Enter your name here",
   "This license has already been activated.",
   "Software ID:",
   "Buy license",
   "-",
   "-",
   "The General software license is not active!\nActivate the General license before activating this license."
  ],
  "licwd": [
   "Software license information",
   "License type",
   "Personal (single user)",
   "Commercial (1 seat)",
   "Corporate (10 seats)",
   "Unknown",
   "Updates expire",
   "Never",
   "Government (1 seat)",
   "Academic"
  ],
  "licwe": [
   "License Manager",
   "OK",
   "Registration code not accepted",
   "Please make sure that the registration code is copied as is, with all dashes, preserving letter case. Also make sure that the registration code is issued specifically for this version and edition of the software.",
   "Resolve registration problems online"
  ]
 }
}

def set_lang(code):
    global LANG
    if code in STRINGS:
        LANG = code


def get_lang():
    return LANG


def available_langs():
    return sorted(STRINGS)


def _fmt(s, args):
    """تنسيق يحافظ على متطابقات مثل %lld و%.01f"""
    if not args:
        return s
    try:
        return s % args
    except (TypeError, ValueError):
        return s


def T(section, idx=0, *args):
    """جلب نص من القسم الحالي بلغة الواجهة مع تنسيق اختياري"""
    table = STRINGS.get(LANG) or STRINGS['ru']
    sec = table.get(section) or STRINGS['ru'].get(section) or []
    if idx >= len(sec):
        sec_ru = STRINGS['ru'].get(section) or []
        if idx < len(sec_ru):
            return _fmt(sec_ru[idx], args)
        return ''
    return _fmt(sec[idx], args)


def section(section):
    """كل نصوص القسم باللغة الحالية"""
    table = STRINGS.get(LANG) or STRINGS['ru']
    return table.get(section) or STRINGS['ru'].get(section) or []
