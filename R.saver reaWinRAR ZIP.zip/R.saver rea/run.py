# -*- coding: utf-8 -*-
"""R.saver 6.9.5 - Direct GUI Launcher"""
import os
import sys

# Ensure project root is in python path
ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)

from minisaver.gui import run_gui

if __name__ == '__main__':
    run_gui()
